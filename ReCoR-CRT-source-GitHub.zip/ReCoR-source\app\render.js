import { esc, money, fmtDate, fmtDateTime, monthLabel, DOSSIER_STATUTS, STATUT_TONE, initials } from './util.js';
import { can } from './auth.js';

const NAV = [
  { group: 'Pilotage', items: [
    { n: '17', label: 'Tableaux de bord', href: '/dashboard', perm: 'view' },
    { n: '08', label: 'Contrôle', href: '/controles', perm: 'view' },
    { n: '16', label: 'États et éditions', href: '/etats', perm: 'view' }
  ]},
  { group: 'Référentiels et données de base', items: [
    { n: '02', label: 'Assurés', href: '/assures', perm: 'view' },
    { n: '03', label: 'Carrières', href: '/carrieres', perm: 'view' },
    { n: '04', label: 'Cotisants', href: '/organismes', perm: 'view' },
    { n: '05', label: 'Indices et valeurs', href: '/indices', perm: 'view' },
    { n: '01', label: 'Authentification', href: '/mon-compte', perm: 'view' }
  ]},
  { group: 'Saisie et traitement', items: [
    { n: '06', label: 'Déclarations', href: '/declarations', perm: 'view' },
    { n: '07', label: 'Paiements', href: '/paiements', perm: 'view' },
    { n: '09', label: 'Calcul', href: '/calcul', perm: 'view' },
    { n: '10', label: 'Import / Export', href: '/import-export', perm: 'view' }
  ]},
  { group: 'Régularisation et recouvrement', items: [
    { n: '11', label: 'Régularisation', href: '/dossiers?type=Regularisation', perm: 'view' },
    { n: '12', label: 'Redressement', href: '/dossiers?type=Redressement', perm: 'view' },
    { n: '13', label: 'Recouvrement', href: '/recouvrement', perm: 'view' },
    { n: '14', label: 'Notifications', href: '/notifications', perm: 'view' },
    { n: '15', label: 'Comptes', href: '/comptes', perm: 'view' }
  ]},
  { group: 'Pilotage et transverse', items: [
    { n: '18', label: 'Administration', href: '/administration', perm: 'admin.users' },
    { n: '19', label: 'Traçabilité', href: '/journal', perm: 'audit.view' },
    { n: '20', label: 'Communication', href: '/communication', perm: 'view' }
  ]}
];

function icon(name, size = 18) {
  const paths = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8M8 17h5"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
    chart: '<path d="M3 3v18h18"/><path d="M7 16v-5M12 16V8M17 16v-3"/>',
    calc: '<rect x="4" y="2" width="16" height="20" rx="2"/><path d="M8 6h8M8 11h2M12 11h2M16 11h.01M8 15h2M12 15h2M16 15h.01M8 19h2M12 19h2"/>',
    wallet: '<path d="M20 12V8H6a2 2 0 0 1 0-4h12v4"/><path d="M4 6v12a2 2 0 0 0 2 2h14v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/>',
    book: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    layers: '<path d="m12 2 9 5-9 5-9-5 9-5z"/><path d="m3 12 9 5 9-5"/><path d="m3 17 9 5 9-5"/>',
    db: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5"/><path d="M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9c0 .66.4 1.25 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    print: '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>',
    menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5"/><path d="M21 12H9"/>',
    chevron: '<path d="m9 18 6-6-6-6"/>',
    message: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    alert: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>',
    building: '<rect x="3" y="4" width="18" height="18" rx="1"/><path d="M8 8h.01M12 8h.01M16 8h.01M8 12h.01M12 12h.01M16 12h.01M8 16h.01M12 16h.01M16 16h.01"/>',
    refresh: '<path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/>'
  };
  return `<svg class="ico" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.grid}</svg>`;
}

const NAV_ICONS = {
  '17': 'grid', '08': 'shield', '16': 'file',
  '02': 'users', '03': 'layers', '04': 'building', '05': 'db', '01': 'shield',
  '06': 'file', '07': 'wallet', '09': 'calc', '10': 'download',
  '11': 'refresh', '12': 'alert', '13': 'wallet', '14': 'bell', '15': 'book',
  '18': 'settings', '19': 'clock', '20': 'message'
};

export function csrfField(token) {
  return `<input type="hidden" name="_csrf" value="${esc(token || '')}">`;
}

export function badge(text, tone = 'neutral') {
  return `<span class="badge ${esc(tone)}">${esc(text)}</span>`;
}

export function dossierBadge(code) {
  return badge(DOSSIER_STATUTS[code] || code, STATUT_TONE[code] || 'neutral');
}

export function genericBadge(text) {
  const t = String(text || '').toLowerCase();
  if (['validé', 'rapproché', 'reçue', 'publié', 'conforme', 'actif', 'traité', 'résolue'].some(x => t === x)) return badge(text, 'ok');
  if (['rejeté', 'critique', 'annulé', 'suspendu', 'radié', 'décédé'].some(x => t === x)) return badge(text, 'bad');
  if (['soumis', 'transmise', 'en cours', 'nouvelle', 'à contrôler'].some(x => t === x)) return badge(text, 'info');
  if (['brouillon', 'non rapproché', 'préparée', 'en attente', 'disponibilité', 'détachement'].some(x => t === x)) return badge(text, 'warn');
  return badge(text, 'neutral');
}

export function statCard({ label, value, hint = '', tone = '', href = '', iconName = '' }) {
  const body = `
    <div class="stat-top">
      <span class="stat-label">${esc(label)}</span>
      ${iconName ? `<span class="stat-ico ${tone}">${icon(iconName, 17)}</span>` : ''}
    </div>
    <div class="stat-value ${tone}">${value}</div>
    ${hint ? `<div class="stat-hint">${hint}</div>` : ''}`;
  return href ? `<a class="stat-card ${tone}" href="${esc(href)}">${body}</a>` : `<div class="stat-card ${tone}">${body}</div>`;
}

function visibleCrumbs(crumbs, title = '') {
  const list = (Array.isArray(crumbs) ? crumbs : crumbs ? [crumbs] : [])
    .map(c => String(c ?? '').trim())
    .filter(c => c && !/^modules?\s+\d+([\s–-]+\d+)?$/i.test(c));
  const out = [];
  for (const c of list) {
    if (out.length && out[out.length - 1].toLowerCase() === c.toLowerCase()) continue;
    out.push(c);
  }
  const t = String(title).trim().toLowerCase();
  if (t && out.length) {
    const last = out[out.length - 1].toLowerCase();
    if (t === last || t.startsWith(last + ' ')) out.pop();
  }
  return out;
}

function crumbsHtml(crumbs, title = '', strongLast = false) {
  const list = visibleCrumbs(crumbs, title);
  return list.map((c, i) => {
    const last = i === list.length - 1;
    return (strongLast && last ? `<strong>${esc(c)}</strong>` : `<span>${esc(c)}</span>`) + (last ? '' : '<i>/</i>');
  }).join('');
}

export function pageHead(title, subtitle = '', actions = '', crumbs = '') {
  const head = crumbsHtml(crumbs, title);
  return `<div class="page-head">
    <div>
      ${head ? `<div class="crumbs">${head}</div>` : ''}
      <h1>${esc(title)}</h1>
      ${subtitle ? `<p class="subtitle">${subtitle}</p>` : ''}
    </div>
    ${actions ? `<div class="page-actions">${actions}</div>` : ''}
  </div>`;
}

export function card(content, { title = '', subtitle = '', actions = '', className = '', bodyClass = '' } = {}) {
  return `<section class="card ${className}">
    ${title ? `<div class="card-head"><div><h2>${esc(title)}</h2>${subtitle ? `<p>${subtitle}</p>` : ''}</div>${actions ? `<div class="card-actions">${actions}</div>` : ''}</div>` : ''}
    <div class="card-body ${bodyClass}">${content}</div>
  </section>`;
}

export function dataTable(headers, rows, { empty = 'Aucune donnée disponible.', className = '', foot = '' } = {}) {
  if (!rows.length) return `<div class="table-wrap ${className}"><div class="empty">${icon('search', 26)}<p>${esc(empty)}</p></div></div>`;
  return `<div class="table-wrap ${className}">
    <table class="data">
      <thead><tr>${headers.map(h => `<th>${h}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(r => `<tr>${r.join('')}</tr>`).join('')}</tbody>
      ${foot ? `<tfoot>${foot}</tfoot>` : ''}
    </table>
  </div>`;
}

export function td(v, cls = '', title = '') {
  return `<td class="${cls}"${title ? ` title="${esc(title)}"` : ''}>${v}</td>`;
}

export function emptyState(text, sub = '') {
  return `<div class="empty big">${icon('search', 32)}<p>${esc(text)}</p>${sub ? `<span>${esc(sub)}</span>` : ''}</div>`;
}

export function pagination({ total, page, pages, size }, base, params = {}) {
  if (pages <= 1) return `<div class="pager"><span>${total} ligne(s)</span></div>`;
  const url = p => {
    const u = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v !== '' && v !== undefined && v !== null) u.set(k, v);
    u.set('page', p);
    return `${base}?${u.toString()}`;
  };
  const start = (page - 1) * size + 1;
  const end = Math.min(total, page * size);
  const nums = [];
  for (let p = Math.max(1, page - 2); p <= Math.min(pages, page + 2); p++) nums.push(p);
  return `<div class="pager">
    <span>${start}–${end} sur ${total}</span>
    <div class="pager-btns">
      <a class="pg ${page <= 1 ? 'disabled' : ''}" href="${page <= 1 ? '#' : url(page - 1)}">Précédent</a>
      ${nums.map(p => `<a class="pg ${p === page ? 'active' : ''}" href="${url(p)}">${p}</a>`).join('')}
      <a class="pg ${page >= pages ? 'disabled' : ''}" href="${page >= pages ? '#' : url(page + 1)}">Suivant</a>
    </div>
  </div>`;
}

export function tabs(items, active) {
  return `<div class="tabs">${items.map(i => `<a href="${esc(i.href)}" class="tab ${i.key === active ? 'active' : ''}">${esc(i.label)}${i.count !== undefined ? `<span class="count">${i.count}</span>` : ''}</a>`).join('')}</div>`;
}

export function progress(pct, tone = '') {
  return `<div class="progress ${tone}"><i style="width:${Math.max(0, Math.min(100, pct))}%"></i></div>`;
}

export function barChart(items, { valueFmt = v => money(v), height = 120 } = {}) {
  const max = Math.max(1, ...items.map(i => Number(i.value) || 0));
  return `<div class="bars" style="height:${height}px">${items.map(i => {
    const h = Math.round((Number(i.value) || 0) / max * (height - 30));
    return `<div class="bar-col" title="${esc(i.label)} : ${esc(valueFmt(i.value))}">
      <div class="bar-val">${esc(valueFmt(i.value))}</div>
      <div class="bar ${i.tone || ''}" style="height:${Math.max(2, h)}px"></div>
      <div class="bar-label">${esc(i.label)}</div>
    </div>`;
  }).join('')}</div>`;
}

export function flashHtml(flash) {
  if (!flash) return '';
  const tone = flash.type === 'error' ? 'bad' : flash.type === 'warn' ? 'warn' : 'ok';
  return `<div class="flash ${tone}">${icon(flash.type === 'error' ? 'alert' : 'check', 18)}<span>${esc(flash.message)}</span><button class="flash-close" aria-label="Fermer">&times;</button></div>`;
}

function navHtml(user, active) {
  return NAV.map(group => {
    const items = group.items.filter(i => can(user, i.perm));
    if (!items.length) return '';
    return `<div class="nav-group"><div class="nav-label">${esc(group.group)}</div>
      ${items.map(i => `<a href="${i.href}" class="nav-item ${active === i.href.split('?')[0] || active === i.href ? 'active' : ''}">
        <span class="nav-ico">${icon(NAV_ICONS[i.n] || 'grid', 16)}</span>
        <span class="nav-text">${esc(i.label)}</span>
      </a>`).join('')}
    </div>`;
  }).join('');
}

export function layout({ user, title, active = '', content, flash = null, breadcrumb = [] }) {
  const today = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  return `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(title)} — ReCoR</title>
<link rel="stylesheet" href="/public/styles.css">
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'><rect width='64' height='64' rx='14' fill='%230f2742'/><text x='32' y='43' font-size='30' text-anchor='middle' fill='%23e8b93a' font-family='Georgia'>R</text></svg>">
</head>
<body>
<div class="app">
  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <div class="brand-mark">R</div>
      <div class="brand-txt"><strong>ReCoR</strong><span>CRT · Immatriculation &amp; Recouvrement</span></div>
    </div>
    <nav class="nav" aria-label="Navigation principale">${navHtml(user, active)}</nav>
    <div class="sidebar-foot"><span class="dot"></span> Plateforme opérationnelle <span class="ver">v1.0</span></div>
  </aside>
  <div class="main">
    <header class="topbar">
      <button class="icon-btn menu-btn" id="menuBtn" aria-label="Menu">${icon('menu', 20)}</button>
      <div class="top-crumb">${breadcrumb.length ? crumbsHtml(breadcrumb, '', true) || '<strong>Espace de travail</strong>' : '<strong>Espace de travail</strong>'}</div>
      <div class="top-right">
        <span class="today">${esc(today)}</span>
        <div class="user-chip">
          <span class="avatar">${esc(initials(user?.nom?.split(' ').slice(1).join(' ') || user?.nom, user?.nom?.split(' ')[0] || ''))}</span>
          <span class="user-meta"><strong>${esc(user?.nom || '')}</strong><small>${esc(user?.profil || '')}</small></span>
          <form method="post" action="/logout" class="logout-form">${csrfField(user?.csrf)}<button class="icon-btn" title="Se déconnecter" aria-label="Se déconnecter">${icon('logout', 17)}</button></form>
        </div>
      </div>
    </header>
    <main class="content" id="content">
      ${flashHtml(flash)}
      ${content}
      <footer class="app-foot">ReCoR — Caisse de Retraites du Togo · Direction de l'Immatriculation et du Recouvrement · Données de démonstration</footer>
    </main>
  </div>
</div>
<div class="overlay" id="overlay"></div>
<script src="/public/app.js"></script>
</body>
</html>`;
}

export function loginLayout({ error = '', csrf = '', demo = true }) {
  return `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Connexion — ReCoR</title>
<link rel="stylesheet" href="/public/styles.css">
</head>
<body class="login-body">
<div class="login-wrap">
  <section class="login-side">
    <div class="login-brand"><div class="brand-mark">R</div><div><strong>ReCoR</strong><span>Caisse de Retraites du Togo</span></div></div>
    <h1>Suivi, contrôle et recouvrement des cotisations sociales</h1>
    <p>Plateforme intégrée de suivi, de contrôle, de redressement, de régularisation et de recouvrement des cotisations sociales.</p>
    <ul class="login-points">
      <li>${icon('shield', 17)} Comptes individuels assurés et cotisants</li>
      <li>${icon('calc', 17)} Calculs paramétrables et explicables</li>
      <li>${icon('bell', 17)} Notification et recouvrement jusqu'à l'apurement</li>
    </ul>
    <div class="login-foot">Direction de l'Immatriculation et du Recouvrement · Octobre 2026</div>
  </section>
  <section class="login-main">
    <form method="post" action="/login" class="login-card">
      <h2>Connexion à la plateforme</h2>
      <p class="login-sub">Accès réservé aux utilisateurs habilités.</p>
      ${error ? `<div class="alert-line">${icon('alert', 17)} ${esc(error)}</div>` : ''}
      ${csrfField(csrf)}
      <label>Identifiant<input name="login" autocomplete="username" required autofocus placeholder="Votre identifiant"></label>
      <label>Mot de passe<input type="password" name="password" autocomplete="current-password" required placeholder="Votre mot de passe"></label>
      <button class="btn primary block" type="submit">Se connecter ${icon('arrow', 17)}</button>
      ${demo ? `<details class="demo-accounts"><summary>Comptes de démonstration</summary>
        <div class="demo-grid">
          <span><b>admin</b> / Recor2026!</span><span>Administrateur</span>
          <span><b>direction</b> / Recor2026!</span><span>Direction</span>
          <span><b>superviseur</b> / Recor2026!</span><span>Superviseur</span>
          <span><b>controleur</b> / Recor2026!</span><span>Contrôleur</span>
          <span><b>comptable</b> / Recor2026!</span><span>Comptable</span>
          <span><b>recouvrement</b> / Recor2026!</span><span>Agent Recouvrement</span>
          <span><b>saisie</b> / Recor2026!</span><span>Agent de saisie</span>
        </div>
      </details>` : ''}
    </form>
    <div class="login-legal">Toute connexion est journalisée. Les données affichées sont fictives et destinées à la démonstration.</div>
  </section>
</div>
</body>
</html>`;
}

export { icon };
