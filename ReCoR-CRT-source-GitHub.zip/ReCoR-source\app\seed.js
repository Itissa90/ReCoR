import { db, q, one, run, tx, nextReference, schema, isSeeded, getParam } from './db.js';
import { hashPassword } from './auth.js';
import { addMonths, monthLast, monthIndex, nowStamp, periodFromDate } from './util.js';
import { calcMois, rebuildComptes, getAssure } from './calc.js';

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20261112);
const rint = (a, b) => a + Math.floor(rnd() * (b - a + 1));
const pick = arr => arr[Math.floor(rnd() * arr.length)];
const chance = p => rnd() < p;
const pad = (n, l = 2) => String(n).padStart(l, '0');
const iso = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;

const NOMS = ['ADJOVI','AMOUZOU','AGBEKO','MENSAH','KOUASSI','DOGBE','TETTEH','AGBODJAN','AKAKPO','AMEGASHIE','ANANI','ATI','AYIVI','BAKO','BODJONA','DOSSEH','EDOH','EKLU','FIAWOO','GBEASSOR','GNASSINGBE','HOUNKPATI','JOHNSON','KAGBARA','KOFFI','LABODJI','LAWSON','LOMOU','MAGLOIRE','MAWUSSI','NARTEY','NYASSOGBO','OCLOO','OGOE','SEDDOH','SEGBEDJI','TCHALLA','TOSSOU','VIAGBO','WOSSOU','YOVO','ZINSOU','ASSIH','BALOUKI','DAGRA','KADANGA','NAPO','OURO','SAIBOU','KPODAR'];
const PRENOMS_M = ['Kossi','Yao','Komi','Kodjo','Kofi','Edem','Sena','Mawuli','Dodji','Elom','Ayi','Kokou','Messan','Abdoul','Ibrahim','Pascal','Emmanuel','Prosper','Jean','Paul'];
const PRENOMS_F = ['Afi','Ama','Akossiwa','Ayaba','Emefa','Essi','Georgette','Akouvi','Laure','Mireille','Nadège','Ophélie','Reine','Sika','Yawa','Zénabou','Adjovi','Bénédicte','Céline','Dédé'];
const VILLES = ['Lomé','Kpalimé','Atakpamé','Sokodé','Kara','Dapaong','Tsévié','Aného','Bassar','Notsé'];
const CORPS = [
  ['Enseignement', ['A','B']], ['Santé', ['A','B']], ['Administration générale', ['A','B','C']],
  ['Douanes', ['A','B']], ['Impôts', ['A','B']], ['Eaux et Forêts', ['B','C']],
  ['Travaux publics', ['B','C']], ['Justice', ['A','B']], ['Élevage', ['B','C']]
];
const GRADES = ['1er grade', '2e grade', '3e grade', 'Hors échelle'];

const ORGANISMES = [
  ['MEF', "Ministère de l'Économie et des Finances", 'MEF', 'Ministère', 'Lomé', 'contact@mef.gouv.tg'],
  ['MSHP', "Ministère de la Santé et de l'Hygiène Publique", 'MSHP', 'Ministère', 'Lomé', 'contact@sante.gouv.tg'],
  ['MEPSTA', "Ministère des Enseignements Primaire, Secondaire, Technique et de l'Artisanat", 'MEPSTA', 'Ministère', 'Lomé', 'contact@education.gouv.tg'],
  ['MAEP', "Ministère de l'Agriculture, de l'Élevage et de la Pêche", 'MAEP', 'Ministère', 'Lomé', 'contact@agriculture.gouv.tg'],
  ['MIED', "Ministère des Infrastructures et de l'Énergie", 'MIED', 'Ministère', 'Lomé', 'contact@infrastructures.gouv.tg'],
  ['MFPT', 'Ministère de la Fonction Publique et du Travail', 'MFPT', 'Ministère', 'Lomé', 'contact@fonctionpublique.gouv.tg'],
  ['UL', 'Université de Lomé', 'UL', 'Établissement', 'Lomé', 'contact@univ-lome.tg'],
  ['CHUSO', 'CHU Sylvanus Olympio', 'CHUSO', 'Établissement', 'Lomé', 'contact@chusylvanus.tg'],
  ['CL', 'Commune de Lomé', 'CL', 'Collectivité', 'Lomé', 'contact@ville-lome.tg'],
  ['ANASER', 'Agence Nationale de la Sécurité Routière', 'ANASER', 'Agence', 'Lomé', 'contact@anaser.tg'],
  ['MJ', 'Ministère de la Justice', 'MJ', 'Ministère', 'Lomé', 'contact@justice.gouv.tg'],
  ['DGD', 'Direction Générale des Douanes', 'DGD', 'Administration', 'Lomé', 'contact@douanes.gouv.tg']
];

const PERIODE_DEBUT = '2024-07';
const PERIODE_FIN = '2026-06';

function insertParam(cle, valeur, libelle, groupe, type = 'texte') {
  run('INSERT OR REPLACE INTO parametres (cle, valeur, libelle, type, groupe, modifiable) VALUES (?,?,?,?,?,1)',
    cle, String(valeur), libelle, type, groupe);
}

export async function seedDatabase() {
  schema();
  if (isSeeded()) return { seeded: false };

  tx(() => {
    for (const t of ['declaration_lignes','declarations','paiements','dossiers','dossier_etapes','notifications','mouvements','anomalies','carrieres','assures','indices','organismes','communications','extractions','audit_log','sessions','users','pieces','sequences']) {
      db.exec(`DELETE FROM ${t}`);
    }
    for (const t of ['sqlite_sequence']) {
      try { db.exec(`DELETE FROM ${t}`); } catch { /* ignore */ }
    }

    insertParam('TAUX_COTISATION', '0.125', 'Taux global de cotisation (à valider par la CRT)', 'Calcul', 'nombre');
    insertParam('VALEUR_INDICIAIRE_DEFAUT', '1000', 'Valeur indiciaire par défaut (FCFA / point)', 'Calcul', 'nombre');
    insertParam('SEUIL_ANCIENNETE_MOIS', '6', "Seuil d'ancienneté d'un solde impayé (mois)", 'Contrôle', 'nombre');
    insertParam('DELAI_DECLARATION_JOURS', '30', 'Délai réglementaire de déclaration (jours)', 'Contrôle', 'nombre');
    insertParam('DELAI_RELANCE_JOURS', '30', 'Délai entre deux relances (jours)', 'Recouvrement', 'nombre');
    insertParam('RELANCE_MAX', '3', 'Nombre maximum de relances', 'Recouvrement', 'nombre');
    insertParam('MODE_NOTIFICATION', 'Courrier', 'Mode de transmission des notifications', 'Recouvrement');
    insertParam('TOLERANCE_ECART', '1', 'Tolérance sur les écarts de calcul (FCFA)', 'Calcul', 'nombre');
    insertParam('PERIODE_ANALYSE_DEBUT', PERIODE_DEBUT, 'Début de la période analysée par les contrôles', 'Contrôle');
    insertParam('PERIODE_ANALYSE_FIN', PERIODE_FIN, 'Fin de la période analysée par les contrôles', 'Contrôle');
    insertParam('ORGANISME_LIBELLE', 'Caisse de Retraites du Togo', 'Libellé de l’institution', 'Général');
    insertParam('DEVISE', 'FCFA', 'Devise de référence', 'Général');
    insertParam('TAUX_MAJORATION', '0', 'Taux de majoration de retard (à valider par la CRT)', 'Calcul', 'nombre');

    const users = [
      ['admin', 'Amina ADJOVI', 'Administrateur', 'admin@crt.tg'],
      ['direction', 'Kossi AMOUZOU', 'Direction', 'direction@crt.tg'],
      ['superviseur', 'Afi MENSAH', 'Superviseur', 'superviseur@crt.tg'],
      ['controleur', 'Yao KOUASSI', 'Contrôleur', 'controleur@crt.tg'],
      ['comptable', 'Ama DOGBE', 'Comptable', 'comptable@crt.tg'],
      ['recouvrement', 'Komi AGBEKO', 'Agent Recouvrement', 'recouvrement@crt.tg'],
      ['saisie', 'Sena TETTEH', 'Agent de saisie', 'saisie@crt.tg']
    ];
    for (const [login, nom, profil, email] of users) {
      run('INSERT INTO users (login, password_hash, nom, profil, email, telephone, actif, created_at) VALUES (?,?,?,?,?,?,1,?)',
        login, hashPassword('Recor2026!'), nom, profil, email, '+228 22 00 00 00', nowStamp());
    }

    for (const [code, nom, sigle, type, ville, email] of ORGANISMES) {
      run('INSERT INTO organismes (code, nom, sigle, type, ville, email, telephone, actif, created_at) VALUES (?,?,?,?,?,?,?,1,?)',
        code, nom, sigle, type, ville, email, '+228 22 10 10 10', nowStamp());
    }

    const indices = [];
    const baseVals = new Map();
    for (let ind = 350; ind <= 1300; ind += 50) {
      const v2024 = Math.round((900 + (ind - 350) * 0.30) / 10) * 10;
      baseVals.set(ind, v2024);
    }
    let seqIdx = 0;
    for (const [year, factor] of [[2024, 1], [2026, 1.05]]) {
      for (const [ind, v] of baseVals) {
        seqIdx++;
        const ref = `IDX-${year}-${pad(seqIdx, 4)}`;
        const debut = year === 2024 ? '2024-01-01' : '2026-01-01';
        const fin = year === 2024 ? '2025-12-31' : null;
        run(`INSERT INTO indices (reference, indice, valeur_indiciaire, date_debut, date_fin, categorie, corps, observation, statut, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?)`,
          ref, ind, Math.round(v * factor), debut, fin, 'A/B/C', 'Tous corps', 'Référentiel de démonstration', 'Actif', nowStamp());
      }
    }
    run(`INSERT INTO indices (reference, indice, valeur_indiciaire, date_debut, date_fin, categorie, corps, observation, statut, created_at)
         VALUES ('IDX-2026-ABERRANT', 1350, 50, '2026-01-01', NULL, 'A', 'Santé', 'Valeur à vérifier', 'Actif', ?)`, nowStamp());

    const assureIds = [];
    for (let i = 1; i <= 120; i++) {
      const sexe = chance(0.45) ? 'M' : 'F';
      const prenom = sexe === 'M' ? PRENOMS_M[(i * 7) % PRENOMS_M.length] : PRENOMS_F[(i * 5) % PRENOMS_F.length];
      const nom = NOMS[(i * 3) % NOMS.length];
      const birthYear = rint(1960, 1995);
      const dateNaissance = iso(birthYear, rint(1, 12), rint(1, 28));
      const priseYear = Math.min(2018, birthYear + rint(22, 27));
      const datePrise = iso(priseYear, rint(1, 12), rint(1, 28));
      const dateNom = addMonths(periodFromDate(datePrise), 6) + '-15';
      const dateTit = addMonths(periodFromDate(datePrise), rint(12, 24)) + '-01';
      const [corps, cats] = CORPS[(i * 2) % CORPS.length];
      const categorie = cats[(i * 3) % cats.length];
      let indice = 350 + 50 * Math.min(18, Math.max(0, Math.floor((priseYear - 1985) / 2) + rint(0, 3)));
      indice = Math.min(1300, Math.max(350, indice));
      const orgId = ((i - 1) % 12) + 1;
      let position = 'Actif', datePosition = null, statut = 'Actif', cessationType = null, dateCessation = null;
      if ([16, 42, 67, 88, 101, 113].includes(i)) { position = 'Détachement'; datePosition = '2025-09-01'; }
      if ([23, 58, 94].includes(i)) { position = 'Disponibilité'; datePosition = '2025-06-01'; }
      if (i === 31) { position = 'Suspension'; datePosition = '2025-08-01'; }
      if (i === 40) { indice = 1350; }
      if ([19, 64, 110].includes(i)) { statut = 'Retraité'; cessationType = 'Retraite'; dateCessation = '2025-12-31'; position = 'Cessation'; }
      if (i === 77) { statut = 'Radié'; cessationType = 'Radiation'; dateCessation = '2025-03-31'; position = 'Cessation'; }
      const dateRetraite = iso(birthYear + 60, 12, 31);
      run(`INSERT INTO assures (matricule, nom, prenom, sexe, date_naissance, lieu_naissance, telephone, date_prise_service,
           date_nomination, date_titularisation, corps, categorie, grade, echelon, indice, bonification, date_retraite,
           position, date_position, cessation_type, date_cessation, organisme_id, statut, observation, created_at, updated_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        `FP-${pad(i, 6)}`, nom, prenom, sexe, dateNaissance, pick(VILLES), `+228 9${rint(0, 9)} ${rint(10, 99)} ${rint(10, 99)} ${rint(10, 99)}`,
        datePrise, dateNom, dateTit, corps, categorie, pick(GRADES), String(rint(1, 4)), indice, rint(0, 15), dateRetraite,
        position, datePosition, cessationType, dateCessation, orgId, statut, i === 40 ? 'Indice à vérifier' : '', nowStamp(), nowStamp());
      assureIds.push(i);

      run(`INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        i, 'Titularisation', 'Acte de titularisation', dateTit, null, null, indice, null, `acte_titularisation_${i}.pdf`, 'Validé', 1, nowStamp());
      if (chance(0.45)) {
        const an = rint(2019, 2023);
        run(`INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          i, 'Avancement', "Avancement d'échelon", iso(an, 1, 1), null, indice, indice + 50, null, `arrete_avancement_${i}.pdf`, 'Validé', 3, nowStamp());
        indice = Math.min(1300, indice + 50);
        run('UPDATE assures SET indice = ? WHERE id = ?', indice, i);
      }
      if (position === 'Détachement' && i !== 30) {
        run(`INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          i, 'Détachement', 'Détachement auprès d’un organisme tiers', '2025-09-01', null, indice, indice, null, 'decision_detachement.pdf', 'Validé', 3, nowStamp());
      }
      if (i === 20) {
        run(`INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          20, 'Reclassement', 'Reclassement indiciaire', '2026-01-01', null, indice, 1450, null, 'arrete_reclassement.pdf', 'Validé', 3, nowStamp());
      }
      if (i === 25) {
        run(`INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          25, 'Disponibilité', 'Disponibilité pour convenances personnelles', '2026-03-01', '2026-01-01', indice, indice, null, 'decision_disponibilite.pdf', 'Validé', 3, nowStamp());
      }
      if (i === 30) {
        run(`UPDATE assures SET position = 'Détachement', date_position = '2025-10-01' WHERE id = 30`);
      }
      if (i === 20) {
        run(`INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
          20, 'Brouillon test', 'Événement en attente', '2025-01-01', null, indice, indice, null, '', 'Brouillon', 3, nowStamp());
      }
    }

    const specialStart = new Map();
    for (let i = 1; i <= 8; i++) specialStart.set(i, '2025-10');
    const periods = [];
    for (let p = PERIODE_DEBUT; p <= PERIODE_FIN; p = addMonths(p, 1)) periods.push(p);

    const cache = {};
    const allDeclarations = [];
    for (const periode of periods) {
      for (const [idx, org] of ORGANISMES.entries()) {
        const orgId = idx + 1;
        if ((orgId === 11 && ['2026-03', '2026-04'].includes(periode)) || (orgId === 12 && periode === '2026-02')) continue;
        const assures = q('SELECT * FROM assures WHERE organisme_id = ?', orgId);
        const lines = [];
        for (const a of assures) {
          if (a.date_prise_service && periodFromDate(a.date_prise_service) > periode) continue;
          if (a.date_cessation && periodFromDate(a.date_cessation) < periode) continue;
          if (specialStart.get(a.id) && specialStart.get(a.id) > periode) continue;
          const c = calcMois(a.id, periode, cache);
          if (!c) continue;
          lines.push({ matricule: a.matricule, assure_id: a.id, montant: c.theorique });
        }
        if (!lines.length) continue;

        let montant = lines.reduce((s, l) => s + l.montant, 0);
        const reference = nextReference('DEC');
        let statut = 'Validé';
        if (periode >= '2026-04') statut = chance(0.5) ? 'Soumis' : 'Validé';
        if (chance(0.03)) statut = 'Rejeté';
        let dateReception = monthLast(periode).slice(0, 8) + pad(rint(5, 28));
        if (orgId === 5 && periode === '2026-02') dateReception = '2026-04-10';
        const type = 'Mensuelle';
        const res = run(`INSERT INTO declarations (reference, organisme_id, periode, date_reception, type_declaration, nb_assures,
             montant_declare, fichier_source, piece, agent_id, statut, observation, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          reference, orgId, periode, dateReception, type, lines.length, montant,
          `declaration_${org[0]}_${periode}.csv`, `bordereau_${org[0]}_${periode}.pdf`, 7, statut, '', nowStamp());
        const declId = Number(res.lastInsertRowid);

        let under = null;
        if ((orgId === 3 && periode === '2026-03') || (orgId === 7 && periode === '2026-04')) {
          under = lines.length > 3 ? [1, 3, 5] : [0];
        }
        for (const [li, l] of lines.entries()) {
          let m = l.montant;
          if (under && under.includes(li)) m = Math.round(m * 0.7);
          run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
            declId, l.matricule, l.assure_id, m, 'Conforme');
        }
        if (under) {
          montant = q('SELECT COALESCE(SUM(montant),0) AS m FROM declaration_lignes WHERE declaration_id = ?', declId)[0].m;
          run('UPDATE declarations SET montant_declare = ? WHERE id = ?', montant, declId);
        }
        if (orgId === 4 && periode === '2026-02') {
          run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
            declId, 'FP-999999', null, 35000, 'Anomalie');
          run('UPDATE declarations SET montant_declare = montant_declare + 35000 WHERE id = ?', declId);
        }
        if (orgId === 5 && periode === '2026-01') {
          const other = one('SELECT * FROM assures WHERE organisme_id = 6 LIMIT 1');
          if (other) {
            const c = calcMois(other.id, periode, cache);
            run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
              declId, other.matricule, other.id, c.theorique, 'Anomalie');
            run('UPDATE declarations SET montant_declare = montant_declare + ? WHERE id = ?', c.theorique, declId);
          }
        }
        if (orgId === 2 && periode === '2026-05') {
          const res2 = run(`INSERT INTO declarations (reference, organisme_id, periode, date_reception, type_declaration, nb_assures,
               montant_declare, fichier_source, piece, agent_id, statut, observation, created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            nextReference('DEC'), 2, periode, `${periode}-25`, 'Rectificative', lines.length, montant + 1000,
            `declaration_MSHP_${periode}_rect.csv`, `bordereau_MSHP_${periode}_rect.pdf`, 7, 'Soumis', 'Déclaration rectificative', nowStamp());
          const d2 = Number(res2.lastInsertRowid);
          for (const l of lines) {
            run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
              d2, l.matricule, l.assure_id, l.montant, 'Conforme');
          }
          allDeclarations.push({ id: d2, organisme_id: 2, periode, montant_declare: montant + 1000, statut: 'Soumis', date_reception: `${periode}-25` });
        }
        allDeclarations.push({ id: declId, organisme_id: orgId, periode, montant_declare: montant, statut, date_reception: dateReception, type, reference });
      }
    }

    let payCounter = 0;
    for (const d of allDeclarations) {
      if (d.statut !== 'Validé') continue;
      savePaymentLoop: {
        if (chance(0.1)) {
          const old = monthIndex(d.periode) < monthIndex(addMonths(PERIODE_FIN, -6));
          if (old && chance(0.55)) break savePaymentLoop;
          if (!old) break savePaymentLoop;
        }
        const partial = chance(0.18);
        const montantPaye = partial ? Math.round(d.montant_declare * (0.5 + rnd() * 0.3)) : d.montant_declare;
        if (montantPaye <= 0) continue;
        payCounter++;
        const datePaiement = addMonths(d.periode, 1) + `-${pad(rint(3, 26))}`;
        const mode = pick(['Virement', 'Virement', 'Chèque', 'Espèces']);
        const rapproche = chance(0.9);
        const year = datePaiement.slice(0, 4);
        const reference = `PAY-${year}-${pad(payCounter, 5)}`;
        run(`INSERT INTO paiements (reference, organisme_id, date_paiement, montant, mode_paiement, reference_bancaire, declaration_id,
             dossier_id, piece, agent_id, statut, motif, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
          reference, d.organisme_id, datePaiement, montantPaye, mode,
          mode === 'Virement' ? `BOA-${rint(100000, 999999)}` : mode === 'Chèque' ? `CHQ-${rint(10000, 99999)}` : '',
          d.id, null, `recu_${reference}.pdf`, 5, rapproche ? 'Rapproché' : 'Non rapproché', '', nowStamp());
      }
    }

    const orphanPayments = [
      [1, '2026-01-18', 1250000, 'Virement', 'BOA-778451'],
      [4, '2026-03-09', 480000, 'Chèque', 'CHQ-44781'],
      [8, '2025-11-22', 960000, 'Virement', 'BOA-661230'],
      [10, '2026-04-14', 315000, 'Espèces', '']
    ];
    for (const [orgId, date, montant, mode, banque] of orphanPayments) {
      payCounter++;
      const reference = `PAY-${date.slice(0, 4)}-${pad(payCounter, 5)}`;
      run(`INSERT INTO paiements (reference, organisme_id, date_paiement, montant, mode_paiement, reference_bancaire, declaration_id,
           dossier_id, piece, agent_id, statut, motif, created_at)
           VALUES (?,?,?,?,?,?,NULL,NULL,?,?,?,?,?)`,
        reference, orgId, date, montant, mode, banque, `recu_${reference}.pdf`, 5, 'Non rapproché', 'Règlement non imputé', nowStamp());
    }

    run(`INSERT INTO communications (titre, type_support, destinataires, contenu, date_publication, statut, created_by, created_at)
         VALUES (?,?,?,?,?,?,?,?)`,
      'Campagne de régularisation des cotisations 2026', 'Affiche',
      'Assurés et organismes cotisants',
      "La CRT invite les assurés et organismes à se rapprocher de la Direction de l'Immatriculation et du Recouvrement pour régulariser leur situation. Les notifications individuelles seront transmises progressivement.",
      '2026-09-15', 'Publié', 2, nowStamp());
    run(`INSERT INTO communications (titre, type_support, destinataires, contenu, date_publication, statut, created_by, created_at)
         VALUES (?,?,?,?,?,?,?,?)`,
      'Notice explicative — période creuse et droit à pension', 'Notice',
      'Assurés',
      "Une période creuse correspond à une période d'activité non couverte par une cotisation. Elle peut être régularisée afin de préserver vos droits. Contactez votre organisme cotisant pour connaître les pièces à fournir.",
      null, 'Brouillon', 2, nowStamp());

    run(`INSERT INTO audit_log (user_id, user_nom, date_action, entite, entite_id, action, ancienne_valeur, nouvelle_valeur, motif, piece, adresse_ip)
         VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      1, 'Système', nowStamp(), 'Plateforme', '0', 'Initialisation', '', 'Jeu de données de démonstration chargé', 'Amorçage ReCoR', '', '127.0.0.1');
  });

  let controls = null;
  try {
    const mod = await import('./controls.js');
    controls = mod.runControles ? mod.runControles({ actor: { id: 1, nom: 'Système' } }) : null;
  } catch (e) {
    console.error('Contrôles initiaux non exécutés:', e.message);
  }

  try {
    tx(() => {
      const seqMax = new Map();
      for (const row of q('SELECT reference FROM paiements')) {
        const m = /^(.+)-(\d{4})-(\d+)$/.exec(row.reference || '');
        if (!m) continue;
        const key = `${m[1]}-${m[2]}`;
        seqMax.set(key, Math.max(seqMax.get(key) || 0, Number(m[3])));
      }
      for (const [key, value] of seqMax) {
        run('INSERT OR REPLACE INTO sequences (prefix, value) VALUES (?,?)', key, value);
      }
      const flux = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13'];
      const dates = ['2026-05-12', '2026-05-28', '2026-06-10', '2026-06-24', '2026-07-08', '2026-07-22',
        '2026-08-05', '2026-08-19', '2026-09-03', '2026-09-18', '2026-10-02', '2026-10-16'];
      const progression = ['13', '09', '10', '08', '06', '05', '03', '12', '11', '07', '02', '13', '09', '10', '08', '06', '05', '03', '12', '11', '07'];
      const dossiers = q('SELECT * FROM dossiers ORDER BY id');
      for (const [i, d] of dossiers.entries()) {
        const target = progression[i % progression.length];
        const rank = flux.indexOf(target);
        if (rank <= 0) continue;
        const assure = d.assure_id ? one('SELECT nom, prenom FROM assures WHERE id = ?', d.assure_id) : null;
        const organisme = !d.assure_id && d.organisme_id ? one('SELECT nom FROM organismes WHERE id = ?', d.organisme_id) : null;
        run("UPDATE dossier_etapes SET date = ? WHERE dossier_id = ? AND statut = '01'", '2026-05-02 09:30:00', d.id);
        for (let k = 1; k <= rank; k++) {
          run('INSERT INTO dossier_etapes (dossier_id, statut, date, user_id, commentaire) VALUES (?,?,?,?,?)',
            d.id, flux[k], `${dates[Math.min(k - 1, dates.length - 1)]} 09:30:00`, 1,
            k === rank ? 'Progression de démonstration' : `Passage au statut ${flux[k]}`);
        }
        const dueInitial = Number(d.montant_du || 0);
        run('UPDATE dossiers SET statut = ?, created_at = ?, updated_at = ? WHERE id = ?',
          target, '2026-05-02 09:30:00', `${dates[Math.min(rank - 1, dates.length - 1)]} 09:30:00`, d.id);
        if (target >= '07') {
          const recue = target >= '09';
          const notRef = nextReference('NOT');
          run(
            `INSERT INTO notifications (reference, dossier_id, destinataire_type, destinataire_id, destinataire_nom, montant_du,
               date_notification, date_reception, mode, statut, relances, derniere_relance, created_at)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
            notRef, d.id, d.assure_id ? 'Assuré' : 'Organisme cotisant', d.assure_id || d.organisme_id,
            assure ? `${assure.nom} ${assure.prenom}` : (organisme?.nom || 'Organisme cotisant'), dueInitial,
            target >= '08' ? dates[6] : null, recue ? dates[8] : null, 'Courrier',
            recue ? 'Reçue' : target >= '08' ? 'Transmise' : 'Préparée',
            target >= '10' ? 1 : 0, target >= '10' ? dates[9] : null, `${dates[6]} 09:30:00`
          );
        }
        if (['10', '11', '12', '13'].includes(target) && dueInitial > 0) {
          const montant = target === '10' ? Math.round(dueInitial * 0.45) : dueInitial;
          const ref = nextReference('PAY');
          run(`INSERT INTO paiements (reference, organisme_id, date_paiement, montant, mode_paiement, reference_bancaire,
               declaration_id, dossier_id, piece, agent_id, statut, motif, created_at)
               VALUES (?,?,?,?,?,?,NULL,?,?,?,?,?,?)`,
            ref, d.organisme_id || 1, dates[9], montant, 'Virement', `BOA-${Number(d.id) + 690000}`,
            d.id, `recu_${ref}.pdf`, 5, 'Rapproché', '', nowStamp());
          run('UPDATE dossiers SET montant_paye = ?, montant_du = ? WHERE id = ?', montant, Math.max(0, dueInitial - montant), d.id);
        }
      }
    });
  } catch (e) {
    console.error('Progression de démonstration non appliquée:', e.message);
  }

  rebuildComptes();
  return { seeded: true, controls };
}

if (process.argv[1] && process.argv[1].endsWith('seed.js')) {
  const res = await seedDatabase();
  console.log('Seed:', JSON.stringify(res));
}
