import { q, one, run, tx, getParam, setParam, nextReference, audit } from './db.js';
import { ANOMALIES, addMonths, ageDays, monthLast, monthLabel, nowStamp, periodFromDate, todayISO } from './util.js';
import { calcMois, firstDeclarationMonth, periodesCreques, rebuildComptes } from './calc.js';

const TOL = () => Number(getParam('TOLERANCE_ECART', '1'));

function addAnomaly(a) {
  const signature = a.signature.slice(0, 300);
  const existing = one('SELECT * FROM anomalies WHERE signature = ?', signature);
  if (existing) return existing;
  const meta = ANOMALIES[a.code] || { libelle: a.code, criticite: 'À contrôler' };
  const res = run(
    `INSERT INTO anomalies (signature, code, criticite, libelle, detail, assure_id, organisme_id, declaration_id, dossier_id, periode, statut, created_at)
     VALUES (?,?,?,?,?,?,?,?,?,?, 'Nouvelle', ?)`,
    signature, a.code, meta.criticite, meta.libelle, a.detail || '', a.assure_id || null, a.organisme_id || null,
    a.declaration_id || null, a.dossier_id || null, a.periode || null, nowStamp()
  );
  return one('SELECT * FROM anomalies WHERE id = ?', Number(res.lastInsertRowid));
}

export function createDossier({ type, assure_id, organisme_id, periode_debut, periode_fin, montant_theorique, montant_declare = 0, motif, piece = '', agent_id = null, anomalie_id = null }) {
  if (anomalie_id) {
    const linked = one('SELECT * FROM dossiers WHERE anomalie_id = ?', anomalie_id);
    if (linked) return linked;
  }
  const reference = nextReference('REC');
  const du = Math.max(0, Math.round(Number(montant_theorique || 0) - Number(montant_declare || 0)));
  const now = nowStamp();
  const res = run(
    `INSERT INTO dossiers (reference, type, assure_id, organisme_id, periode_debut, periode_fin, montant_theorique, montant_declare,
       montant_paye, montant_du, statut, motif, piece, agent_id, anomalie_id, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,0,?,?,?,?,?,?,?,?)`,
    reference, type, assure_id || null, organisme_id || null, periode_debut || null, periode_fin || periode_debut || null,
    Number(montant_theorique || 0), Number(montant_declare || 0), du, '01', motif || '', piece || '', agent_id, anomalie_id, now, now
  );
  const id = Number(res.lastInsertRowid);
  run('INSERT INTO dossier_etapes (dossier_id, statut, date, user_id, commentaire) VALUES (?,?,?,?,?)',
    id, '01', now, agent_id, 'Dossier créé par le contrôle automatique');
  if (anomalie_id) run('UPDATE anomalies SET dossier_id = ? WHERE id = ?', id, anomalie_id);
  return one('SELECT * FROM dossiers WHERE id = ?', id);
}

export function createDossierFromAnomaly(anomalyId, actor) {
  const a = one('SELECT * FROM anomalies WHERE id = ?', anomalyId);
  if (!a) return null;
  if (a.dossier_id) return one('SELECT * FROM dossiers WHERE id = ?', a.dossier_id);
  let type = 'Redressement';
  if (a.code === 'A09' || a.code === 'A01' || a.code === 'A04' || a.code === 'A05' || a.code === 'A14') type = 'Regularisation';
  if (a.code === 'A10' || a.code === 'A11' || a.code === 'A12') type = 'Recouvrement';
  let theorique = 0, declare = 0, debut = a.periode, fin = a.periode;
  if (a.declaration_id) {
    const d = one('SELECT * FROM declarations WHERE id = ?', a.declaration_id);
    if (d) { theorique = Number(d.montant_declare); declare = 0; debut = d.periode; fin = d.periode; }
  } else if (a.assure_id) {
    const c = a.periode && /^\d{4}-\d{2}$/.test(a.periode) ? calcMois(a.assure_id, a.periode) : null;
    theorique = c ? c.theorique : 0;
  }
  const dossier = createDossier({
    type, assure_id: a.assure_id, organisme_id: a.organisme_id, periode_debut: debut, periode_fin: fin,
    montant_theorique: theorique, montant_declare: declare, motif: `${a.code} — ${a.libelle}${a.detail ? ' : ' + a.detail : ''}`,
    agent_id: actor?.id, anomalie_id: a.id
  });
  run('UPDATE anomalies SET statut = ? WHERE id = ?', 'En cours', a.id);
  audit(actor, 'Anomalie', a.id, 'Création dossier', a.statut, dossier.reference, a.libelle);
  return dossier;
}

export function runControles({ actor } = {}) {
  const debut = getParam('PERIODE_ANALYSE_DEBUT', '2024-07');
  const fin = getParam('PERIODE_ANALYSE_FIN', todayISO().slice(0, 7));
  const seuilMois = Number(getParam('SEUIL_ANCIENNETE_MOIS', '6'));
  const delaiDecl = Number(getParam('DELAI_DECLARATION_JOURS', '30'));
  const tolerance = TOL();
  const cache = {};
  const counts = {};
  const bump = code => { counts[code] = (counts[code] || 0) + 1; };

  tx(() => {
    const organismes = q('SELECT * FROM organismes WHERE actif = 1 ORDER BY id');
    const assures = q("SELECT * FROM assures WHERE statut IN ('Actif','Suspendu') ORDER BY id");

    const moisA01 = [];
    for (let p = Math.max(0, 11); p >= 0; p--) moisA01.push(addMonths(fin, -p));

    for (const org of organismes) {
      for (const periode of moisA01) {
        const decl = one("SELECT * FROM declarations WHERE organisme_id = ? AND periode = ? AND statut <> 'Rejeté'", org.id, periode);
        if (!decl) {
          addAnomaly({
            code: 'A01', organisme_id: org.id, periode,
            signature: `A01|${org.id}|${periode}`,
            detail: `Aucune déclaration reçue pour ${monthLabel(periode)} (${org.sigle || org.code}).`
          });
          bump('A01');
        }
      }
    }

    const declarations = q("SELECT * FROM declarations WHERE statut <> 'Rejeté' ORDER BY periode, organisme_id");
    const groups = new Map();
    for (const d of declarations) {
      const key = `${d.organisme_id}|${d.periode}`;
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(d);
    }
    for (const [key, list] of groups) {
      if (list.length < 2) continue;
      const [orgId, periode] = key.split('|');
      for (const dup of list.slice(1)) {
        addAnomaly({
          code: 'A03', organisme_id: Number(orgId), declaration_id: dup.id, periode,
          signature: `A03|${dup.id}`,
          detail: `Déclaration en doublon (${dup.reference}) pour ${monthLabel(periode)}.`
        });
        bump('A03');
      }
    }

    const lateLimit = delaiDecl;
    for (const d of declarations) {
      if (!d.date_reception) continue;
      const limit = new Date(monthLast(d.periode) + 'T00:00:00Z');
      limit.setUTCDate(limit.getUTCDate() + lateLimit);
      if (new Date(d.date_reception + 'T00:00:00Z') > limit) {
        addAnomaly({
          code: 'A02', organisme_id: d.organisme_id, declaration_id: d.id, periode: d.periode,
          signature: `A02|${d.id}`,
          detail: `Déclaration reçue le ${d.date_reception} pour la période ${monthLabel(d.periode)}.`
        });
        bump('A02');
      }
    }

    for (const d of declarations) {
      const lines = q('SELECT l.*, a.organisme_id AS assure_org FROM declaration_lignes l LEFT JOIN assures a ON a.id = l.assure_id WHERE l.declaration_id = ?', d.id);
      for (const l of lines) {
        if (!l.assure_id && l.matricule) {
          const found = one('SELECT id FROM assures WHERE matricule = ?', l.matricule);
          if (!found) {
            addAnomaly({
              code: 'A04', organisme_id: d.organisme_id, declaration_id: d.id, periode: d.periode,
              signature: `A04|${d.id}|${l.matricule}`,
              detail: `Matricule ${l.matricule} absent du référentiel des assurés.`
            });
            bump('A04');
          }
        }
        if (l.assure_id && l.assure_org && Number(l.assure_org) !== Number(d.organisme_id)) {
          addAnomaly({
            code: 'A05', assure_id: l.assure_id, organisme_id: d.organisme_id, declaration_id: d.id, periode: d.periode,
            signature: `A05|${d.id}|${l.assure_id}`,
            detail: `L'assuré ${l.matricule} relève d'un autre organisme que celui de la déclaration.`
          });
          bump('A05');
        }
      }
    }

    for (const d of declarations) {
      const lines = q('SELECT * FROM declaration_lignes WHERE declaration_id = ?', d.id);
      const byAssure = new Map(lines.filter(l => l.assure_id).map(l => [l.assure_id, l]));
      const expected = assures.filter(a => Number(a.organisme_id) === Number(d.organisme_id));
      for (const a of expected) {
        if (a.date_prise_service && periodFromDate(a.date_prise_service) > d.periode) continue;
        if (a.date_cessation && periodFromDate(a.date_cessation) < d.periode) continue;
        const first = firstDeclarationMonth(a.id);
        if (!first || d.periode < first) continue;
        const c = calcMois(a.id, d.periode, cache);
        if (!c || c.theorique <= 0) continue;
        const line = byAssure.get(a.id);
        const declared = line ? Number(line.montant || 0) : 0;
        if (declared + tolerance < c.theorique) {
          const detail = line
            ? `Déclaré ${Math.round(declared)} FCFA contre ${c.theorique} FCFA théoriques (${monthLabel(d.periode)}).`
            : `Assuré non déclaré pour ${monthLabel(d.periode)} (théorique ${c.theorique} FCFA).`;
          const anomalie = addAnomaly({
            code: 'A06', assure_id: a.id, organisme_id: d.organisme_id, declaration_id: d.id, periode: d.periode,
            signature: `A06|${d.id}|${a.id}`, detail
          });
          if (!anomalie.dossier_id) {
            createDossier({
              type: 'Redressement', assure_id: a.id, organisme_id: d.organisme_id,
              periode_debut: d.periode, periode_fin: d.periode, montant_theorique: c.theorique,
              montant_declare: declared, motif: `Sous-déclaration — ${monthLabel(d.periode)}`,
              agent_id: actor?.id, anomalie_id: anomalie.id
            });
          }
          bump('A06');
        }
      }
    }

    const carrieres = q("SELECT * FROM carrieres WHERE statut = 'Validé'");
    for (const c of carrieres) {
      if (!c.nouvel_indice) continue;
      const idx = one(
        `SELECT id FROM indices WHERE indice = ? AND statut = 'Actif'
         AND (date_debut IS NULL OR date_debut <= ?) AND (date_fin IS NULL OR date_fin >= ?) LIMIT 1`,
        c.nouvel_indice, c.date_fin || '9999-12-31', c.date_debut || '0000-01-01');
      if (!idx) {
        addAnomaly({
          code: 'A07', assure_id: c.assure_id, periode: c.date_debut ? c.date_debut.slice(0, 7) : null,
          signature: `A07|${c.id}`,
          detail: `Indice ${c.nouvel_indice} issu de l'événement de carrière n°${c.id} sans valeur indiciaire applicable.`
        });
        bump('A07');
      }
    }

    for (const idx of q("SELECT * FROM indices WHERE statut = 'Actif'")) {
      if (Number(idx.valeur_indiciaire) < 100) {
        addAnomaly({
          code: 'A08', periode: idx.date_debut ? idx.date_debut.slice(0, 7) : null,
          signature: `A08|${idx.id}`,
          detail: `Valeur indiciaire ${idx.valeur_indiciaire} FCFA anormalement faible pour l'indice ${idx.indice} (${idx.reference}).`
        });
        bump('A08');
      }
    }

    for (const a of assures) {
      const periods = periodesCreques(a.id, debut);
      if (!periods.length) continue;
      let total = 0;
      const details = [];
      for (const p of periods) {
        const c = calcMois(a.id, p, cache);
        if (c && c.theorique > 0) { total += c.theorique; details.push(p); }
      }
      if (total <= 0) continue;
      const first = details[0], last = details[details.length - 1];
      const anomalie = addAnomaly({
        code: 'A09', assure_id: a.id, organisme_id: a.organisme_id, periode: first,
        signature: `A09|${a.id}|${first}|${last}`,
        detail: `${details.length} période(s) sans cotisation entre ${monthLabel(first)} et ${monthLabel(last)} — ${Math.round(total)} FCFA à régulariser.`
      });
      if (!anomalie.dossier_id) {
        createDossier({
          type: 'Regularisation', assure_id: a.id, organisme_id: a.organisme_id,
          periode_debut: first, periode_fin: last, montant_theorique: total, montant_declare: 0,
          motif: `Périodes non cotisées (${monthLabel(first)} → ${monthLabel(last)})`,
          agent_id: actor?.id, anomalie_id: anomalie.id
        });
      }
      bump('A09');
    }

    const paiements = q("SELECT * FROM paiements WHERE statut = 'Non rapproché' ORDER BY date_paiement");
    for (const p of paiements) {
      if (ageDays(p.date_paiement) < 15) continue;
      addAnomaly({
        code: 'A10', organisme_id: p.organisme_id, periode: p.date_paiement ? p.date_paiement.slice(0, 7) : null,
        signature: `A10|${p.id}`,
        detail: `Paiement ${p.reference} de ${Math.round(p.montant)} FCFA non rapproché depuis ${ageDays(p.date_paiement)} jours.`
      });
      bump('A10');
    }

    for (const d of declarations) {
      if (d.statut !== 'Validé') continue;
      const paid = one("SELECT COALESCE(SUM(montant),0) AS m FROM paiements WHERE declaration_id = ? AND statut = 'Rapproché'", d.id).m;
      if (Number(paid) > 0 && Number(paid) + tolerance < Number(d.montant_declare) && ageDays(d.date_reception) > 30) {
        addAnomaly({
          code: 'A11', organisme_id: d.organisme_id, declaration_id: d.id, periode: d.periode,
          signature: `A11|${d.id}`,
          detail: `Payé ${Math.round(paid)} FCFA sur ${Math.round(d.montant_declare)} FCFA déclarés (${d.reference}).`
        });
        bump('A11');
      }
    }

    const cutoff = addMonths(fin, -seuilMois);
    const unpaid = q(
      `SELECT d.* FROM declarations d
       WHERE d.statut = 'Validé' AND d.periode <= ?
         AND NOT EXISTS (SELECT 1 FROM paiements p WHERE p.declaration_id = d.id)
       ORDER BY d.periode ASC LIMIT 8`, cutoff);
    for (const d of unpaid) {
      if (Number(d.montant_declare) <= 0) continue;
      const anomalie = addAnomaly({
        code: 'A12', organisme_id: d.organisme_id, declaration_id: d.id, periode: d.periode,
        signature: `A12|${d.id}`,
        detail: `Déclaration ${d.reference} de ${monthLabel(d.periode)} sans aucun paiement (${Math.round(d.montant_declare)} FCFA).`
      });
      if (!anomalie.dossier_id) {
        createDossier({
          type: 'Recouvrement', organisme_id: d.organisme_id, periode_debut: d.periode, periode_fin: d.periode,
          montant_theorique: Number(d.montant_declare), montant_declare: 0,
          motif: `Solde ancien non apuré — ${monthLabel(d.periode)}`, agent_id: actor?.id, anomalie_id: anomalie.id
        });
      }
      bump('A12');
    }

    for (const c of carrieres) {
      const incoherent = (c.date_fin && c.date_debut && c.date_fin < c.date_debut) || (c.nouvel_indice !== null && Number(c.nouvel_indice) <= 0);
      if (incoherent) {
        addAnomaly({
          code: 'A13', assure_id: c.assure_id, periode: c.date_debut ? c.date_debut.slice(0, 7) : null,
          signature: `A13|${c.id}`,
          detail: `Événement « ${c.type_evenement} » incohérent : début ${c.date_debut}, fin ${c.date_fin}.`
        });
        bump('A13');
      }
    }

    for (const a of assures) {
      if (!['Détachement', 'Disponibilité'].includes(a.position)) continue;
      const ev = one("SELECT id FROM carrieres WHERE assure_id = ? AND statut = 'Validé' AND type_evenement = ?", a.id, a.position);
      if (!ev) {
        addAnomaly({
          code: 'A14', assure_id: a.id, organisme_id: a.organisme_id, periode: a.date_position ? a.date_position.slice(0, 7) : null,
          signature: `A14|${a.id}`,
          detail: `Position « ${a.position} » depuis ${a.date_position || '—'} sans événement de carrière correspondant.`
        });
        bump('A14');
      }
    }

    for (const a of assures) {
      if (a.position !== 'Suspension') continue;
      const start = a.date_position ? a.date_position.slice(0, 7) : '0000-01';
      const n = one(
        `SELECT COUNT(*) AS n FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id
         WHERE l.assure_id = ? AND d.periode >= ? AND d.statut <> 'Rejeté'`, a.id, start).n;
      if (Number(n) > 0) {
        addAnomaly({
          code: 'A15', assure_id: a.id, organisme_id: a.organisme_id, periode: start,
          signature: `A15|${a.id}`,
          detail: `Assuré suspendu depuis ${a.date_position} mais ${n} déclaration(s) continuent de le mentionner.`
        });
        bump('A15');
      }
    }

    setParam('DERNIER_CONTROLE', nowStamp());
  });

  audit(actor, 'Contrôle', 'global', 'Exécution des contrôles', '', JSON.stringify(counts), 'Contrôle automatique A01-A15');
  try { rebuildComptes(); } catch (e) { console.error('Rebuild comptes:', e.message); }
  return counts;
}
