const MONTHS = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];

export function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v)
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#39;');
}

export function money(n, suffix = true) {
  const v = Math.round(Number(n) || 0);
  const s = new Intl.NumberFormat('fr-FR').format(v).replaceAll('\u202f', ' ').replaceAll('\u00a0', ' ');
  return suffix ? `${s} FCFA` : s;
}

export function num(v, def = 0) {
  if (v === null || v === undefined || v === '') return def;
  const n = Number(String(v).replace(/\s/g, '').replace(',', '.'));
  return Number.isFinite(n) ? n : def;
}

export function int(v, def = 0) {
  const n = parseInt(String(v ?? '').replace(/\s/g, ''), 10);
  return Number.isFinite(n) ? n : def;
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function nowStamp() {
  return new Date().toISOString().slice(0, 19).replace('T', ' ');
}

export function fmtDate(s) {
  if (!s) return '—';
  const d = String(s).slice(0, 10).split('-');
  if (d.length !== 3) return String(s);
  return `${d[2]}/${d[1]}/${d[0]}`;
}

export function fmtDateTime(s) {
  if (!s) return '—';
  return `${fmtDate(s)} ${String(s).slice(11, 16)}`;
}

export function monthLabel(p) {
  if (!p || !/^\d{4}-\d{2}$/.test(p)) return p || '—';
  const [y, m] = p.split('-').map(Number);
  return `${MONTHS[m - 1]} ${y}`;
}

export function monthShort(p) {
  if (!p || !/^\d{4}-\d{2}$/.test(p)) return p || '—';
  const [y, m] = p.split('-').map(Number);
  return `${String(m).padStart(2, '0')}/${y}`;
}

export function parsePeriod(p) {
  if (!p || !/^\d{4}-\d{2}$/.test(p)) return null;
  const [y, m] = p.split('-').map(Number);
  if (m < 1 || m > 12) return null;
  return { year: y, month: m };
}

export function periodFromDate(iso) {
  return String(iso || todayISO()).slice(0, 7);
}

export function addMonths(p, n) {
  const [y, m] = p.split('-').map(Number);
  const idx = y * 12 + (m - 1) + n;
  return `${Math.floor(idx / 12)}-${String((idx % 12) + 1).padStart(2, '0')}`;
}

export function monthIndex(p) {
  const [y, m] = p.split('-').map(Number);
  return y * 12 + (m - 1);
}

export function monthsBetween(a, b) {
  return monthIndex(b) - monthIndex(a);
}

export function monthsRange(start, end) {
  const out = [];
  if (!start || !end) return out;
  let cur = start;
  let guard = 0;
  while (monthIndex(cur) <= monthIndex(end) && guard < 1200) {
    out.push(cur);
    cur = addMonths(cur, 1);
    guard++;
  }
  return out;
}

export function lastMonths(n, end) {
  const e = end || new Date().toISOString().slice(0, 7);
  const out = [];
  for (let i = n - 1; i >= 0; i--) out.push(addMonths(e, -i));
  return out;
}

export function monthFirst(p) { return `${p}-01`; }

export function monthLast(p) {
  const [y, m] = p.split('-').map(Number);
  const d = new Date(Date.UTC(y, m, 0));
  return d.toISOString().slice(0, 10);
}

export function paginate(total, page, size = 25) {
  const pages = Math.max(1, Math.ceil(total / size));
  const current = Math.min(Math.max(1, page || 1), pages);
  return { total, pages, page: current, size, offset: (current - 1) * size };
}

export function csvCell(v) {
  const s = v === null || v === undefined ? '' : String(v);
  return `"${s.replaceAll('"', '""')}"`;
}

export function age(iso) {
  if (!iso) return null;
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  let a = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) a--;
  return a;
}

export function initials(nom, prenom) {
  return `${(prenom || '').charAt(0)}${(nom || '').charAt(0)}`.toUpperCase() || '?';
}

export function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }

export function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export const DOSSIER_STATUTS = {
  '01': 'Détecté',
  '02': 'À contrôler',
  '03': "En cours d'analyse",
  '04': 'Calcul effectué',
  '05': 'En attente de validation',
  '06': 'Validé',
  '07': 'Notification à établir',
  '08': 'Notifié',
  '09': 'En attente de paiement',
  '10': 'Paiement partiel',
  '11': 'Paiement reçu',
  '12': 'En rapprochement',
  '13': 'Apuré',
  '14': 'Rejeté',
  '15': 'Annulé',
  '16': 'Suspendu'
};

export const DOSSIER_TRANSITIONS = {
  '01': ['02', '15', '16'],
  '02': ['03', '15', '16'],
  '03': ['04', '15', '16'],
  '04': ['05', '03', '16'],
  '05': ['06', '14', '16'],
  '06': ['07', '16'],
  '07': ['08', '16'],
  '08': ['09', '16'],
  '09': ['10', '11', '13', '16'],
  '10': ['11', '12', '16'],
  '11': ['12', '16'],
  '12': ['13', '09', '16'],
  '13': [],
  '14': [],
  '15': [],
  '16': ['03', '15']
};

export const DOSSIER_TYPES = {
  'Regularisation': 'Régularisation',
  'Redressement': 'Redressement',
  'Recouvrement': 'Recouvrement'
};

export const ANOMALIES = {
  A01: { libelle: 'Déclaration manquante', famille: 'Déclarations', criticite: 'Critique' },
  A02: { libelle: 'Déclaration en retard', famille: 'Déclarations', criticite: 'À contrôler' },
  A03: { libelle: 'Déclaration en doublon', famille: 'Déclarations', criticite: 'Critique' },
  A04: { libelle: 'Matricule inconnu', famille: 'Carrière et référentiels', criticite: 'Critique' },
  A05: { libelle: 'Assuré rattaché à un mauvais organisme', famille: 'Carrière et référentiels', criticite: 'Critique' },
  A06: { libelle: 'Cotisation inférieure au montant théorique', famille: 'Cotisations et périodes', criticite: 'Critique' },
  A07: { libelle: 'Indice non pris en compte', famille: 'Carrière et référentiels', criticite: 'À contrôler' },
  A08: { libelle: 'Valeur indiciaire incorrecte', famille: 'Carrière et référentiels', criticite: 'À contrôler' },
  A09: { libelle: 'Période creuse détectée', famille: 'Cotisations et périodes', criticite: 'Critique' },
  A10: { libelle: 'Paiement non rapproché', famille: 'Paiements et soldes', criticite: 'À contrôler' },
  A11: { libelle: 'Paiement inférieur au montant dû', famille: 'Paiements et soldes', criticite: 'À contrôler' },
  A12: { libelle: 'Solde ancien non apuré', famille: 'Paiements et soldes', criticite: 'Critique' },
  A13: { libelle: 'Incohérence de carrière', famille: 'Carrière et référentiels', criticite: 'Critique' },
  A14: { libelle: 'Détachement non renseigné', famille: 'Cotisations et périodes', criticite: 'À contrôler' },
  A15: { libelle: 'Suspension de solde non prise en compte', famille: 'Cotisations et périodes', criticite: 'À contrôler' }
};

export const STATUT_TONE = {
  '01': 'neutral', '02': 'warn', '03': 'info', '04': 'info', '05': 'warn', '06': 'ok',
  '07': 'warn', '08': 'info', '09': 'warn', '10': 'warn', '11': 'ok', '12': 'info',
  '13': 'ok', '14': 'bad', '15': 'neutral', '16': 'neutral'
};

export function dossierStatut(code) {
  return DOSSIER_STATUTS[code] || code || '—';
}

export function ageDays(iso) {
  if (!iso) return 0;
  const d = new Date(`${String(iso).slice(0, 10)}T00:00:00Z`).getTime();
  return Math.max(0, Math.floor((Date.now() - d) / 86400000));
}
