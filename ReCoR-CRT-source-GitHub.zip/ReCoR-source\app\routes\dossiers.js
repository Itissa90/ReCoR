import { q, one, run, audit, nextReference, getParam } from '../db.js';
import { can } from '../auth.js';
import { getDossier, compteAssure, compteCotisant, rebuildComptes, refreshDossierTotals, expliquer } from '../calc.js';
import { storePiece } from '../files.js';
import { pageHead, card, dataTable, td, pagination, tabs, csrfField, badge, genericBadge, dossierBadge, statCard, icon, progress } from '../render.js';
import { esc, money, num, int, fmtDate, fmtDateTime, monthLabel, paginate, todayISO, nowStamp, DOSSIER_STATUTS, DOSSIER_TRANSITIONS, DOSSIER_TYPES, STATUT_TONE, ageDays } from '../util.js';

const TOL = () => Number(getParam('TOLERANCE_ECART', '1'));
const OUVERT = "('01','02','03','04','05','16')";
const RECOUVREMENT = "('06','07','08','09','10','11','12')";

function orgOptions(selected) {
  return q('SELECT * FROM organismes ORDER BY nom')
    .map(o => `<option value="${o.id}" ${Number(selected) === o.id ? 'selected' : ''}>${esc(o.sigle || o.code)} — ${esc(o.nom)}</option>`).join('');
}

function dossierLink(id, ref) {
  return id ? `<a class="mono" href="/dossiers/${id}">${esc(ref)}</a>` : '<span class="muted">—</span>';
}

function typeLabel(t) {
  return DOSSIER_TYPES[t] || t || '—';
}

function timeline(etapes) {
  if (!etapes.length) return '<div class="empty"><p>Aucun mouvement enregistré.</p></div>';
  return `<ol class="timeline">${etapes.map(e => `
    <li class="timeline-item">
      <span class="timeline-dot ${STATUT_TONE[e.statut] || 'neutral'}"></span>
      <div class="timeline-body">
        <div class="timeline-head"><strong>${esc(DOSSIER_STATUTS[e.statut] || e.statut)}</strong><span class="muted">${fmtDateTime(e.date)}</span></div>
        <div class="timeline-meta">${esc(e.user_nom || 'Système')}${e.commentaire ? ` — ${esc(e.commentaire)}` : ''}</div>
      </div>
    </li>`).join('')}</ol>`;
}

function cibleOptions(current, user) {
  const targets = DOSSIER_TRANSITIONS[current] || [];
  return targets.filter(t => {
    if (t === '06' || t === '14') return can(user, 'dossiers.validate');
    if (t === '07' || t === '08') return can(user, 'dossiers.notify');
    return can(user, 'dossiers.edit');
  }).map(t => `<option value="${t}">${t} — ${esc(DOSSIER_STATUTS[t])}</option>`).join('');
}

function notificationRow(n) {
  return [
    td(`<a class="mono" href="/notifications/${n.id}">${esc(n.reference)}</a>`),
    td(dossierLink(n.dossier_id, n.dossier_ref)),
    td(fmtDate(n.date_notification)),
    td(fmtDate(n.date_reception)),
    td(String(n.relances || 0), 'num'),
    td(genericBadge(n.statut)),
    td(`<a class="btn xs" href="/notifications/${n.id}">Ouvrir</a>`, 'actions')
  ];
}

export function register(router) {
  // ---------------- Dossiers ----------------
  router.get('/dossiers', 'view', (ctx) => {
    const f = {
      q: String(ctx.query.q || '').trim(),
      type: String(ctx.query.type || ''),
      statut: String(ctx.query.statut || ''),
      organisme: String(ctx.query.organisme || '')
    };
    const page = int(ctx.query.page, 1);
    const where = []; const params = [];
    if (f.q) {
      where.push('(d.reference LIKE ? OR a.matricule LIKE ? OR a.nom LIKE ? OR a.prenom LIKE ?)');
      const t = `%${f.q}%`; params.push(t, t, t, t);
    }
    if (f.type) { where.push('d.type = ?'); params.push(f.type); }
    if (f.statut) { where.push('d.statut = ?'); params.push(f.statut); }
    if (f.organisme) { where.push('d.organisme_id = ?'); params.push(Number(f.organisme)); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const from = `FROM dossiers d LEFT JOIN assures a ON a.id = d.assure_id LEFT JOIN organismes o ON o.id = d.organisme_id`;
    const total = one(`SELECT COUNT(*) AS n ${from} ${w}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(
      `SELECT d.*, a.matricule, a.nom AS assure_nom, a.prenom AS assure_prenom, o.sigle, o.nom AS organisme_nom
       ${from} ${w}
       ORDER BY CASE d.statut WHEN '01' THEN 0 WHEN '05' THEN 1 WHEN '07' THEN 2 WHEN '08' THEN 3 ELSE 4 END, d.updated_at DESC
       LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(d => [
      td(`<a class="main-cell mono" href="/dossiers/${d.id}">${esc(d.reference)}</a><span class="sub">${esc(typeLabel(d.type))} · ${esc(monthLabel(d.periode_debut))}${d.periode_fin && d.periode_fin !== d.periode_debut ? ' → ' + esc(monthLabel(d.periode_fin)) : ''}</span>`),
      td(d.matricule ? `<a href="/assures/${d.assure_id}">${esc(d.assure_nom)} ${esc(d.assure_prenom)}</a><span class="sub mono">${esc(d.matricule)}</span>` : (d.sigle ? `<a href="/organismes/${d.organisme_id}">${esc(d.sigle)}</a>` : '<span class="muted">—</span>')),
      td(money(d.montant_du), 'num'),
      td(fmtDate(d.updated_at || d.created_at)),
      td(dossierBadge(d.statut)),
      td(`<a class="btn xs" href="/dossiers/${d.id}">Ouvrir</a>`, 'actions')
    ]);
    const byType = new Map(q('SELECT type, COUNT(*) AS n FROM dossiers GROUP BY type').map(r => [r.type, r.n]));
    const counts = one(`SELECT COUNT(*) AS total,
      SUM(CASE WHEN statut IN ${OUVERT} THEN 1 ELSE 0 END) AS ouverts,
      SUM(CASE WHEN statut IN ${RECOUVREMENT} THEN 1 ELSE 0 END) AS recouvrement,
      SUM(CASE WHEN statut = '13' THEN 1 ELSE 0 END) AS apures,
      COALESCE(SUM(CASE WHEN statut IN ${RECOUVREMENT} THEN montant_du ELSE 0 END),0) AS du FROM dossiers`);
    const tabsHtml = tabs([
      { key: '', label: 'Tous les dossiers', href: '/dossiers', count: counts.total },
      { key: 'Regularisation', label: 'Régularisation', href: '/dossiers?type=Regularisation', count: byType.get('Regularisation') || 0 },
      { key: 'Redressement', label: 'Redressement', href: '/dossiers?type=Redressement', count: byType.get('Redressement') || 0 },
      { key: 'Recouvrement', label: 'Recouvrement', href: '/dossiers?type=Recouvrement', count: byType.get('Recouvrement') || 0 }
    ], f.type);
    const content = `
      ${pageHead('Dossiers de régularisation et de redressement', 'Circuit de traitement en 11 étapes et 16 statuts, de la détection à l’apurement.', `<a class="btn" href="/controles">${icon('shield', 16)} Centre de contrôle</a>`, ['Modules 11–12', 'Dossiers'])}
      ${tabsHtml}
      <div class="stats">
        ${statCard({ label: 'Dossiers ouverts', value: counts.ouverts || 0, hint: 'Détection à validation', tone: 'warn', iconName: 'clock' })}
        ${statCard({ label: 'En recouvrement', value: counts.recouvrement || 0, hint: 'Notifiés et non apurés', tone: 'info', iconName: 'bell' })}
        ${statCard({ label: 'Montant restant dû', value: money(counts.du), hint: 'Dossiers en recouvrement', tone: 'bad', iconName: 'wallet' })}
        ${statCard({ label: 'Dossiers apurés', value: counts.apures || 0, hint: 'Solde soldé', tone: 'ok', iconName: 'check' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/dossiers">
          ${f.type ? `<input type="hidden" name="type" value="${esc(f.type)}">` : ''}
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(f.q)}" placeholder="Référence, matricule ou nom"></div>
          <div class="field"><label>Organisme</label><select name="organisme"><option value="">Tous</option>${orgOptions(f.organisme)}</select></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${Object.entries(DOSSIER_STATUTS).map(([c, l]) => `<option value="${c}" ${f.statut === c ? 'selected' : ''}>${c} — ${esc(l)}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/dossiers${f.type ? `?type=${esc(f.type)}` : ''}">Réinitialiser</a>
        </form>
        ${dataTable(['Dossier', 'Assuré / organisme', 'Reste dû', 'Dernier mouvement', 'Statut', ''], trs, { empty: 'Aucun dossier pour ces critères. Lancez les contrôles pour en générer.' })}
        ${pagination(p, '/dossiers', f)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Dossiers', '/dossiers', content, ['Modules 11–12', 'Dossiers']));
  });

  router.get('/dossiers/:id', 'view', (ctx) => {
    const d = getDossier(Number(ctx.params.id));
    if (!d) return ctx.send('<h1>Dossier introuvable</h1>', 404);
    const etapes = q(`SELECT e.*, u.nom AS user_nom FROM dossier_etapes e LEFT JOIN users u ON u.id = e.user_id WHERE e.dossier_id = ? ORDER BY e.id`, d.id);
    const notifications = q('SELECT * FROM notifications WHERE dossier_id = ? ORDER BY id DESC', d.id);
    const paiements = q('SELECT * FROM paiements WHERE dossier_id = ? ORDER BY date_paiement, id', d.id);
    const anomalie = d.anomalie_id ? one('SELECT * FROM anomalies WHERE id = ?', d.anomalie_id) : null;
    const cibles = cibleOptions(d.statut, ctx.user);
    const resteTol = Number(d.montant_du) > TOL();
    const progressPct = Number(d.montant_theorique) > 0
      ? Math.round((Number(d.montant_declare) + Number(d.montant_paye)) / Number(d.montant_theorique) * 100) : 0;
    const paiementRows = paiements.map(p => [
      td(`<a class="mono" href="/paiements/${p.id}">${esc(p.reference)}</a>`),
      td(fmtDate(p.date_paiement)),
      td(esc(p.mode_paiement || '—')),
      td(money(p.montant), 'num'),
      td(genericBadge(p.statut))
    ]);
    const noticeRows = notifications.map(n => notificationRow({ ...n, dossier_ref: d.reference }));
    const content = `
      ${pageHead(`Dossier ${d.reference}`, `${typeLabel(d.type)} · ${d.assure_nom ? `${d.assure_nom} ${d.assure_prenom} (${d.matricule})` : d.organisme_nom || ''}`, `<button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Modules 11–12', 'Dossiers', d.reference])}
      <div class="stats">
        ${statCard({ label: 'Montant théorique', value: money(d.montant_theorique), hint: 'Cotisations reconstituées', iconName: 'calc' })}
        ${statCard({ label: 'Montant déclaré', value: money(d.montant_declare), hint: 'Déjà déclaré', tone: 'info', iconName: 'file' })}
        ${statCard({ label: 'Montant payé', value: money(d.montant_paye), hint: `${paiements.length} paiement(s)`, tone: 'ok', iconName: 'wallet' })}
        ${statCard({ label: 'Reste dû', value: money(d.montant_du), hint: resteTol ? 'À recouvrer' : 'Dossier soldé', tone: resteTol ? 'bad' : 'ok', iconName: 'alert' })}
      </div>
      <div class="grid grid-2">
        ${card(`<dl class="dl tight">
          <dt>Référence</dt><dd class="mono">${esc(d.reference)}</dd>
          <dt>Type</dt><dd>${esc(typeLabel(d.type))}</dd>
          <dt>Assuré</dt><dd>${d.assure_id ? `<a href="/assures/${d.assure_id}">${esc(d.assure_nom)} ${esc(d.assure_prenom)} (${esc(d.matricule)})</a>` : '—'}</dd>
          <dt>Organisme</dt><dd>${d.organisme_id ? `<a href="/organismes/${d.organisme_id}">${esc(d.organisme_nom)}</a>` : '—'}</dd>
          <dt>Période</dt><dd>${esc(monthLabel(d.periode_debut))}${d.periode_fin && d.periode_fin !== d.periode_debut ? ` → ${esc(monthLabel(d.periode_fin))}` : ''}</dd>
          <dt>Motif</dt><dd>${esc(d.motif || '—')}</dd>
          <dt>Pièce</dt><dd>${esc(d.piece || '—')}</dd>
          <dt>Anomalie d'origine</dt><dd>${anomalie ? `<a href="/anomalies/${anomalie.id}">${esc(anomalie.code)} — ${esc(anomalie.libelle)}</a>` : '—'}</dd>
          <dt>Créé le</dt><dd>${fmtDateTime(d.created_at)}</dd>
          <dt>Dernière action</dt><dd>${fmtDateTime(d.updated_at)}</dd>
        </dl>
        <div class="mt16"><a class="btn" href="/expliquer?dossier_id=${d.id}&periode=${esc(d.periode_debut || '')}">${icon('calc', 15)} Expliquer l'écart</a></div>`, { title: 'Informations du dossier' })}
        ${card(`
          <div class="kv-row"><span>Statut actuel</span><strong>${dossierBadge(d.statut)}</strong></div>
          <div class="kv-row"><span>Étape</span><strong>${Object.keys(DOSSIER_STATUTS).indexOf(d.statut) + 1} / 16</strong></div>
          <div class="kv-row"><span>Avancement financier</span><strong>${Math.min(100, progressPct)} %</strong></div>
          ${progress(Math.min(100, progressPct), resteTol ? '' : 'ok')}
          ${cibles ? `<form method="post" action="/dossiers/${d.id}/transition" enctype="multipart/form-data" class="form-grid one mt16">
            ${csrfField(ctx.csrf)}
            <div class="field"><label>Nouveau statut</label><select name="statut" required><option value="">Choisir…</option>${cibles}</select></div>
            <div class="field"><label>Motif / commentaire</label><textarea name="motif" rows="2" placeholder="Obligatoire pour un rejet, une annulation ou une suspension."></textarea></div>
            <div class="field"><label>Pièce justificative</label><input type="file" name="piece" accept=".pdf,.png,.jpg,.jpeg"></div>
            <div class="form-actions"><button class="btn primary" type="submit">Enregistrer la transition</button></div>
          </form>` : `<div class="callout mt16">${icon('check', 18)}<div>Ce dossier est dans un statut final : aucune transition supplémentaire n'est possible.</div></div>`}
        `, { title: 'Circuit de validation' })}
      </div>
      ${card(timeline(etapes), { title: 'Historique du dossier', subtitle: 'Chaque transition est horodatée et attribuée.' })}
      ${card(dataTable(['Notification', 'Dossier', 'Émise le', 'Reçue le', 'Relances', 'Statut', ''], noticeRows, { empty: 'Aucune notification. Le passage au statut 07 en crée une automatiquement.' }), { title: 'Notifications', bodyClass: 'flush' })}
      ${card(dataTable(['Paiement', 'Date', 'Mode', 'Montant', 'Statut'], paiementRows, { empty: 'Aucun paiement imputé à ce dossier.' }), { title: 'Paiements imputés', bodyClass: 'flush', actions: can(ctx.user, 'paiements.create') ? `<a class="btn sm" href="/paiements/nouveau?dossier=${d.id}">Enregistrer un paiement</a>` : '' })}`;
    ctx.send(ctx.page(`Dossier ${d.reference}`, '/dossiers', content, ['Modules 11–12', 'Dossiers', d.reference]));
  });

  router.post('/dossiers/:id/transition', 'view', (ctx) => {
    const d = one('SELECT * FROM dossiers WHERE id = ?', Number(ctx.params.id));
    if (!d) return ctx.send('<h1>Dossier introuvable</h1>', 404);
    const target = String(ctx.body.statut || '');
    const motif = String(ctx.body.motif || '').trim();
    const allowed = DOSSIER_TRANSITIONS[d.statut] || [];
    if (!allowed.includes(target)) {
      ctx.flash('error', `Transition impossible : ${DOSSIER_STATUTS[d.statut]} → ${DOSSIER_STATUTS[target] || target}.`);
      return ctx.redirect(`/dossiers/${d.id}`);
    }
    const required = (target === '06' || target === '14') ? 'dossiers.validate' : (target === '07' || target === '08') ? 'dossiers.notify' : 'dossiers.edit';
    if (!can(ctx.user, required)) {
      ctx.flash('error', 'Votre profil ne dispose pas du droit requis pour cette transition.');
      return ctx.redirect(`/dossiers/${d.id}`);
    }
    if (['14', '15', '16'].includes(target) && !motif) {
      ctx.flash('error', 'Un motif est obligatoire pour rejeter, annuler ou suspendre un dossier.');
      return ctx.redirect(`/dossiers/${d.id}`);
    }
    const totals = refreshDossierTotals(d.id);
    if (['10', '11'].includes(target) && Number(totals.montant_paye) <= 0) {
      ctx.flash('error', 'Aucun paiement rapproché : enregistrez d’abord un paiement.');
      return ctx.redirect(`/dossiers/${d.id}`);
    }
    if (target === '13' && Number(totals.montant_du) > TOL()) {
      ctx.flash('error', `Apurement impossible : reste dû ${money(totals.montant_du)}.`);
      return ctx.redirect(`/dossiers/${d.id}`);
    }
    let notification = one('SELECT * FROM notifications WHERE dossier_id = ? ORDER BY id DESC LIMIT 1', d.id);
    if (target === '08' && !notification) {
      ctx.flash('error', 'Établissez d’abord la notification (statut 07).');
      return ctx.redirect(`/dossiers/${d.id}`);
    }
    if (target === '07' && !notification) {
      const ref = nextReference('NOT');
      run(
        `INSERT INTO notifications (reference, dossier_id, destinataire_type, destinataire_id, destinataire_nom, montant_du, mode, statut, relances, created_at)
         VALUES (?,?,?,?,?,?,?, 'Préparée', 0, ?)`,
        ref, d.id, d.assure_id ? 'Assuré' : 'Organisme cotisant', d.assure_id || d.organisme_id,
        d.assure_id ? `${d.assure_nom || ''} ${d.assure_prenom || ''}`.trim() : (d.organisme_nom || ''),
        Number(totals.montant_du), getParam('MODE_NOTIFICATION', 'Courrier'), nowStamp()
      );
      notification = one('SELECT * FROM notifications WHERE reference = ?', ref);
    }
    if (target === '08' && notification) {
      run("UPDATE notifications SET statut = 'Transmise', date_notification = COALESCE(date_notification, ?) WHERE id = ?", todayISO(), notification.id);
    }
    const now = nowStamp();
    let pieceName = d.piece || '';
    const stored = storePiece(ctx.files?.piece, { entite: 'dossier', entiteId: d.id, userId: ctx.user.id });
    if (stored) pieceName = stored;
    run('UPDATE dossiers SET statut = ?, updated_at = ?, piece = ? WHERE id = ?', target, now, pieceName, d.id);
    run('INSERT INTO dossier_etapes (dossier_id, statut, date, user_id, commentaire) VALUES (?,?,?,?,?)',
      d.id, target, now, ctx.user.id, motif || `Passage au statut ${DOSSIER_STATUTS[target]}`);
    audit(ctx.user, 'Dossier', d.id, 'Changement de statut', DOSSIER_STATUTS[d.statut], DOSSIER_STATUTS[target], motif, stored);
    rebuildComptes();
    if (target === '13') {
      for (const n of q("SELECT * FROM notifications WHERE dossier_id = ? AND statut <> 'Reçue'", d.id)) {
        run("UPDATE notifications SET statut = 'Reçue', date_reception = COALESCE(date_reception, ?) WHERE id = ?", todayISO(), n.id);
      }
    }
    ctx.flash('success', `Dossier ${d.reference} : ${DOSSIER_STATUTS[d.statut]} → ${DOSSIER_STATUTS[target]}.`);
    ctx.redirect(`/dossiers/${d.id}`);
  });

  // ---------------- Notifications ----------------
  router.get('/notifications', 'view', (ctx) => {
    const f = { q: String(ctx.query.q || '').trim(), statut: String(ctx.query.statut || ''), organisme: String(ctx.query.organisme || '') };
    const page = int(ctx.query.page, 1);
    const where = []; const params = [];
    if (f.q) {
      where.push('(n.reference LIKE ? OR d.reference LIKE ? OR a.nom LIKE ? OR a.matricule LIKE ?)');
      const t = `%${f.q}%`; params.push(t, t, t, t);
    }
    if (f.statut) { where.push('n.statut = ?'); params.push(f.statut); }
    if (f.organisme) { where.push('d.organisme_id = ?'); params.push(Number(f.organisme)); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const from = `FROM notifications n JOIN dossiers d ON d.id = n.dossier_id LEFT JOIN assures a ON a.id = d.assure_id`;
    const total = one(`SELECT COUNT(*) AS n ${from} ${w}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(
      `SELECT n.*, d.reference AS dossier_ref, d.montant_du, d.statut AS dossier_statut, a.nom AS assure_nom, a.prenom AS assure_prenom, a.matricule
       ${from} ${w} ORDER BY n.id DESC LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(n => [
      td(`<a class="main-cell mono" href="/notifications/${n.id}">${esc(n.reference)}</a><span class="sub">${n.assure_nom ? esc(`${n.assure_nom} ${n.assure_prenom}`) : esc(n.destinataire_nom || 'Organisme')}</span>`),
      td(dossierLink(n.dossier_id, n.dossier_ref)),
      td(money(n.montant_du), 'num'),
      td(fmtDate(n.date_notification)),
      td(fmtDate(n.date_reception)),
      td(String(n.relances || 0), 'num'),
      td(genericBadge(n.statut)),
      td(`<a class="btn xs" href="/notifications/${n.id}">Ouvrir</a>`, 'actions')
    ]);
    const counts = one(`SELECT COUNT(*) AS total,
      SUM(CASE WHEN statut = 'Préparée' THEN 1 ELSE 0 END) AS preparees,
      SUM(CASE WHEN statut = 'Transmise' THEN 1 ELSE 0 END) AS transmises,
      SUM(CASE WHEN statut = 'Reçue' THEN 1 ELSE 0 END) AS recues,
      COALESCE(SUM(CASE WHEN statut <> 'Reçue' THEN montant_du ELSE 0 END),0) AS montant FROM notifications`);
    const content = `
      ${pageHead('Notifications', 'Édition, transmission et suivi des notifications de soldes aux assurés et organismes.', '', ['Module 14', 'Notifications'])}
      <div class="stats">
        ${statCard({ label: 'Notifications préparées', value: counts.preparees || 0, hint: 'À transmettre', tone: 'warn', iconName: 'file' })}
        ${statCard({ label: 'Notifications transmises', value: counts.transmises || 0, hint: 'En attente de réception', tone: 'info', iconName: 'bell' })}
        ${statCard({ label: 'Notifications reçues', value: counts.recues || 0, hint: 'Accusé de réception', tone: 'ok', iconName: 'check' })}
        ${statCard({ label: 'Montant notifié', value: money(counts.montant), hint: 'Non encore reçu', tone: 'bad', iconName: 'wallet' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/notifications">
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(f.q)}" placeholder="Référence, dossier, assuré"></div>
          <div class="field"><label>Organisme</label><select name="organisme"><option value="">Tous</option>${orgOptions(f.organisme)}</select></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Préparée', 'Transmise', 'Reçue'].map(s => `<option ${f.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/notifications">Réinitialiser</a>
        </form>
        ${dataTable(['Notification', 'Dossier', 'Montant dû', 'Émise le', 'Reçue le', 'Relances', 'Statut', ''], trs, { empty: 'Aucune notification. Le circuit des dossiers en génère automatiquement.' })}
        ${pagination(p, '/notifications', f)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Notifications', '/notifications', content, ['Module 14', 'Notifications']));
  });

  router.get('/notifications/:id', 'view', (ctx) => {
    const n = one('SELECT * FROM notifications WHERE id = ?', Number(ctx.params.id));
    if (!n) return ctx.send('<h1>Notification introuvable</h1>', 404);
    const d = getDossier(n.dossier_id);
    const mode = getParam('MODE_NOTIFICATION', 'Courrier');
    const actions = can(ctx.user, 'dossiers.notify') ? `
      ${n.statut === 'Préparée' ? `<form method="post" action="/notifications/${n.id}/action" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="action" value="transmettre"><button class="btn primary" type="submit">Transmettre</button></form>` : ''}
      ${n.statut === 'Transmise' ? `<form method="post" action="/notifications/${n.id}/action" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="action" value="reception"><button class="btn primary" type="submit">Accuser réception</button></form>` : ''}
      ${n.statut !== 'Reçue' ? `<form method="post" action="/notifications/${n.id}/action" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="action" value="relancer"><button class="btn" type="submit">Relancer</button></form>` : ''}
    ` : '';
    const content = `
      ${pageHead(`Notification ${n.reference}`, d ? `Dossier ${d.reference} · ${d.assure_nom ? `${d.assure_nom} ${d.assure_prenom}` : d.organisme_nom}` : '', `${actions}<button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 14', 'Notifications', n.reference])}
      <div class="stats">
        ${statCard({ label: 'Montant notifié', value: money(n.montant_du), hint: 'Solde à régler', tone: 'bad', iconName: 'wallet' })}
        ${statCard({ label: 'Statut', value: genericBadge(n.statut), hint: `Mode : ${esc(n.mode || mode)}`, tone: 'info', iconName: 'bell' })}
        ${statCard({ label: 'Émise le', value: fmtDate(n.date_notification), hint: 'Date de transmission', iconName: 'clock' })}
        ${statCard({ label: 'Relances', value: n.relances || 0, hint: n.derniere_relance ? `Dernière : ${fmtDate(n.derniere_relance)}` : 'Aucune relance', tone: 'warn', iconName: 'refresh' })}
      </div>
      <div class="grid grid-2">
        ${card(`<dl class="dl tight">
          <dt>Référence</dt><dd class="mono">${esc(n.reference)}</dd>
          <dt>Dossier</dt><dd>${d ? `<a href="/dossiers/${d.id}" class="mono">${esc(d.reference)}</a>` : '—'}</dd>
          <dt>Destinataire</dt><dd>${esc(n.destinataire_nom || '—')} <span class="muted">(${esc(n.destinataire_type || '—')})</span></dd>
          <dt>Montant dû</dt><dd class="strong">${money(n.montant_du)}</dd>
          <dt>Mode</dt><dd>${esc(n.mode || mode)}</dd>
          <dt>Préparée le</dt><dd>${fmtDateTime(n.created_at)}</dd>
          <dt>Transmise le</dt><dd>${fmtDate(n.date_notification)}</dd>
          <dt>Reçue le</dt><dd>${fmtDate(n.date_reception)}</dd>
          <dt>Statut</dt><dd>${genericBadge(n.statut)}</dd>
        </dl>`, { title: 'Suivi de la notification' })}
        ${card(`
          <div class="notice-sheet">
            <div class="notice-head"><strong>CAISSE DE RETRAITES DU TOGO</strong><span>Direction de l'Immatriculation et du Recouvrement</span></div>
            <h3>Notification de solde — ${esc(n.reference)}</h3>
            <p>À l'attention de : <strong>${esc(n.destinataire_nom || '—')}</strong></p>
            <p>${d ? `Conformément au contrôle du dossier <span class="mono">${esc(d.reference)}</span>, le montant restant dû au titre de la période <strong>${esc(monthLabel(d.periode_debut))}${d.periode_fin && d.periode_fin !== d.periode_debut ? ` → ${esc(monthLabel(d.periode_fin))}` : ''}</strong> s'élève à :` : 'Le montant restant dû s’élève à :'}</p>
            <div class="notice-amount">${money(n.montant_du)}</div>
            <p>Vous êtes invité(e) à procéder au règlement dans un délai de trente (30) jours à compter de la réception de la présente notification.</p>
            <p class="muted">${esc(mode)} — ${fmtDate(n.date_notification || todayISO())}</p>
          </div>
          <div class="form-actions mt16"><a class="btn" href="/dossiers/${n.dossier_id}">Voir le dossier</a>${d && d.assure_id ? `<a class="btn" href="/comptes/assures/${d.assure_id}">Compte de l'assuré</a>` : ''}</div>`, { title: 'Modèle de notification' })}
      </div>`;
    ctx.send(ctx.page(`Notification ${n.reference}`, '/notifications', content, ['Module 14', 'Notifications', n.reference]));
  });

  router.post('/notifications/:id/action', 'dossiers.notify', (ctx) => {
    const n = one('SELECT * FROM notifications WHERE id = ?', Number(ctx.params.id));
    if (!n) return ctx.send('<h1>Notification introuvable</h1>', 404);
    const d = one('SELECT * FROM dossiers WHERE id = ?', n.dossier_id);
    const action = ctx.body.action;
    if (action === 'transmettre') {
      run("UPDATE notifications SET statut = 'Transmise', date_notification = COALESCE(date_notification, ?) WHERE id = ?", todayISO(), n.id);
      if (d && ['06', '07'].includes(d.statut)) {
        run("UPDATE dossiers SET statut = '08', updated_at = ? WHERE id = ?", nowStamp(), d.id);
        run('INSERT INTO dossier_etapes (dossier_id, statut, date, user_id, commentaire) VALUES (?,?,?,?,?)', d.id, '08', nowStamp(), ctx.user.id, `Notification ${n.reference} transmise`);
        rebuildComptes();
      }
      audit(ctx.user, 'Notification', n.id, 'Transmission', n.statut, 'Transmise');
      ctx.flash('success', `Notification ${n.reference} transmise.`);
    } else if (action === 'reception') {
      run("UPDATE notifications SET statut = 'Reçue', date_reception = ? WHERE id = ?", todayISO(), n.id);
      if (d && ['07', '08'].includes(d.statut)) {
        run("UPDATE dossiers SET statut = '09', updated_at = ? WHERE id = ?", nowStamp(), d.id);
        run('INSERT INTO dossier_etapes (dossier_id, statut, date, user_id, commentaire) VALUES (?,?,?,?,?)', d.id, '09', nowStamp(), ctx.user.id, `Accusé de réception de ${n.reference}`);
        rebuildComptes();
      }
      audit(ctx.user, 'Notification', n.id, 'Réception', n.statut, 'Reçue');
      ctx.flash('success', `Réception de la notification ${n.reference} enregistrée.`);
    } else if (action === 'relancer') {
      run("UPDATE notifications SET relances = COALESCE(relances,0) + 1, derniere_relance = ?, statut = CASE WHEN statut = 'Préparée' THEN 'Transmise' ELSE statut END WHERE id = ?", todayISO(), n.id);
      audit(ctx.user, 'Notification', n.id, 'Relance', n.relances || 0, Number(n.relances || 0) + 1);
      ctx.flash('success', `Relance n°${Number(n.relances || 0) + 1} enregistrée.`);
    }
    ctx.redirect(`/notifications/${n.id}`);
  });

  // ---------------- Recouvrement ----------------
  router.get('/recouvrement', 'view', (ctx) => {
    const stats = one(`SELECT
      COALESCE(SUM(montant_du),0) AS du,
      COALESCE(SUM(montant_paye),0) AS paye,
      COALESCE(SUM(montant_theorique),0) AS theorique,
      COUNT(*) AS nb
      FROM dossiers WHERE statut IN ${RECOUVREMENT}`);
    const notifies = one("SELECT COUNT(*) AS n, COALESCE(SUM(montant_du),0) AS m FROM notifications WHERE statut <> 'Reçue'");
    const recouvre = Number(stats.du) + Number(stats.paye) > 0
      ? Math.round(Number(stats.paye) / (Number(stats.du) + Number(stats.paye)) * 100) : 0;
    const byOrg = q(`SELECT o.id, o.code, o.sigle, o.nom,
        COUNT(d.id) AS nb,
        COALESCE(SUM(d.montant_du),0) AS du,
        COALESCE(SUM(d.montant_paye),0) AS paye
      FROM dossiers d JOIN organismes o ON o.id = d.organisme_id
      WHERE d.statut IN ${RECOUVREMENT}
      GROUP BY o.id ORDER BY du DESC`);
    const orgRows = byOrg.map(o => {
      const total = Number(o.du) + Number(o.paye);
      const taux = total > 0 ? Math.round(Number(o.paye) / total * 100) : 0;
      return [
        td(`<a href="/organismes/${o.id}">${esc(o.sigle || o.code)}</a><span class="sub">${esc(o.nom)}</span>`),
        td(String(o.nb), 'num'),
        td(money(o.du), 'num'),
        td(money(o.paye), 'num'),
        td(`<div class="cell-progress">${progress(taux, taux >= 70 ? 'ok' : taux >= 30 ? '' : 'bad')}<span>${taux} %</span></div>`)
      ];
    });
    const dossiers = q(`SELECT d.*, a.nom AS assure_nom, a.prenom AS assure_prenom, a.matricule, o.sigle
      FROM dossiers d LEFT JOIN assures a ON a.id = d.assure_id LEFT JOIN organismes o ON o.id = d.organisme_id
      WHERE d.statut IN ${RECOUVREMENT} ORDER BY d.montant_du DESC LIMIT 20`);
    const dossierRows = dossiers.map(d => [
      td(`<a class="mono" href="/dossiers/${d.id}">${esc(d.reference)}</a><span class="sub">${esc(typeLabel(d.type))}</span>`),
      td(d.matricule ? `<a href="/assures/${d.assure_id}">${esc(d.assure_nom)} ${esc(d.assure_prenom)}</a>` : (d.sigle ? `<a href="/organismes/${d.organisme_id}">${esc(d.sigle)}</a>` : '—')),
      td(money(d.montant_du), 'num'),
      td(String(ageDays(d.updated_at || d.created_at)) + ' j', 'num'),
      td(dossierBadge(d.statut)),
      td(`<a class="btn xs" href="/dossiers/${d.id}">Traiter</a>`, 'actions')
    ]);
    const buckets = [
      { label: '0 – 30 jours', max: 30, min: 0 },
      { label: '31 – 90 jours', max: 90, min: 31 },
      { label: '91 – 180 jours', max: 180, min: 91 },
      { label: 'Plus de 180 jours', max: 99999, min: 181 }
    ].map(b => {
      const rows = q(`SELECT montant_du, created_at, updated_at FROM dossiers WHERE statut IN ${RECOUVREMENT}`);
      const inB = rows.filter(r => {
        const a = ageDays(r.updated_at || r.created_at);
        return a >= b.min && a <= b.max;
      });
      return { label: b.label, value: inB.reduce((s, r) => s + Number(r.montant_du), 0), nb: inB.length };
    });
    const aging = buckets.map(b => `
      <div class="aging-row">
        <div class="aging-top"><span>${esc(b.label)}</span><strong>${money(b.value)}</strong></div>
        ${progress(Number(stats.du) > 0 ? (b.value / Number(stats.du)) * 100 : 0, b.min >= 181 ? 'bad' : b.min >= 91 ? '' : 'ok')}
        <div class="aging-sub">${b.nb} dossier(s)</div>
      </div>`).join('');
    const content = `
      ${pageHead('Recouvrement', 'Suivi des montants notifiés, des encaissements et du reste à recouvrer.', can(ctx.user, 'recouvrement.edit') ? `<a class="btn" href="/notifications">${icon('bell', 16)} Notifications</a><a class="btn" href="/dossiers?type=Recouvrement">${icon('wallet', 16)} Dossiers de recouvrement</a>` : '', ['Module 13', 'Recouvrement'])}
      <div class="stats">
        ${statCard({ label: 'Montant sous responsabilité', value: money(stats.du), hint: `${stats.nb} dossier(s) actif(s)`, iconName: 'wallet' })}
        ${statCard({ label: 'Montant recouvré', value: money(stats.paye), hint: 'Paiements rapprochés', tone: 'ok', iconName: 'check' })}
        ${statCard({ label: 'Taux de recouvrement', value: `${recouvre} %`, hint: 'Recouvré / (dû + recouvré)', tone: recouvre >= 50 ? 'ok' : 'warn', iconName: 'chart' })}
        ${statCard({ label: 'Notifications en attente', value: notifies.n || 0, hint: money(notifies.m), tone: 'warn', iconName: 'bell' })}
      </div>
      <div class="grid grid-2">
        ${card(aging, { title: 'Ancienneté du reste dû', subtitle: 'Vieillissement des dossiers en recouvrement.' })}
        ${card(`
          <div class="kv-row"><span>Dossiers en recouvrement</span><strong>${stats.nb}</strong></div>
          <div class="kv-row"><span>Montant total reconstitué</span><strong>${money(stats.theorique)}</strong></div>
          <div class="kv-row"><span>Reste à recouvrer</span><strong class="text-danger">${money(stats.du)}</strong></div>
          <div class="kv-row"><span>Déjà encaissé</span><strong class="text-ok">${money(stats.paye)}</strong></div>
          <div class="mt16">${progress(recouvre, recouvre >= 50 ? 'ok' : '')}<div class="aging-sub">Taux global de recouvrement : ${recouvre} %</div></div>
          <div class="callout mt16">${icon('alert', 18)}<div>Les dossiers notifiés non soldés alimentent l'anomalie <strong>A12 — Solde ancien non apuré</strong> à chaque exécution des contrôles.</div></div>`, { title: 'Synthèse' })}
      </div>
      ${card(dataTable(['Organisme', 'Dossiers', 'Reste dû', 'Recouvré', 'Taux'], orgRows, { empty: 'Aucun organisme en recouvrement.' }), { title: 'Recouvrement par organisme', bodyClass: 'flush' })}
      ${card(dataTable(['Dossier', 'Assuré / organisme', 'Reste dû', 'Ancienneté', 'Statut', ''], dossierRows, { empty: 'Aucun dossier en recouvrement.' }), { title: 'Dossiers prioritaires', subtitle: 'Classés par montant restant dû.', bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Recouvrement', '/recouvrement', content, ['Module 13', 'Recouvrement']));
  });

  // ---------------- Comptes ----------------
  router.get('/comptes', 'view', (ctx) => {
    const f = { q: String(ctx.query.q || '').trim(), compte: String(ctx.query.compte || 'assures') };
    const totals = one(`SELECT COALESCE(SUM(debit),0) AS debit, COALESCE(SUM(credit),0) AS credit FROM mouvements`);
    const soldeGlobal = Number(totals.debit) - Number(totals.credit);
    const nbAssures = one(`SELECT COUNT(*) AS n FROM (SELECT assure_id FROM mouvements WHERE compte_type='assure' GROUP BY assure_id HAVING SUM(debit)-SUM(credit) > 1)`).n;
    const nbCotisants = one(`SELECT COUNT(*) AS n FROM (SELECT organisme_id FROM mouvements WHERE compte_type='cotisant' GROUP BY organisme_id HAVING SUM(debit)-SUM(credit) > 1)`).n;
    const where = ["m.compte_type = 'assure'"]; const params = [];
    if (f.q) { where.push('(a.matricule LIKE ? OR a.nom LIKE ? OR a.prenom LIKE ?)'); const t = `%${f.q}%`; params.push(t, t, t); }
    const assureRows = q(`SELECT a.id, a.matricule, a.nom, a.prenom, a.statut,
        COALESCE(SUM(m.debit),0) AS debit, COALESCE(SUM(m.credit),0) AS credit
      FROM assures a JOIN mouvements m ON m.assure_id = a.id AND m.compte_type = 'assure'
      WHERE ${where.join(' AND ')} GROUP BY a.id ORDER BY COALESCE(SUM(m.debit),0)-COALESCE(SUM(m.credit),0) DESC LIMIT 50`, ...params);
    const cotisantRows = q(`SELECT o.id, o.code, o.sigle, o.nom,
        COALESCE(SUM(m.debit),0) AS debit, COALESCE(SUM(m.credit),0) AS credit
      FROM organismes o JOIN mouvements m ON m.organisme_id = o.id AND m.compte_type = 'cotisant'
      GROUP BY o.id ORDER BY COALESCE(SUM(m.debit),0)-COALESCE(SUM(m.credit),0) DESC`);
    const assureTrs = assureRows.map(a => {
      const solde = Number(a.debit) - Number(a.credit);
      return [
        td(`<a class="mono" href="/comptes/assures/${a.id}">${esc(a.matricule)}</a>`),
        td(`<a href="/assures/${a.id}">${esc(a.nom)} ${esc(a.prenom)}</a>`),
        td(money(a.debit), 'num'),
        td(money(a.credit), 'num'),
        td(`<span class="${solde > 1 ? 'text-danger' : solde < -1 ? 'text-ok' : ''}">${money(solde)}</span>`, 'num'),
        td(`<a class="btn xs" href="/comptes/assures/${a.id}">Compte</a>`, 'actions')
      ];
    });
    const cotisantTrs = cotisantRows.map(o => {
      const solde = Number(o.debit) - Number(o.credit);
      return [
        td(`<a href="/comptes/cotisants/${o.id}">${esc(o.sigle || o.code)}</a><span class="sub">${esc(o.nom)}</span>`),
        td(money(o.debit), 'num'),
        td(money(o.credit), 'num'),
        td(`<span class="${solde > 1 ? 'text-danger' : solde < -1 ? 'text-ok' : ''}">${money(solde)}</span>`, 'num'),
        td(`<a class="btn xs" href="/comptes/cotisants/${o.id}">Compte</a>`, 'actions')
      ];
    });
    const content = `
      ${pageHead('Comptes assurés et cotisants', 'Présentation unique en mouvements : débit, crédit et solde.', '', ['Module 15', 'Comptes'])}
      <div class="stats">
        ${statCard({ label: 'Total débits', value: money(totals.debit), hint: 'Cotisations et régularisations', iconName: 'file' })}
        ${statCard({ label: 'Total crédits', value: money(totals.credit), hint: 'Paiements rapprochés', tone: 'ok', iconName: 'wallet' })}
        ${statCard({ label: 'Solde global', value: money(soldeGlobal), hint: soldeGlobal > 0 ? 'Reste à recouvrer' : 'Comptes créditeurs', tone: soldeGlobal > 0 ? 'bad' : 'ok', iconName: 'calc' })}
        ${statCard({ label: 'Comptes débiteurs', value: `${nbAssures} assurés / ${nbCotisants} cotisants`, hint: 'Solde strictement positif', tone: 'warn', iconName: 'users' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/comptes">
          <div class="field grow search-input"><label>Rechercher un assuré</label><span>${icon('search', 15)}</span><input name="q" value="${esc(f.q)}" placeholder="Matricule, nom ou prénom"></div>
          <button class="btn" type="submit">Rechercher</button>
          <a class="btn" href="/comptes">Réinitialiser</a>
        </form>
        <div class="section-title">Comptes individuels assurés</div>
        ${dataTable(['Matricule', 'Assuré', 'Débit', 'Crédit', 'Solde', ''], assureTrs, { empty: 'Aucun mouvement de compte assuré. Validez des déclarations pour alimenter les comptes.' })}
        <div class="section-title mt24">Comptes cotisants</div>
        ${dataTable(['Organisme', 'Débit', 'Crédit', 'Solde', ''], cotisantTrs, { empty: 'Aucun mouvement de compte cotisant.' })}
      `, { bodyClass: '' })}`;
    ctx.send(ctx.page('Comptes', '/comptes', content, ['Module 15', 'Comptes']));
  });

  router.get('/comptes/assures/:id', 'view', (ctx) => {
    const a = one('SELECT a.*, o.nom AS organisme_nom, o.sigle FROM assures a LEFT JOIN organismes o ON o.id = a.organisme_id WHERE a.id = ?', Number(ctx.params.id));
    if (!a) return ctx.send('<h1>Assuré introuvable</h1>', 404);
    const from = String(ctx.query.from || '');
    const to = String(ctx.query.to || '');
    const c = compteAssure(a.id, { from, to });
    const rows = c.rows.map(m => [
      td(fmtDate(m.date_mouvement)),
      td(`${esc(m.libelle || '—')}${m.reference ? `<span class="sub mono">${esc(m.reference)}</span>` : ''}`),
      td(esc(m.origine || '—')),
      td(m.debit ? money(m.debit) : '—', 'num'),
      td(m.credit ? money(m.credit) : '—', 'num'),
      td(`<span class="${m.solde > 1 ? 'text-danger' : m.solde < -1 ? 'text-ok' : ''}">${money(m.solde)}</span>`, 'num'),
      td(m.periode ? `<a class="btn xs" href="/expliquer?assure_id=${a.id}&periode=${esc(m.periode)}">Expliquer</a>` : '', 'actions')
    ]);
    const content = `
      ${pageHead(`Compte assuré — ${a.nom} ${a.prenom}`, `${a.matricule} · ${a.organisme_nom || 'Sans organisme'}`, `<a class="btn" href="/assures/${a.id}">${icon('users', 15)} Fiche assuré</a><button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 15', 'Comptes', a.matricule])}
      <div class="stats">
        ${statCard({ label: 'Débit', value: money(c.debit), hint: 'Cotisations dues', iconName: 'file' })}
        ${statCard({ label: 'Crédit', value: money(c.credit), hint: 'Paiements imputés', tone: 'ok', iconName: 'wallet' })}
        ${statCard({ label: 'Solde', value: money(c.solde), hint: c.solde > 1 ? 'Reste à payer' : 'Compte équilibré', tone: c.solde > 1 ? 'bad' : 'ok', iconName: 'calc' })}
        ${statCard({ label: 'Mouvements', value: c.rows.length, hint: 'Lignes du grand livre', tone: 'info', iconName: 'book' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/comptes/assures/${a.id}">
          <div class="field"><label>Du</label><input type="date" name="from" value="${esc(from)}"></div>
          <div class="field"><label>Au</label><input type="date" name="to" value="${esc(to)}"></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/comptes/assures/${a.id}">Réinitialiser</a>
        </form>
        ${dataTable(['Date', 'Libellé', 'Origine', 'Débit', 'Crédit', 'Solde', ''], rows, { empty: 'Aucun mouvement sur la période.' })}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page(`Compte assuré — ${a.matricule}`, '/comptes', content, ['Module 15', 'Comptes', a.matricule]));
  });

  router.get('/comptes/cotisants/:id', 'view', (ctx) => {
    const o = one('SELECT * FROM organismes WHERE id = ?', Number(ctx.params.id));
    if (!o) return ctx.send('<h1>Organisme introuvable</h1>', 404);
    const from = String(ctx.query.from || '');
    const to = String(ctx.query.to || '');
    const c = compteCotisant(o.id, { from, to });
    const rows = c.rows.map(m => [
      td(fmtDate(m.date_mouvement)),
      td(`${esc(m.libelle || '—')}${m.reference ? `<span class="sub mono">${esc(m.reference)}</span>` : ''}`),
      td(esc(m.origine || '—')),
      td(m.debit ? money(m.debit) : '—', 'num'),
      td(m.credit ? money(m.credit) : '—', 'num'),
      td(`<span class="${m.solde > 1 ? 'text-danger' : m.solde < -1 ? 'text-ok' : ''}">${money(m.solde)}</span>`, 'num')
    ]);
    const content = `
      ${pageHead(`Compte cotisant — ${o.sigle || o.code}`, o.nom, `<a class="btn" href="/organismes/${o.id}">${icon('building', 15)} Fiche organisme</a><button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 15', 'Comptes', o.sigle || o.code])}
      <div class="stats">
        ${statCard({ label: 'Débit', value: money(c.debit), hint: 'Déclarations validées', iconName: 'file' })}
        ${statCard({ label: 'Crédit', value: money(c.credit), hint: 'Paiements rapprochés', tone: 'ok', iconName: 'wallet' })}
        ${statCard({ label: 'Solde', value: money(c.solde), hint: c.solde > 1 ? 'Reste à payer' : 'Compte équilibré', tone: c.solde > 1 ? 'bad' : 'ok', iconName: 'calc' })}
        ${statCard({ label: 'Mouvements', value: c.rows.length, hint: 'Lignes du grand livre', tone: 'info', iconName: 'book' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/comptes/cotisants/${o.id}">
          <div class="field"><label>Du</label><input type="date" name="from" value="${esc(from)}"></div>
          <div class="field"><label>Au</label><input type="date" name="to" value="${esc(to)}"></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/comptes/cotisants/${o.id}">Réinitialiser</a>
        </form>
        ${dataTable(['Date', 'Libellé', 'Origine', 'Débit', 'Crédit', 'Solde'], rows, { empty: 'Aucun mouvement sur la période.' })}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page(`Compte cotisant — ${o.sigle || o.code}`, '/comptes', content, ['Module 15', 'Comptes', o.sigle || o.code]));
  });

  // ---------------- Expliquer l'écart ----------------
  router.get('/expliquer', 'view', (ctx) => {
    let assureId = int(ctx.query.assure_id, 0);
    const dossierId = int(ctx.query.dossier_id, 0);
    let periode = /^\d{4}-\d{2}$/.test(String(ctx.query.periode || '')) ? String(ctx.query.periode) : '';
    const matricule = String(ctx.query.matricule || '').trim();
    if (!assureId && matricule) {
      const a = one('SELECT id FROM assures WHERE matricule = ?', matricule);
      assureId = a?.id || 0;
    }
    if (!assureId && !dossierId) {
      const content = `
        ${pageHead("Expliquer l'écart", 'Décomposition d’un écart constaté entre montant théorique, déclaré et payé.', '', ['Fonction transverse', "Expliquer l'écart"])}
        <div class="grid grid-2">
          ${card(`<form method="get" action="/expliquer" class="form-grid one">
            <div class="field"><label>Matricule de l'assuré <span class="req">*</span></label><input name="matricule" required placeholder="FP-000001"></div>
            <div class="field"><label>Période analysée</label><input type="month" name="periode" value="${esc(periode || new Date().toISOString().slice(0, 7))}"></div>
            <div class="form-actions"><button class="btn primary" type="submit">Expliquer l'écart</button></div>
          </form>`, { title: 'Recherche par assuré' })}
          ${card(`<div class="help-box"><b>La fonction « Expliquer l'écart »</b><br>Elle décompose chaque montant : base de calcul, indice et valeur indiciaire applicables, taux, montant théorique, montant déclaré, paiements imputés et reste dû. Elle relie le constat au dossier, à la notification et aux mouvements de compte.</div>
          <div class="mt16"><a class="btn" href="/controles">Ouvrir le centre de contrôle</a></div>`, { title: 'À quoi ça sert ?' })}
        </div>`;
      return ctx.send(ctx.page("Expliquer l'écart", '/controles', content, ['Fonction transverse', "Expliquer l'écart"]));
    }
    if (dossierId) {
      const d = one('SELECT * FROM dossiers WHERE id = ?', dossierId);
      if (d) { assureId = d.assure_id; periode = periode || d.periode_debut; }
    }
    if (!periode) {
      ctx.flash('error', 'Sélectionnez une période pour la décomposition.');
      return ctx.redirect(assureId ? `/comptes/assures/${assureId}` : '/expliquer');
    }
    const ex = expliquer({ assureId, periode, dossierId });
    if (!ex) return ctx.send('<h1>Assuré introuvable</h1>', 404);
    const c = ex.calc || { indice: 0, valeur: 0, base: 0, taux: Number(getParam('TAUX_COTISATION', '0.125')), theorique: 0, motif: '', sourceValeur: '', indice_source: null };
    const dossier = ex.dossier;
    const formula = `
      <div class="formula">
        <div class="formula-step"><span>Base de calcul</span><strong>${c.indice} × ${money(c.valeur, false)}</strong><small>Indice × valeur indiciaire</small></div>
        <div class="formula-op">×</div>
        <div class="formula-step"><span>Taux applicable</span><strong>${(Number(c.taux) * 100).toFixed(2)} %</strong><small>Paramètre TAUX_COTISATION</small></div>
        <div class="formula-op">=</div>
        <div class="formula-step highlight"><span>Cotisation théorique</span><strong>${money(c.theorique)}</strong><small>${esc(monthLabel(periode))}</small></div>
      </div>
      <div class="formula">
        <div class="formula-step"><span>Théorique</span><strong>${money(c.theorique)}</strong></div>
        <div class="formula-op">−</div>
        <div class="formula-step"><span>Déclaré</span><strong>${money(ex.declared.montant)}</strong></div>
        <div class="formula-op">=</div>
        <div class="formula-step ${ex.ecart > 0 ? 'bad' : 'ok'}"><span>Écart à régulariser</span><strong>${money(Math.max(0, ex.ecart))}</strong></div>
      </div>
      <div class="formula">
        <div class="formula-step"><span>Total dû</span><strong>${money(c.theorique)}</strong></div>
        <div class="formula-op">−</div>
        <div class="formula-step"><span>Déjà payé</span><strong>${money(ex.paye)}</strong></div>
        <div class="formula-op">=</div>
        <div class="formula-step ${ex.reste > 0 ? 'bad' : 'ok'}"><span>Reste à payer</span><strong>${money(ex.reste)}</strong></div>
      </div>`;
    const declRows = ex.declarations.map(d => [
      td(d.reference ? `<span class="mono">${esc(d.reference)}</span>` : '—'),
      td(monthLabel(d.periode)),
      td(money(d.montant), 'num'),
      td(genericBadge(d.statut))
    ]);
    const payRows = ex.paiements.map(p => [
      td(`<a class="mono" href="/paiements/${p.id}">${esc(p.reference)}</a>`),
      td(fmtDate(p.date_paiement)),
      td(money(p.montant), 'num'),
      td(genericBadge(p.statut))
    ]);
    const content = `
      ${pageHead("Expliquer l'écart", `${ex.assure.nom} ${ex.assure.prenom} (${ex.assure.matricule}) · ${monthLabel(periode)}`, `<a class="btn" href="/assures/${ex.assure.id}">Fiche assuré</a><button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Fonction transverse', "Expliquer l'écart"])}
      <div class="stats">
        ${statCard({ label: 'Cotisation théorique', value: money(c.theorique), hint: c.suspendu ? esc(c.motif) : `${c.indice} × ${money(c.valeur, false)} × ${(Number(c.taux) * 100).toFixed(2)} %`, tone: 'info', iconName: 'calc' })}
        ${statCard({ label: 'Montant déclaré', value: money(ex.declared.montant), hint: `${ex.declared.nb} déclaration(s)`, iconName: 'file' })}
        ${statCard({ label: 'Écart théorique', value: money(Math.max(0, ex.ecart)), hint: ex.ecart > 0 ? 'À régulariser' : 'Aucun écart', tone: ex.ecart > 0 ? 'bad' : 'ok', iconName: 'alert' })}
        ${statCard({ label: 'Reste à payer', value: money(ex.reste), hint: `Payé : ${money(ex.paye)}`, tone: ex.reste > 0 ? 'warn' : 'ok', iconName: 'wallet' })}
      </div>
      ${card(formula, { title: 'Décomposition du calcul', subtitle: c.motif ? `Observation : ${esc(c.motif)}` : 'Formule appliquée à la période analysée.' })}
      <div class="grid grid-2">
        ${card(`<dl class="dl tight">
          <dt>Indice retenu</dt><dd>${c.indice}${c.indice_source ? ` <span class="muted">(événement de carrière n°${c.indice_source.id} du ${fmtDate(c.indice_source.date_debut)})</span>` : ''}</dd>
          <dt>Valeur indiciaire</dt><dd>${money(c.valeur)} <span class="muted">— ${esc(c.sourceValeur)}</span></dd>
          <dt>Base de calcul</dt><dd>${money(c.base)}</dd>
          <dt>Taux applicable</dt><dd>${(Number(c.taux) * 100).toFixed(2)} %</dd>
          <dt>Période</dt><dd>${esc(monthLabel(periode))}</dd>
          <dt>Position</dt><dd>${esc(ex.assure.position || 'Actif')}${c.suspendu ? ' — suspension de solde' : ''}</dd>
          <dt>Dossier lié</dt><dd>${dossier ? `<a class="mono" href="/dossiers/${dossier.id}">${esc(dossier.reference)}</a> ${dossierBadge(dossier.statut)}` : '—'}</dd>
          <dt>Notification</dt><dd>${ex.notification ? `<a class="mono" href="/notifications/${ex.notification.id}">${esc(ex.notification.reference)}</a> ${genericBadge(ex.notification.statut)}` : '—'}</dd>
        </dl>`, { title: 'Paramètres du calcul' })}
        ${card(`
          ${dossier ? `<div class="kv-row"><span>Type de dossier</span><strong>${esc(typeLabel(dossier.type))}</strong></div>
          <div class="kv-row"><span>Montant théorique du dossier</span><strong>${money(dossier.montant_theorique)}</strong></div>
          <div class="kv-row"><span>Montant déclaré</span><strong>${money(dossier.montant_declare)}</strong></div>
          <div class="kv-row"><span>Montant payé</span><strong>${money(dossier.montant_paye)}</strong></div>
          <div class="kv-row"><span>Reste dû</span><strong>${money(dossier.montant_du)}</strong></div>` : '<div class="empty"><p>Aucun dossier de régularisation pour cette période.</p></div>'}
          <div class="mt16"><a class="btn" href="/assures/${ex.assure.id}">Consulter la carrière</a></div>`, { title: 'Dossier et recouvrement' })}
      </div>
      ${card(dataTable(['Déclaration', 'Période', 'Montant', 'Statut'], declRows, { empty: 'Aucune ligne de déclaration pour cette période.' }), { title: 'Déclarations rattachées', bodyClass: 'flush' })}
      ${card(dataTable(['Paiement', 'Date', 'Montant', 'Statut'], payRows, { empty: 'Aucun paiement rattaché à cette période.' }), { title: 'Paiements rattachés', bodyClass: 'flush' })}`;
    ctx.send(ctx.page("Expliquer l'écart", '/controles', content, ['Fonction transverse', "Expliquer l'écart"]));
  });
}
