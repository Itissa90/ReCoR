import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { nowStamp } from './util.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(__dirname, '..');
export const DATA_DIR = path.join(ROOT, 'data');
export const PIECES_DIR = path.join(DATA_DIR, 'pieces');
fs.mkdirSync(PIECES_DIR, { recursive: true });

export const DB_PATH = path.join(DATA_DIR, 'recor.db');
export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

export function q(sql, ...params) {
  return db.prepare(sql).all(...params.map(norm));
}
export function one(sql, ...params) {
  return db.prepare(sql).get(...params.map(norm));
}
export function run(sql, ...params) {
  return db.prepare(sql).run(...params.map(norm));
}
function norm(v) {
  if (v === undefined || v === null) return null;
  if (typeof v === 'boolean') return v ? 1 : 0;
  return v;
}

export function tx(fn) {
  db.exec('BEGIN');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (e) {
    db.exec('ROLLBACK');
    throw e;
  }
}

export function audit(user, entite, entiteId, action, ancienne, nouvelle, motif = '', piece = '', ip = '') {
  run(
    `INSERT INTO audit_log (user_id, user_nom, date_action, entite, entite_id, action, ancienne_valeur, nouvelle_valeur, motif, piece, adresse_ip)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    user?.id || null, user?.nom || 'Système', nowStamp(), entite, String(entiteId ?? ''), action,
    typeof ancienne === 'object' ? JSON.stringify(ancienne) : (ancienne ?? '').toString(),
    typeof nouvelle === 'object' ? JSON.stringify(nouvelle) : (nouvelle ?? '').toString(),
    motif, piece, ip
  );
}

export function nextReference(prefix) {
  const year = new Date().getFullYear();
  const key = `${prefix}-${year}`;
  const existing = one('SELECT value FROM sequences WHERE prefix = ?', key);
  let value;
  if (existing) {
    value = Number(existing.value) + 1;
    run('UPDATE sequences SET value = ? WHERE prefix = ?', value, key);
  } else {
    value = 1;
    run('INSERT INTO sequences (prefix, value) VALUES (?, ?)', key, value);
  }
  return `${key}-${String(value).padStart(5, '0')}`;
}

export function getParam(cle, def = '') {
  const row = one('SELECT valeur FROM parametres WHERE cle = ?', cle);
  return row ? row.valeur : def;
}

export function setParam(cle, valeur) {
  const row = one('SELECT cle FROM parametres WHERE cle = ?', cle);
  if (row) run('UPDATE parametres SET valeur = ? WHERE cle = ?', String(valeur), cle);
  else run('INSERT INTO parametres (cle, valeur, libelle, groupe) VALUES (?,?,?,?)', cle, String(valeur), cle, 'Général');
}

export function schema() {
  db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    login TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    nom TEXT NOT NULL,
    profil TEXT NOT NULL,
    email TEXT,
    telephone TEXT,
    actif INTEGER NOT NULL DEFAULT 1,
    derniere_connexion TEXT,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    csrf TEXT NOT NULL,
    created_at TEXT,
    expires_at TEXT
  );

  CREATE TABLE IF NOT EXISTS organismes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    nom TEXT NOT NULL,
    sigle TEXT,
    type TEXT,
    ville TEXT,
    email TEXT,
    telephone TEXT,
    actif INTEGER NOT NULL DEFAULT 1,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS assures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    matricule TEXT NOT NULL UNIQUE,
    nom TEXT NOT NULL,
    prenom TEXT NOT NULL,
    sexe TEXT,
    date_naissance TEXT,
    lieu_naissance TEXT,
    telephone TEXT,
    date_prise_service TEXT,
    date_nomination TEXT,
    date_titularisation TEXT,
    corps TEXT,
    categorie TEXT,
    grade TEXT,
    echelon TEXT,
    indice INTEGER,
    bonification INTEGER DEFAULT 0,
    date_retraite TEXT,
    position TEXT DEFAULT 'Actif',
    date_position TEXT,
    cessation_type TEXT,
    date_cessation TEXT,
    organisme_id INTEGER,
    statut TEXT DEFAULT 'Actif',
    observation TEXT,
    created_at TEXT,
    updated_at TEXT
  );

  CREATE TABLE IF NOT EXISTS carrieres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    assure_id INTEGER NOT NULL,
    type_evenement TEXT NOT NULL,
    motif TEXT,
    date_debut TEXT,
    date_fin TEXT,
    ancien_indice INTEGER,
    nouvel_indice INTEGER,
    valeur_indiciaire REAL,
    piece TEXT,
    statut TEXT NOT NULL DEFAULT 'Brouillon',
    created_by INTEGER,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS indices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,
    indice INTEGER NOT NULL,
    valeur_indiciaire REAL NOT NULL,
    date_debut TEXT,
    date_fin TEXT,
    categorie TEXT,
    corps TEXT,
    observation TEXT,
    statut TEXT NOT NULL DEFAULT 'Actif',
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS declarations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,
    organisme_id INTEGER NOT NULL,
    periode TEXT NOT NULL,
    date_reception TEXT,
    type_declaration TEXT DEFAULT 'Mensuelle',
    nb_assures INTEGER DEFAULT 0,
    montant_declare REAL DEFAULT 0,
    fichier_source TEXT,
    piece TEXT,
    agent_id INTEGER,
    statut TEXT NOT NULL DEFAULT 'Brouillon',
    observation TEXT,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS declaration_lignes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    declaration_id INTEGER NOT NULL,
    matricule TEXT,
    assure_id INTEGER,
    montant REAL DEFAULT 0,
    statut TEXT DEFAULT 'Conforme'
  );

  CREATE TABLE IF NOT EXISTS paiements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,
    organisme_id INTEGER NOT NULL,
    date_paiement TEXT,
    montant REAL NOT NULL,
    mode_paiement TEXT,
    reference_bancaire TEXT,
    declaration_id INTEGER,
    dossier_id INTEGER,
    piece TEXT,
    agent_id INTEGER,
    statut TEXT NOT NULL DEFAULT 'Non rapproché',
    motif TEXT,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS dossiers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,
    type TEXT NOT NULL,
    assure_id INTEGER,
    organisme_id INTEGER,
    periode_debut TEXT,
    periode_fin TEXT,
    montant_theorique REAL DEFAULT 0,
    montant_declare REAL DEFAULT 0,
    montant_paye REAL DEFAULT 0,
    montant_du REAL DEFAULT 0,
    statut TEXT NOT NULL DEFAULT '01',
    motif TEXT,
    piece TEXT,
    agent_id INTEGER,
    anomalie_id INTEGER,
    created_at TEXT,
    updated_at TEXT
  );

  CREATE TABLE IF NOT EXISTS dossier_etapes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    dossier_id INTEGER NOT NULL,
    statut TEXT NOT NULL,
    date TEXT,
    user_id INTEGER,
    commentaire TEXT
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reference TEXT NOT NULL UNIQUE,
    dossier_id INTEGER NOT NULL,
    destinataire_type TEXT,
    destinataire_id INTEGER,
    destinataire_nom TEXT,
    montant_du REAL DEFAULT 0,
    date_notification TEXT,
    date_reception TEXT,
    mode TEXT,
    statut TEXT NOT NULL DEFAULT 'Préparée',
    relances INTEGER DEFAULT 0,
    derniere_relance TEXT,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS mouvements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    compte_type TEXT NOT NULL,
    assure_id INTEGER,
    organisme_id INTEGER,
    date_mouvement TEXT,
    periode TEXT,
    libelle TEXT,
    debit REAL DEFAULT 0,
    credit REAL DEFAULT 0,
    origine TEXT,
    reference TEXT,
    statut TEXT DEFAULT 'Validé'
  );

  CREATE TABLE IF NOT EXISTS anomalies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    signature TEXT NOT NULL UNIQUE,
    code TEXT NOT NULL,
    criticite TEXT,
    libelle TEXT,
    detail TEXT,
    assure_id INTEGER,
    organisme_id INTEGER,
    declaration_id INTEGER,
    dossier_id INTEGER,
    periode TEXT,
    statut TEXT NOT NULL DEFAULT 'Nouvelle',
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS parametres (
    cle TEXT PRIMARY KEY,
    valeur TEXT,
    libelle TEXT,
    type TEXT DEFAULT 'texte',
    groupe TEXT,
    modifiable INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    user_nom TEXT,
    date_action TEXT,
    entite TEXT,
    entite_id TEXT,
    action TEXT,
    ancienne_valeur TEXT,
    nouvelle_valeur TEXT,
    motif TEXT,
    piece TEXT,
    adresse_ip TEXT
  );

  CREATE TABLE IF NOT EXISTS communications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    titre TEXT NOT NULL,
    type_support TEXT,
    destinataires TEXT,
    contenu TEXT,
    date_publication TEXT,
    statut TEXT DEFAULT 'Brouillon',
    created_by INTEGER,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS extractions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    type_etat TEXT,
    format TEXT,
    criteres TEXT,
    nb_lignes INTEGER,
    periode TEXT,
    user_id INTEGER,
    user_nom TEXT,
    date_extraction TEXT
  );

  CREATE TABLE IF NOT EXISTS pieces (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entite TEXT,
    entite_id INTEGER,
    nom_original TEXT,
    chemin TEXT,
    taille INTEGER,
    uploaded_by INTEGER,
    created_at TEXT
  );

  CREATE TABLE IF NOT EXISTS sequences (
    prefix TEXT PRIMARY KEY,
    value INTEGER NOT NULL DEFAULT 0
  );

  CREATE INDEX IF NOT EXISTS idx_assures_org ON assures(organisme_id);
  CREATE INDEX IF NOT EXISTS idx_assures_nom ON assures(nom, prenom);
  CREATE INDEX IF NOT EXISTS idx_carrieres_assure ON carrieres(assure_id, date_debut);
  CREATE INDEX IF NOT EXISTS idx_decl_org_periode ON declarations(organisme_id, periode);
  CREATE INDEX IF NOT EXISTS idx_lignes_decl ON declaration_lignes(declaration_id);
  CREATE INDEX IF NOT EXISTS idx_lignes_assure ON declaration_lignes(assure_id);
  CREATE INDEX IF NOT EXISTS idx_paiements_decl ON paiements(declaration_id);
  CREATE INDEX IF NOT EXISTS idx_paiements_dossier ON paiements(dossier_id);
  CREATE INDEX IF NOT EXISTS idx_dossiers_statut ON dossiers(statut);
  CREATE INDEX IF NOT EXISTS idx_dossiers_assure ON dossiers(assure_id);
  CREATE INDEX IF NOT EXISTS idx_mouvements_assure ON mouvements(assure_id, date_mouvement);
  CREATE INDEX IF NOT EXISTS idx_mouvements_org ON mouvements(organisme_id, date_mouvement);
  CREATE INDEX IF NOT EXISTS idx_anomalies_statut ON anomalies(statut, code);
  CREATE INDEX IF NOT EXISTS idx_audit_date ON audit_log(date_action);
  `);
}

export function isSeeded() {
  try {
    return (one('SELECT COUNT(*) AS n FROM users')?.n || 0) > 0;
  } catch {
    return false;
  }
}
