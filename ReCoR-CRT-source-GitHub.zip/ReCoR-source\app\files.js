import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { PIECES_DIR, run, q, one } from './db.js';
import { nowStamp } from './util.js';

export function storePiece(file, { entite, entiteId, userId }) {
  if (!file || !file.filename || !file.data || !file.data.length) return '';
  const ext = path.extname(file.filename).toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 10);
  const stored = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}${ext}`;
  fs.writeFileSync(path.join(PIECES_DIR, stored), file.data);
  run(
    `INSERT INTO pieces (entite, entite_id, nom_original, chemin, taille, uploaded_by, created_at)
     VALUES (?,?,?,?,?,?,?)`,
    entite, entiteId || null, file.filename, stored, file.data.length, userId || null, nowStamp()
  );
  return file.filename;
}

export function listPieces(entite, entiteId) {
  return q('SELECT * FROM pieces WHERE entite = ? AND entite_id = ? ORDER BY id DESC', entite, entiteId);
}

export function getPiece(id) {
  return one('SELECT * FROM pieces WHERE id = ?', id);
}

export function piecePath(piece) {
  if (!piece) return null;
  const p = path.join(PIECES_DIR, piece.chemin);
  return fs.existsSync(p) ? p : null;
}
