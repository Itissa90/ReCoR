import { q, one, run, audit, getParam, setParam } from '../db.js';
import { can, createUser, hashPassword, PROFILS } from '../auth.js';
import { pageHead, card, dataTable, td, pagination, csrfField, badge, genericBadge, dossierBadge, statCard, icon, progress, barChart } from '../render.js';
import {
  esc, money, int, num, fmtDate, fmtDateTime, monthLabel, monthShort, paginate, todayISO, nowStamp,
  ANOMALIES
} from '../util.js';

const NUMERIC_PARAMS = new Set([
  'TAUX_COTISATION', 'VALEUR_INDICIAIRE_DEFAUT', 'SEUIL_ANCIENNETE_MOIS', 'DELAI_DECLARATION_JOURS',
  'DELAI_RELANCE_JOURS', 'RELANCE_MAX', 'TOLERANCE_ECART', 'TAUX_MAJORATION'
]);
const PERIOD_PARAMS = new Set(['PERIODE_ANALYSE_DEBUT', 'PERIODE_ANALYSE_FIN']);

function orgOptions(selected) {
  return q('SELECT * FROM organismes ORDER BY nom')
    .map(o => `<option value="${o.id}" ${Number(selected) === o.id ? 'selected' : ''}>${esc(o.sigle || o.code)} — ${esc(o.nom)}</option>`).join('');
}

function short(s, n = 90) {
  const v = String(s ?? '');
  return v.length > n ? `${v.slice(0, n)}…` : v;
}

// ---------------- États ----------------
const ETATS = {
  declarations: {
    module: '06',
    title: 'État des déclarations de cotisations',
    description: 'Déclarations reçues, par organisme et période, avec montant et statut.',
    columns: [
      { label: 'Référence', type: 'text' }, { label: 'Organisme', type: 'text' }, { label: 'Période', type: 'period' },
      { label: 'Type', type: 'text' }, { label: 'Assurés', type: 'int' }, { label: 'Montant déclaré', type: 'money' },
      { label: 'Réception', type: 'date' }, { label: 'Statut', type: 'badge' }
    ],
    build: (f) => {
      const where = []; const params = [];
      if (f.periode) { where.push('d.periode = ?'); params.push(f.periode); }
      if (f.organisme) { where.push('d.organisme_id = ?'); params.push(f.organisme); }
      const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
      return q(`SELECT d.reference, o.nom AS organisme, d.periode, d.type_declaration, d.nb_assures, d.montant_declare,
          d.date_reception, d.statut FROM declarations d JOIN organismes o ON o.id = d.organisme_id ${w}
          ORDER BY d.periode DESC, o.nom`, ...params)
        .map(r => [r.reference, r.organisme, r.periode, r.type_declaration, r.nb_assures, r.montant_declare, r.date_reception, r.statut]);
    }
  },
  paiements: {
    module: '07',
    title: 'État des paiements',
    description: 'Paiements enregistrés, imputation et statut de rapprochement.',
    columns: [
      { label: 'Référence', type: 'text' }, { label: 'Organisme', type: 'text' }, { label: 'Date', type: 'date' },
      { label: 'Montant', type: 'money' }, { label: 'Mode', type: 'text' }, { label: 'Référence bancaire', type: 'text' },
      { label: 'Imputation', type: 'text' }, { label: 'Statut', type: 'badge' }
    ],
    build: (f) => {
      const where = []; const params = [];
      if (f.organisme) { where.push('p.organisme_id = ?'); params.push(f.organisme); }
      if (f.periode) { where.push("(p.declaration_id IN (SELECT id FROM declarations WHERE periode = ?) OR p.dossier_id IN (SELECT id FROM dossiers WHERE periode_debut <= ? AND COALESCE(periode_fin, periode_debut) >= ?))"); params.push(f.periode, f.periode, f.periode); }
      const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
      return q(`SELECT p.reference, o.nom AS organisme, p.date_paiement, p.montant, p.mode_paiement, p.reference_bancaire,
          COALESCE(d.reference, ds.reference, 'Non imputé') AS imputation, p.statut
        FROM paiements p JOIN organismes o ON o.id = p.organisme_id
        LEFT JOIN declarations d ON d.id = p.declaration_id LEFT JOIN dossiers ds ON ds.id = p.dossier_id
        ${w} ORDER BY p.date_paiement DESC, p.id DESC`, ...params)
        .map(r => [r.reference, r.organisme, r.date_paiement, r.montant, r.mode_paiement, r.reference_bancaire, r.imputation, r.statut]);
    }
  },
  anomalies: {
    module: '08',
    title: 'État des anomalies A01 – A15',
    description: 'Constats de contrôle, criticité, objet et suite donnée.',
    columns: [
      { label: 'Code', type: 'text' }, { label: 'Libellé', type: 'text' }, { label: 'Criticité', type: 'badge' },
      { label: 'Assuré / organisme', type: 'text' }, { label: 'Période', type: 'period' }, { label: 'Statut', type: 'text' },
      { label: 'Dossier', type: 'text' }
    ],
    build: (f) => {
      const where = []; const params = [];
      if (f.organisme) { where.push('a.organisme_id = ?'); params.push(f.organisme); }
      if (f.periode) { where.push('a.periode = ?'); params.push(f.periode); }
      const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
      return q(`SELECT a.code, a.libelle, a.criticite, COALESCE(TRIM(COALESCE(s.nom,'') || ' ' || COALESCE(s.prenom,'')), o.nom, '—') AS objet,
          a.periode, a.statut, COALESCE(d.reference,'—') AS dossier
        FROM anomalies a LEFT JOIN assures s ON s.id = a.assure_id LEFT JOIN organismes o ON o.id = a.organisme_id
        LEFT JOIN dossiers d ON d.id = a.dossier_id ${w} ORDER BY a.code, a.id DESC`, ...params)
        .map(r => [r.code, r.libelle, r.criticite, r.objet, r.periode, r.statut, r.dossier]);
    }
  },
  dossiers: {
    module: '11',
    title: 'État des dossiers de régularisation et de redressement',
    description: 'Dossiers, montants reconstitués, montants payés et reste dû.',
    columns: [
      { label: 'Référence', type: 'text' }, { label: 'Type', type: 'text' }, { label: 'Assuré / organisme', type: 'text' },
      { label: 'Début', type: 'period' }, { label: 'Fin', type: 'period' }, { label: 'Théorique', type: 'money' },
      { label: 'Déclaré', type: 'money' }, { label: 'Payé', type: 'money' }, { label: 'Reste dû', type: 'money' },
      { label: 'Statut', type: 'dossier' }
    ],
    build: (f) => {
      const where = []; const params = [];
      if (f.organisme) { where.push('d.organisme_id = ?'); params.push(f.organisme); }
      if (f.periode) { where.push('d.periode_debut <= ? AND COALESCE(d.periode_fin, d.periode_debut) >= ?'); params.push(f.periode, f.periode); }
      const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
      return q(`SELECT d.reference, d.type, COALESCE(TRIM(COALESCE(a.nom,'') || ' ' || COALESCE(a.prenom,'')), o.nom, '—') AS objet,
          d.periode_debut, d.periode_fin, d.montant_theorique, d.montant_declare, d.montant_paye, d.montant_du, d.statut
        FROM dossiers d LEFT JOIN assures a ON a.id = d.assure_id LEFT JOIN organismes o ON o.id = d.organisme_id
        ${w} ORDER BY d.id DESC`, ...params)
        .map(r => [r.reference, r.type, r.objet, r.periode_debut, r.periode_fin, r.montant_theorique, r.montant_declare, r.montant_paye, r.montant_du, r.statut]);
    }
  },
  recouvrement: {
    module: '13',
    title: 'État du recouvrement par organisme',
    description: 'Montants sous responsabilité, montants recouvrés et taux par organisme.',
    columns: [
      { label: 'Organisme', type: 'text' }, { label: 'Dossiers', type: 'int' }, { label: 'Théorique', type: 'money' },
      { label: 'Recouvré', type: 'money' }, { label: 'Reste dû', type: 'money' }, { label: 'Taux', type: 'percent' }
    ],
    build: (f) => {
      const where = ["d.statut IN ('06','07','08','09','10','11','12')"]; const params = [];
      if (f.organisme) { where.push('d.organisme_id = ?'); params.push(f.organisme); }
      return q(`SELECT o.nom AS organisme, COUNT(d.id) AS nb, COALESCE(SUM(d.montant_theorique),0) AS theo,
          COALESCE(SUM(d.montant_paye),0) AS paye, COALESCE(SUM(d.montant_du),0) AS du
        FROM dossiers d JOIN organismes o ON o.id = d.organisme_id WHERE ${where.join(' AND ')}
        GROUP BY o.id ORDER BY du DESC`, ...params)
        .map(r => {
          const total = Number(r.du) + Number(r.paye);
          return [r.organisme, r.nb, r.theo, r.paye, r.du, total > 0 ? Math.round(Number(r.paye) / total * 100) : 0];
        });
    }
  },
  'comptes-assures': {
    module: '15',
    title: 'État des comptes individuels assurés',
    description: 'Débits, crédits et soldes des comptes assurés.',
    columns: [
      { label: 'Matricule', type: 'text' }, { label: 'Assuré', type: 'text' }, { label: 'Organisme', type: 'text' },
      { label: 'Débit', type: 'money' }, { label: 'Crédit', type: 'money' }, { label: 'Solde', type: 'money' }
    ],
    build: (f) => {
      const where = ["m.compte_type = 'assure'"]; const params = [];
      if (f.organisme) { where.push('a.organisme_id = ?'); params.push(f.organisme); }
      return q(`SELECT a.matricule, a.nom, a.prenom, o.nom AS organisme,
          COALESCE(SUM(m.debit),0) AS debit, COALESCE(SUM(m.credit),0) AS credit
        FROM assures a JOIN mouvements m ON m.assure_id = a.id AND ${where.join(' AND ')}
        LEFT JOIN organismes o ON o.id = a.organisme_id
        GROUP BY a.id ORDER BY COALESCE(SUM(m.debit),0)-COALESCE(SUM(m.credit),0) DESC`, ...params)
        .map(r => [r.matricule, `${r.nom} ${r.prenom}`, r.organisme, r.debit, r.credit, Number(r.debit) - Number(r.credit)]);
    }
  },
  'comptes-cotisants': {
    module: '15',
    title: 'État des comptes cotisants',
    description: 'Débits, crédits et soldes des comptes organismes.',
    columns: [
      { label: 'Organisme', type: 'text' }, { label: 'Débit', type: 'money' }, { label: 'Crédit', type: 'money' }, { label: 'Solde', type: 'money' }
    ],
    build: (f) => {
      const where = ["m.compte_type = 'cotisant'"]; const params = [];
      if (f.organisme) { where.push('o.id = ?'); params.push(f.organisme); }
      return q(`SELECT o.nom AS organisme, COALESCE(SUM(m.debit),0) AS debit, COALESCE(SUM(m.credit),0) AS credit
        FROM organismes o JOIN mouvements m ON m.organisme_id = o.id AND ${where.join(' AND ')}
        GROUP BY o.id ORDER BY COALESCE(SUM(m.debit),0)-COALESCE(SUM(m.credit),0) DESC`, ...params)
        .map(r => [r.organisme, r.debit, r.credit, Number(r.debit) - Number(r.credit)]);
    }
  },
  journal: {
    module: '19',
    title: 'Journal de traçabilité',
    description: 'Historique horodaté des opérations : utilisateur, action, valeurs et motif.',
    columns: [
      { label: 'Date', type: 'text' }, { label: 'Utilisateur', type: 'text' }, { label: 'Action', type: 'text' },
      { label: 'Entité', type: 'text' }, { label: 'Référence', type: 'text' }, { label: 'Ancienne valeur', type: 'text' },
      { label: 'Nouvelle valeur', type: 'text' }, { label: 'Motif', type: 'text' }, { label: 'Pièce', type: 'text' }, { label: 'IP', type: 'text' }
    ],
    build: (f) => {
      const where = []; const params = [];
      if (f.organisme) { where.push('1=0'); }
      if (f.from) { where.push('date_action >= ?'); params.push(`${f.from} 00:00:00`); }
      if (f.to) { where.push('date_action <= ?'); params.push(`${f.to} 23:59:59`); }
      const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
      return q(`SELECT date_action, user_nom, action, entite, entite_id, ancienne_valeur, nouvelle_valeur, motif, piece, adresse_ip
        FROM audit_log ${w} ORDER BY id DESC LIMIT 5000`, ...params)
        .map(r => [r.date_action, r.user_nom, r.action, r.entite, r.entite_id, r.ancienne_valeur, r.nouvelle_valeur, r.motif, r.piece, r.adresse_ip]);
    }
  }
};

function displayCell(value, type) {
  if (value === null || value === undefined || value === '') return type === 'dossier' || type === 'badge' ? '—' : '<span class="muted">—</span>';
  switch (type) {
    case 'money': return money(value);
    case 'percent': return `${value} %`;
    case 'int': return String(value);
    case 'date': return fmtDate(value);
    case 'period': return esc(monthLabel(value));
    case 'badge': return genericBadge(value);
    case 'dossier': return dossierBadge(value);
    default: return esc(String(value));
  }
}

function csvSafe(value) {
  let s = value === null || value === undefined ? '' : String(value);
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`;
  return `"${s.replaceAll('"', '""')}"`;
}

function xmlSafe(value) {
  return String(value ?? '').replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
}

function filtersFrom(ctx) {
  return {
    periode: /^\d{4}-\d{2}$/.test(String(ctx.query.periode || '')) ? String(ctx.query.periode) : '',
    organisme: int(ctx.query.organisme, 0),
    from: String(ctx.query.from || ''),
    to: String(ctx.query.to || '')
  };
}

function recordExtraction(ctx, code, format, filters, count) {
  run(
    `INSERT INTO extractions (type_etat, format, criteres, nb_lignes, periode, user_id, user_nom, date_extraction)
     VALUES (?,?,?,?,?,?,?,?)`,
    code, format, JSON.stringify(filters), count, filters.periode || '', ctx.user.id, ctx.user.nom, nowStamp()
  );
  audit(ctx.user, 'Extraction', code, 'Export', '', `${format} — ${count} ligne(s)`, JSON.stringify(filters));
}

function sendDownload(ctx, body, filename, mime) {
  const buf = Buffer.from(body, 'utf8');
  ctx.res.writeHead(200, {
    'Content-Type': mime,
    'Content-Length': buf.length,
    'Content-Disposition': `attachment; filename="${filename}"`,
    'X-Content-Type-Options': 'nosniff'
  });
  ctx.res.end(buf);
}

function exportBase(code, filters) {
  const stamp = todayISO().replaceAll('-', '');
  return `recor-${code}-${stamp}`;
}

// ---------------- Administration helpers ----------------
function formUser(u = null) {
  return `<form method="post" action="${u ? `/administration/utilisateurs/${u.id}` : '/administration/utilisateurs'}" class="form-grid">
    ${csrfField('__CSRF__')}
    ${u ? '' : '<div class="field"><label>Identifiant <span class="req">*</span></label><input name="login" required pattern="[A-Za-z0-9._-]{3,}" placeholder="prenom.nom"></div>'}
    <div class="field"><label>Nom complet <span class="req">*</span></label><input name="nom" required value="${esc(u?.nom || '')}"></div>
    <div class="field"><label>Profil <span class="req">*</span></label><select name="profil" required>${PROFILS.map(p => `<option ${u?.profil === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
    <div class="field"><label>${u ? 'Nouveau mot de passe' : 'Mot de passe'} ${u ? '' : '<span class="req">*</span>'}</label><input type="password" name="password" ${u ? '' : 'required'} minlength="8" autocomplete="new-password"><span class="hint">8 caractères minimum${u ? ' — laisser vide pour conserver' : ''}.</span></div>
    <div class="field"><label>Adresse électronique</label><input type="email" name="email" value="${esc(u?.email || '')}"></div>
    <div class="field"><label>Téléphone</label><input name="telephone" value="${esc(u?.telephone || '')}"></div>
    ${u ? `<div class="field span2"><label class="checkline"><input type="checkbox" name="actif" value="1" ${u.actif ? 'checked' : ''}> Compte actif</label></div>` : ''}
    <div class="form-actions"><button class="btn primary" type="submit">${u ? 'Enregistrer les modifications' : 'Créer le compte'}</button></div>
  </form>`;
}

export function register(router) {
  router.get('/', 'view', (ctx) => ctx.redirect('/dashboard'));

  // ---------------- Tableau de bord ----------------
  router.get('/dashboard', 'view', (ctx) => {
    const s = {
      assures: one("SELECT COUNT(*) AS n FROM assures WHERE statut IN ('Actif','Suspendu')").n,
      organismes: one('SELECT COUNT(*) AS n FROM organismes WHERE actif = 1').n,
      declarations: one("SELECT COUNT(*) AS n, COALESCE(SUM(montant_declare),0) AS m FROM declarations WHERE statut = 'Validé'"),
      paiements: one("SELECT COALESCE(SUM(montant),0) AS m FROM paiements WHERE statut = 'Rapproché'"),
      critiques: one("SELECT COUNT(*) AS n FROM anomalies WHERE criticite = 'Critique' AND statut = 'Nouvelle'").n,
      dossiersOuverts: one("SELECT COUNT(*) AS n FROM dossiers WHERE statut IN ('01','02','03','04','05','16')").n,
      du: one("SELECT COALESCE(SUM(montant_du),0) AS m FROM dossiers WHERE statut IN ('06','07','08','09','10','11','12')").m,
      notifications: one("SELECT COUNT(*) AS n FROM notifications WHERE statut <> 'Reçue'").n,
      anomaliesTotal: one('SELECT COUNT(*) AS n FROM anomalies').n,
      dossiersTotal: one('SELECT COUNT(*) AS n FROM dossiers').n
    };
    const months = q(`SELECT periode, COALESCE(SUM(montant_declare),0) AS m FROM declarations
      WHERE statut = 'Validé' GROUP BY periode ORDER BY periode DESC LIMIT 12`).reverse();
    const chart = months.length
      ? barChart(months.map(m => ({ label: monthShort(m.periode), value: Number(m.m) })),
        { valueFmt: v => `${(v / 1000000).toFixed(1)} M`, height: 150 })
      : '<div class="empty"><p>Aucune déclaration validée.</p></div>';
    const byCode = new Map(q('SELECT code, COUNT(*) AS n FROM anomalies GROUP BY code').map(r => [r.code, r.n]));
    const familles = {};
    for (const [code, meta] of Object.entries(ANOMALIES)) {
      familles[meta.famille] = (familles[meta.famille] || 0) + (byCode.get(code) || 0);
    }
    const anomalyChart = barChart(Object.entries(familles).map(([label, value]) => ({ label, value, tone: 'gold' })),
      { valueFmt: v => String(v), height: 150 });
    const typeRows = q(`SELECT type, COUNT(*) AS n, COALESCE(SUM(montant_du),0) AS du FROM dossiers GROUP BY type`);
    const typeList = ['Regularisation', 'Redressement', 'Recouvrement'].map(t => {
      const row = typeRows.find(r => r.type === t) || { n: 0, du: 0 };
      const label = t === 'Regularisation' ? 'Régularisation' : t;
      const pct = s.dossiersTotal ? Math.round(Number(row.n) / s.dossiersTotal * 100) : 0;
      return `<div class="kv-row"><span>${label}</span><strong>${row.n} <span class="muted">· ${money(row.du)}</span></strong></div>
        ${progress(pct, t === 'Recouvrement' ? 'bad' : t === 'Redressement' ? 'gold' : '')}`;
    }).join('');
    const derniers = q(`SELECT d.*, a.matricule, a.nom AS assure_nom, a.prenom AS assure_prenom, o.sigle
      FROM dossiers d LEFT JOIN assures a ON a.id = d.assure_id LEFT JOIN organismes o ON o.id = d.organisme_id
      ORDER BY d.updated_at DESC LIMIT 8`);
    const dashRows = derniers.map(d => [
      td(`<a class="mono" href="/dossiers/${d.id}">${esc(d.reference)}</a>`),
      td(d.matricule ? `${esc(d.assure_nom)} ${esc(d.assure_prenom)}` : esc(d.sigle || '—')),
      td(money(d.montant_du), 'num'),
      td(dossierBadge(d.statut))
    ]);
    const topOrg = q(`SELECT o.id, o.sigle, o.nom, COALESCE(SUM(d.montant_du),0) AS du, COUNT(d.id) AS nb
      FROM dossiers d JOIN organismes o ON o.id = d.organisme_id
      WHERE d.statut IN ('06','07','08','09','10','11','12') GROUP BY o.id ORDER BY du DESC LIMIT 6`);
    const topRows = topOrg.map(o => [
      td(`<a href="/organismes/${o.id}">${esc(o.sigle || o.nom)}</a>`),
      td(String(o.nb), 'num'),
      td(money(o.du), 'num')
    ]);
    const lastControl = getParam('DERNIER_CONTROLE', '—');
    const content = `
      ${pageHead('Tableau de bord', 'Pilotage des cotisations, du contrôle, de la régularisation et du recouvrement.',
        `${can(ctx.user, 'controles.run') ? `<form method="post" action="/controles/executer" class="inline-form">${csrfField(ctx.csrf)}<button class="btn primary" type="submit">${icon('refresh', 16)} Lancer les contrôles</button></form>` : ''}`,
        ['Module 17', 'Tableau de bord'])}
      ${s.critiques > 0 ? `<div class="callout gold" style="margin-bottom:16px">${icon('alert', 18)}<div><strong>${s.critiques} anomalie(s) critique(s)</strong> non encore traitée(s). <a href="/controles?criticite=Critique">Ouvrir le centre de contrôle</a></div></div>` : ''}
      <div class="stats">
        ${statCard({ label: 'Assurés suivis', value: s.assures, hint: `${s.organismes} organisme(s) cotisant(s)`, iconName: 'users' })}
        ${statCard({ label: 'Cotisations déclarées', value: money(s.declarations.m), hint: `${s.declarations.n} déclaration(s) validée(s)`, tone: 'info', iconName: 'file' })}
        ${statCard({ label: 'Reste à recouvrer', value: money(s.du), hint: `${s.notifications} notification(s) en attente`, tone: 'bad', iconName: 'wallet' })}
        ${statCard({ label: 'Anomalies critiques', value: s.critiques, hint: `Dernier contrôle : ${esc(lastControl)}`, tone: s.critiques ? 'warn' : 'ok', iconName: 'shield' })}
      </div>
      <div class="stats">
        ${statCard({ label: 'Paiements rapprochés', value: money(s.paiements.m), hint: 'Encaissements imputés', tone: 'ok', iconName: 'check' })}
        ${statCard({ label: 'Dossiers ouverts', value: s.dossiersOuverts, hint: `sur ${s.dossiersTotal} dossier(s)`, tone: 'warn', iconName: 'clock' })}
        ${statCard({ label: 'Anomalies détectées', value: s.anomaliesTotal, hint: '15 typologies A01 – A15', iconName: 'alert' })}
        ${statCard({ label: 'Période analysée', value: `${esc(getParam('PERIODE_ANALYSE_DEBUT', '—'))} → ${esc(getParam('PERIODE_ANALYSE_FIN', '—'))}`, hint: 'Paramètre de contrôle', iconName: 'calc' })}
      </div>
      <div class="grid grid-2">
        ${card(`<div class="legend"><span><i></i> Montant déclaré validé</span></div>${chart}`, { title: 'Déclarations validées — 12 derniers mois', subtitle: 'Montants en millions de FCFA.' })}
        ${card(anomalyChart, { title: 'Anomalies par famille', subtitle: 'Répartition des constats A01 – A15.' })}
      </div>
      <div class="grid grid-2">
        ${card(typeList + `<div class="mt16"><a class="btn" href="/dossiers">Tous les dossiers</a></div>`, { title: 'Dossiers par chaîne', subtitle: 'Régularisation, redressement, recouvrement.' })}
        ${card(topRows.length ? dataTable(['Organisme', 'Dossiers', 'Reste dû'], topRows) : '<div class="empty"><p>Aucun organisme en recouvrement.</p></div>', { title: 'Principaux organismes débiteurs', bodyClass: 'flush' })}
      </div>
      ${card(dataTable(['Dossier', 'Assuré / organisme', 'Reste dû', 'Statut'], dashRows, { empty: 'Aucun dossier enregistré.' }), { title: 'Derniers dossiers traités', bodyClass: 'flush', actions: `<a class="btn sm" href="/dossiers">Voir tout</a>` })}`;
    ctx.send(ctx.page('Tableau de bord', '/dashboard', content, ['Module 17', 'Tableau de bord']));
  });

  // ---------------- États et exports ----------------
  router.get('/etats', 'view', (ctx) => {
    const counts = {
      declarations: one('SELECT COUNT(*) AS n FROM declarations').n,
      paiements: one('SELECT COUNT(*) AS n FROM paiements').n,
      anomalies: one('SELECT COUNT(*) AS n FROM anomalies').n,
      dossiers: one('SELECT COUNT(*) AS n FROM dossiers').n,
      recouvrement: one("SELECT COUNT(*) AS n FROM dossiers WHERE statut IN ('06','07','08','09','10','11','12')").n,
      'comptes-assures': one("SELECT COUNT(DISTINCT assure_id) AS n FROM mouvements WHERE compte_type='assure'").n,
      'comptes-cotisants': one("SELECT COUNT(DISTINCT organisme_id) AS n FROM mouvements WHERE compte_type='cotisant'").n,
      journal: one('SELECT COUNT(*) AS n FROM audit_log').n
    };
    const cards = Object.entries(ETATS).map(([code, e]) => {
      const label = e.title.replace('État des ', '').replace('État du ', '').replace(/^./, c => c.toUpperCase());
      return `
      <a class="stat-card" href="/etats/${code}" style="align-items:flex-start">
        <div class="stat-top" style="justify-content:flex-end"><span class="stat-ico">${icon('file', 17)}</span></div>
        <div class="stat-value" style="font-size:17px;margin-top:4px">${esc(label)}</div>
        <div class="stat-hint" style="min-height:32px">${esc(e.description)}</div>
        <div class="stat-hint" style="margin-top:8px"><strong>${counts[code] || 0}</strong> ligne(s) disponibles</div>
      </a>`;
    }).join('');
    const content = `
      ${pageHead('États et éditions', 'Rapports institutionnels exportables en CSV, Excel et version imprimable.', `<a class="btn" href="/import-export">${icon('download', 16)} Échanges de données</a>`, ['Module 16', 'États'])}
      <div class="stats" style="grid-template-columns:repeat(4,minmax(0,1fr))">${cards}</div>
      ${card(`<div class="help-box"><b>Formats disponibles</b><br>Chaque état s'ouvre en aperçu, puis s'exporte en <b>CSV</b> (UTF-8, séparateur « ; »), en <b>Excel</b> (SpreadsheetML) ou s'imprime en <b>PDF</b> via le navigateur. Les exports sont journalisés dans la table des extractions.</div>`, { title: 'Mode d’emploi' })}`;
    ctx.send(ctx.page('États', '/etats', content, ['Module 16', 'États']));
  });

  router.get('/etats/:code', 'view', (ctx) => {
    const code = String(ctx.params.code);
    const etat = ETATS[code];
    if (!etat) return ctx.send('<h1>État introuvable</h1>', 404);
    const f = filtersFrom(ctx);
    const format = String(ctx.query.format || '');
    const rows = etat.build(f);
    if (format === 'csv') {
      if (!can(ctx.user, 'etats.export')) return ctx.send('<h1>Accès refusé</h1>', 403);
      recordExtraction(ctx, code, 'CSV', f, rows.length);
      const lines = [etat.columns.map(c => csvSafe(c.label)).join(';')];
      for (const row of rows) lines.push(row.map((v, i) => csvSafe(v)).join(';'));
      return sendDownload(ctx, `\uFEFF${lines.join('\r\n')}\r\n`, `${exportBase(code, f)}.csv`, 'text/csv; charset=utf-8');
    }
    if (format === 'xls') {
      if (!can(ctx.user, 'etats.export')) return ctx.send('<h1>Accès refusé</h1>', 403);
      recordExtraction(ctx, code, 'Excel', f, rows.length);
      const cell = (v, type) => {
        const numeric = ['money', 'int', 'percent'].includes(type) && v !== null && v !== '' && Number.isFinite(Number(v));
        return `<Cell><Data ss:Type="${numeric ? 'Number' : 'String'}">${xmlSafe(numeric ? Number(v) : v)}</Data></Cell>`;
      };
      const xml = `<?xml version="1.0" encoding="UTF-8"?>
<?mso-application progid="Excel.Sheet"?>
<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">
<Styles><Style ss:ID="h"><Font ss:Bold="1"/><Interior ss:Color="#DCE6F1" ss:Pattern="Solid"/></Style></Styles>
<Worksheet ss:Name="${xmlSafe(code).slice(0, 28)}"><Table>
<Row>${etat.columns.map(c => `<Cell ss:StyleID="h"><Data ss:Type="String">${xmlSafe(c.label)}</Data></Cell>`).join('')}</Row>
${rows.map(row => `<Row>${row.map((v, i) => cell(v, etat.columns[i].type)).join('')}</Row>`).join('\n')}
</Table></Worksheet></Workbook>`;
      return sendDownload(ctx, xml, `${exportBase(code, f)}.xls`, 'application/vnd.ms-excel; charset=utf-8');
    }
    const preview = rows.slice(0, 200);
    const table = dataTable(
      etat.columns.map(c => esc(c.label)),
      preview.map(row => row.map((v, i) => td(displayCell(v, etat.columns[i].type), ['money', 'int', 'percent'].includes(etat.columns[i].type) ? 'num' : ''))),
      { empty: 'Aucune donnée pour ces critères.' }
    );
    const query = new URLSearchParams();
    if (f.periode) query.set('periode', f.periode);
    if (f.organisme) query.set('organisme', String(f.organisme));
    if (f.from) query.set('from', f.from);
    if (f.to) query.set('to', f.to);
    const suffix = query.toString() ? `&${query.toString()}` : '';
    const actions = `${can(ctx.user, 'etats.export') ? `<a class="btn" href="/etats/${code}?format=csv${suffix}">${icon('download', 15)} CSV</a><a class="btn" href="/etats/${code}?format=xls${suffix}">${icon('download', 15)} Excel</a>` : ''}<a class="btn" href="/etats/${code}?format=print${suffix}" data-print>${icon('print', 15)} Imprimer</a>`;
    const content = `
      ${pageHead(etat.title, etat.description, actions, ['Module 16', 'États', code])}
      <div class="print-head"><h2>CAISSE DE RETRAITES DU TOGO — ${esc(etat.title)}</h2><p>Direction de l'Immatriculation et du Recouvrement · Édité le ${fmtDate(todayISO())}${f.periode ? ` · Période ${esc(monthLabel(f.periode))}` : ''}</p></div>
      ${card(`
        <form class="filter-bar" method="get" action="/etats/${code}">
          ${code !== 'journal' ? `<div class="field"><label>Période</label><input type="month" name="periode" value="${esc(f.periode)}"></div>` : ''}
          ${!['comptes-assures', 'comptes-cotisants', 'journal'].includes(code) ? `<div class="field"><label>Organisme</label><select name="organisme"><option value="">Tous</option>${orgOptions(f.organisme)}</select></div>` : ''}
          ${code === 'comptes-assures' ? `<div class="field"><label>Organisme</label><select name="organisme"><option value="">Tous</option>${orgOptions(f.organisme)}</select></div>` : ''}
          ${code === 'journal' ? `<div class="field"><label>Du</label><input type="date" name="from" value="${esc(f.from)}"></div><div class="field"><label>Au</label><input type="date" name="to" value="${esc(f.to)}"></div>` : ''}
          <button class="btn" type="submit">Actualiser</button>
          <a class="btn" href="/etats/${code}">Réinitialiser</a>
        </form>
        <div class="split-actions" style="padding:10px 16px;border-bottom:1px solid var(--line);font-size:12px;color:var(--muted)">
          <span>${rows.length} ligne(s)${rows.length > preview.length ? ` — aperçu limité à ${preview.length}, l'export contient tout` : ''}</span>
          <span>Édité le ${fmtDateTime(nowStamp())}</span>
        </div>
        ${table}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page(etat.title, '/etats', content, ['Module 16', 'États', code]));
  });

  // ---------------- Administration ----------------
  router.get('/administration', 'admin.users', (ctx) => {
    const users = q('SELECT * FROM users ORDER BY nom');
    const userRows = users.map(u => [
      td(`${esc(u.nom)}<span class="sub">${esc(u.login)}</span>`),
      td(badge(u.profil, u.profil === 'Administrateur' ? 'gold' : u.profil === 'Direction' ? 'info' : 'neutral')),
      td(esc(u.email || '—')),
      td(fmtDateTime(u.derniere_connexion)),
      td(u.actif ? badge('Actif', 'ok') : badge('Inactif', 'bad')),
      td(`<a class="btn xs" href="/administration/utilisateurs/${u.id}">Modifier</a>`, 'actions')
    ]);
    const params = q('SELECT * FROM parametres ORDER BY groupe, cle');
    const groups = new Map();
    for (const p of params) {
      if (!groups.has(p.groupe || 'Général')) groups.set(p.groupe || 'Général', []);
      groups.get(p.groupe || 'Général').push(p);
    }
    const paramsHtml = [...groups.entries()].map(([groupe, list]) => `
      <div class="form-section"><h3>${esc(groupe)}</h3>
        <div class="form-grid">
          ${list.map(p => `<div class="field">
            <label>${esc(p.libelle || p.cle)} <span class="muted mono">${esc(p.cle)}</span></label>
            <input name="p_${esc(p.cle)}" value="${esc(p.valeur)}" ${p.modifiable ? '' : 'readonly'}>
          </div>`).join('')}
        </div>
      </div>`).join('');
    const sessions = one('SELECT COUNT(*) AS n FROM sessions WHERE expires_at > ?', new Date().toISOString()).n;
    const auditCount = one('SELECT COUNT(*) AS n FROM audit_log').n;
    const content = `
      ${pageHead('Administration', 'Utilisateurs, habilitations et paramètres de calcul.', '', ['Module 18', 'Administration'])}
      <div class="stats">
        ${statCard({ label: 'Utilisateurs', value: users.length, hint: `${users.filter(u => u.actif).length} actif(s)`, iconName: 'users' })}
        ${statCard({ label: 'Sessions en cours', value: sessions, hint: 'Expiration après 8 h', tone: 'info', iconName: 'shield' })}
        ${statCard({ label: 'Paramètres', value: params.length, hint: 'Taux, délais et seuils', iconName: 'settings' })}
        ${statCard({ label: 'Actions journalisées', value: auditCount, hint: 'Traçabilité complète', tone: 'ok', iconName: 'clock' })}
      </div>
      ${card(dataTable(['Utilisateur', 'Profil', 'Courriel', 'Dernière connexion', 'État', ''], userRows, { empty: 'Aucun utilisateur.' }), { title: 'Comptes utilisateurs', bodyClass: 'flush' })}
      <div class="grid grid-2">
        ${card(formUser().replace('__CSRF__', esc(ctx.csrf)), { title: 'Créer un utilisateur' })}
        ${card(`<div class="help-box"><b>Habilitations par profil</b><br>
          <b>Administrateur</b> : accès total et paramétrage.<br>
          <b>Direction</b> : consultation, validation, exports et supervision.<br>
          <b>Superviseur</b> : référentiels, contrôles, dossiers et recouvrement.<br>
          <b>Contrôleur</b> : contrôles, analyse et validation des calculs.<br>
          <b>Comptable</b> : enregistrement et rapprochement des paiements.<br>
          <b>Agent Recouvrement</b> : dossiers, notifications et relances.<br>
          <b>Agent de saisie</b> : saisie des assurés, déclarations et paiements.</div>
          <div class="callout mt16">${icon('shield', 18)}<div>Les mots de passe sont stockés avec un hachage scrypt salé. Toute création ou modification est journalisée.</div></div>`, { title: 'Profils et sécurité' })}
      </div>
      ${card(`<form method="post" action="/administration/parametres" class="form-grid one">
        ${csrfField(ctx.csrf)}
        ${paramsHtml}
        <div class="form-actions"><button class="btn primary" type="submit">Enregistrer les paramètres</button></div>
      </form>`, { title: 'Paramètres du système', subtitle: 'Les taux exacts et règles juridiques doivent être validés par la CRT.' })}`;
    ctx.send(ctx.page('Administration', '/administration', content, ['Module 18', 'Administration']));
  });

  router.get('/administration/utilisateurs/:id', 'admin.users', (ctx) => {
    const u = one('SELECT * FROM users WHERE id = ?', Number(ctx.params.id));
    if (!u) return ctx.send('<h1>Utilisateur introuvable</h1>', 404);
    const content = `
      ${pageHead(`Utilisateur — ${u.nom}`, `${u.login} · ${u.profil}`, '<a class="btn" href="/administration">Retour</a>', ['Module 18', 'Administration', u.login])}
      ${card(formUser(u).replace('__CSRF__', esc(ctx.csrf)), { title: 'Modifier le compte' })}`;
    ctx.send(ctx.page(`Utilisateur — ${u.login}`, '/administration', content, ['Module 18', 'Administration', u.login]));
  });

  router.post('/administration/utilisateurs', 'admin.users', (ctx) => {
    const b = ctx.body;
    const login = String(b.login || '').trim().toLowerCase();
    if (!/^[a-z0-9._-]{3,}$/.test(login)) {
      ctx.flash('error', "L'identifiant doit contenir au moins 3 caractères (lettres, chiffres, point, tiret, souligné).");
      return ctx.redirect('/administration');
    }
    if (!b.nom || String(b.password || '').length < 8 || !PROFILS.includes(b.profil)) {
      ctx.flash('error', 'Nom, profil et mot de passe (8 caractères minimum) sont obligatoires.');
      return ctx.redirect('/administration');
    }
    if (one('SELECT id FROM users WHERE login = ?', login)) {
      ctx.flash('error', 'Cet identifiant existe déjà.');
      return ctx.redirect('/administration');
    }
    const id = createUser({ login, password: b.password, nom: b.nom, profil: b.profil, email: b.email || '', telephone: b.telephone || '' });
    audit(ctx.user, 'Utilisateur', id, 'Création', '', `${login} — ${b.profil}`, '', '', ctx.ip);
    ctx.flash('success', `Utilisateur ${login} créé.`);
    ctx.redirect('/administration');
  });

  router.post('/administration/utilisateurs/:id', 'admin.users', (ctx) => {
    const u = one('SELECT * FROM users WHERE id = ?', Number(ctx.params.id));
    if (!u) return ctx.send('<h1>Utilisateur introuvable</h1>', 404);
    const b = ctx.body;
    const actif = b.actif === '1' ? 1 : 0;
    const profil = PROFILS.includes(b.profil) ? b.profil : u.profil;
    if (u.id === ctx.user.id && (!actif || profil !== u.profil)) {
      ctx.flash('error', 'Vous ne pouvez pas désactiver votre propre compte ni modifier votre propre profil.');
      return ctx.redirect(`/administration/utilisateurs/${u.id}`);
    }
    run('UPDATE users SET nom = ?, profil = ?, email = ?, telephone = ?, actif = ? WHERE id = ?',
      b.nom || u.nom, profil, b.email || '', b.telephone || '', actif, u.id);
    if (b.password) {
      if (String(b.password).length < 8) {
        ctx.flash('error', 'Le nouveau mot de passe doit contenir au moins 8 caractères.');
        return ctx.redirect(`/administration/utilisateurs/${u.id}`);
      }
      run('UPDATE users SET password_hash = ? WHERE id = ?', hashPassword(b.password), u.id);
    }
    audit(ctx.user, 'Utilisateur', u.id, 'Modification', `${u.nom} / ${u.profil} / actif=${u.actif}`, `${b.nom} / ${profil} / actif=${actif}`, '', '', ctx.ip);
    ctx.flash('success', 'Compte utilisateur mis à jour.');
    ctx.redirect('/administration');
  });

  router.post('/administration/parametres', 'admin.users', (ctx) => {
    const params = q('SELECT * FROM parametres');
    let changed = 0;
    for (const p of params) {
      if (!p.modifiable) continue;
      const key = `p_${p.cle}`;
      if (!(key in ctx.body)) continue;
      const value = String(ctx.body[key] ?? '').trim();
      if (value === String(p.valeur ?? '')) continue;
      if (NUMERIC_PARAMS.has(p.cle)) {
        const n = num(value, NaN);
        if (!Number.isFinite(n) || n < 0) {
          ctx.flash('error', `Valeur numérique invalide pour ${p.cle}.`);
          return ctx.redirect('/administration');
        }
      }
      if (PERIOD_PARAMS.has(p.cle) && !/^\d{4}-\d{2}$/.test(value)) {
        ctx.flash('error', `La période ${p.cle} doit être au format AAAA-MM.`);
        return ctx.redirect('/administration');
      }
      setParam(p.cle, value);
      audit(ctx.user, 'Paramètre', p.cle, 'Modification', p.valeur, value);
      changed++;
    }
    ctx.flash('success', changed ? `${changed} paramètre(s) mis à jour.` : 'Aucun changement.');
    ctx.redirect('/administration');
  });

  // ---------------- Traçabilité ----------------
  router.get('/journal', 'audit.view', (ctx) => {
    const f = {
      q: String(ctx.query.q || '').trim(),
      user: String(ctx.query.user || ''),
      action: String(ctx.query.action || ''),
      entite: String(ctx.query.entite || ''),
      from: String(ctx.query.from || ''),
      to: String(ctx.query.to || '')
    };
    const page = int(ctx.query.page, 1);
    const where = []; const params = [];
    if (f.q) {
      where.push('(motif LIKE ? OR entite_id LIKE ? OR ancienne_valeur LIKE ? OR nouvelle_valeur LIKE ? OR user_nom LIKE ?)');
      const t = `%${f.q}%`; params.push(t, t, t, t, t);
    }
    if (f.user) { where.push('user_id = ?'); params.push(Number(f.user)); }
    if (f.action) { where.push('action = ?'); params.push(f.action); }
    if (f.entite) { where.push('entite = ?'); params.push(f.entite); }
    if (f.from) { where.push('date_action >= ?'); params.push(`${f.from} 00:00:00`); }
    if (f.to) { where.push('date_action <= ?'); params.push(`${f.to} 23:59:59`); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM audit_log ${w}`, ...params).n;
    const p = paginate(total, page, 50);
    const rows = q(`SELECT * FROM audit_log ${w} ORDER BY id DESC LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(a => [
      td(`<span class="mono">${esc(fmtDateTime(a.date_action))}</span>`),
      td(esc(a.user_nom || '—')),
      td(esc(a.action)),
      td(`${esc(a.entite)}${a.entite_id ? `<span class="sub mono">${esc(a.entite_id)}</span>` : ''}`),
      td(a.ancienne_valeur ? `<span class="mono" title="${esc(a.ancienne_valeur)}">${esc(short(a.ancienne_valeur, 40))}</span>` : '<span class="muted">—</span>'),
      td(a.nouvelle_valeur ? `<span class="mono" title="${esc(a.nouvelle_valeur)}">${esc(short(a.nouvelle_valeur, 40))}</span>` : '<span class="muted">—</span>'),
      td(a.motif ? esc(short(a.motif, 60)) : '<span class="muted">—</span>'),
      td(a.piece ? `<span class="ref">${esc(a.piece)}</span>` : '—'),
      td(`<span class="mono">${esc(a.adresse_ip || '—')}</span>`)
    ]);
    const actions = q('SELECT DISTINCT action FROM audit_log ORDER BY action').map(r => r.action);
    const entites = q('SELECT DISTINCT entite FROM audit_log ORDER BY entite').map(r => r.entite);
    const users = q('SELECT id, nom FROM users ORDER BY nom');
    const today = one("SELECT COUNT(*) AS n FROM audit_log WHERE date_action >= ?", `${todayISO()} 00:00:00`).n;
    const content = `
      ${pageHead('Traçabilité', 'Historique horodaté de toutes les opérations : date, utilisateur, action, valeurs, motif et pièce.', `<a class="btn" href="/etats/journal">${icon('file', 15)} État complet</a>`, ['Module 19', 'Traçabilité'])}
      <div class="stats">
        ${statCard({ label: 'Actions journalisées', value: total, hint: 'Selon les filtres actifs', iconName: 'clock' })}
        ${statCard({ label: "Actions aujourd'hui", value: today, hint: fmtDate(todayISO()), tone: 'info', iconName: 'refresh' })}
        ${statCard({ label: 'Utilisateurs traceés', value: users.length, hint: 'Comptes du système', iconName: 'users' })}
        ${statCard({ label: 'Types d’objets', value: entites.length, hint: 'Entités concernées', tone: 'ok', iconName: 'layers' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/journal">
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(f.q)}" placeholder="Motif, référence, valeur, utilisateur"></div>
          <div class="field"><label>Utilisateur</label><select name="user"><option value="">Tous</option>${users.map(u => `<option value="${u.id}" ${f.user === String(u.id) ? 'selected' : ''}>${esc(u.nom)}</option>`).join('')}</select></div>
          <div class="field"><label>Action</label><select name="action"><option value="">Toutes</option>${actions.map(a => `<option ${f.action === a ? 'selected' : ''}>${esc(a)}</option>`).join('')}</select></div>
          <div class="field"><label>Objet</label><select name="entite"><option value="">Tous</option>${entites.map(e => `<option ${f.entite === e ? 'selected' : ''}>${esc(e)}</option>`).join('')}</select></div>
          <div class="field"><label>Du</label><input type="date" name="from" value="${esc(f.from)}"></div>
          <div class="field"><label>Au</label><input type="date" name="to" value="${esc(f.to)}"></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/journal">Réinitialiser</a>
        </form>
        ${dataTable(['Date', 'Utilisateur', 'Action', 'Objet', 'Ancienne valeur', 'Nouvelle valeur', 'Motif', 'Pièce', 'IP'], trs, { empty: 'Aucune action pour ces critères.' })}
        ${pagination(p, '/journal', f)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Traçabilité', '/journal', content, ['Module 19', 'Traçabilité']));
  });

  // ---------------- Communication ----------------
  router.get('/communication', 'view', (ctx) => {
    const rows = q(`SELECT c.*, u.nom AS auteur FROM communications c LEFT JOIN users u ON u.id = c.created_by ORDER BY c.id DESC`);
    const trs = rows.map(c => [
      td(`<a class="main-cell" href="/communication/${c.id}">${esc(c.titre)}</a><span class="sub">${esc(short(c.contenu, 90))}</span>`),
      td(esc(c.type_support || '—')),
      td(esc(c.destinataires || '—')),
      td(fmtDate(c.date_publication)),
      td(genericBadge(c.statut)),
      td(esc(c.auteur || '—')),
      td(`<a class="btn xs" href="/communication/${c.id}">Ouvrir</a>`, 'actions')
    ]);
    const stats = one(`SELECT COUNT(*) AS total,
      SUM(CASE WHEN statut = 'Publié' THEN 1 ELSE 0 END) AS publies,
      SUM(CASE WHEN statut = 'Brouillon' THEN 1 ELSE 0 END) AS brouillons FROM communications`);
    const content = `
      ${pageHead('Communication', 'Supports d’information aux organismes, aux assurés et aux agents.', '', ['Module 20', 'Communication'])}
      <div class="stats">
        ${statCard({ label: 'Supports créés', value: stats.total || 0, hint: 'Tous statuts', iconName: 'message' })}
        ${statCard({ label: 'Publiés', value: stats.publies || 0, hint: 'Diffusés', tone: 'ok', iconName: 'check' })}
        ${statCard({ label: 'Brouillons', value: stats.brouillons || 0, hint: 'En préparation', tone: 'warn', iconName: 'file' })}
        ${statCard({ label: 'Canaux', value: 'Courrier · Affichage · Portail', hint: 'Modes de diffusion', tone: 'info', iconName: 'bell' })}
      </div>
      <div class="grid grid-2-1">
        ${card(dataTable(['Titre', 'Support', 'Destinataires', 'Publication', 'Statut', 'Auteur', ''], trs, { empty: 'Aucun support de communication.' }), { title: 'Supports d’information', bodyClass: 'flush' })}
        ${can(ctx.user, 'communication.edit') ? card(`
          <form method="post" action="/communication" class="form-grid one">
            ${csrfField(ctx.csrf)}
            <div class="field"><label>Titre <span class="req">*</span></label><input name="titre" required></div>
            <div class="field"><label>Type de support</label><select name="type_support">${['Note de service', 'Information', 'Rappel', 'Communication institutionnelle'].map(t => `<option>${t}</option>`).join('')}</select></div>
            <div class="field"><label>Destinataires</label><select name="destinataires">${['Tous les organismes', 'Tous les assurés', 'Agents CRT', 'Organismes en retard', 'Assurés débiteurs'].map(t => `<option>${t}</option>`).join('')}</select></div>
            <div class="field"><label>Contenu <span class="req">*</span></label><textarea name="contenu" rows="6" required></textarea></div>
            <div class="field"><label>Statut</label><select name="statut"><option>Brouillon</option><option>Publié</option></select></div>
            <div class="form-actions"><button class="btn primary" type="submit">Enregistrer</button></div>
          </form>`, { title: 'Nouveau support' }) : card('<div class="help-box">Votre profil ne permet pas de créer des supports de communication.</div>', { title: 'Nouveau support' })}
      </div>`;
    ctx.send(ctx.page('Communication', '/communication', content, ['Module 20', 'Communication']));
  });

  router.post('/communication', 'communication.edit', (ctx) => {
    const b = ctx.body;
    if (!b.titre || !b.contenu) {
      ctx.flash('error', 'Le titre et le contenu sont obligatoires.');
      return ctx.redirect('/communication');
    }
    const statut = b.statut === 'Publié' ? 'Publié' : 'Brouillon';
    const res = run(
      `INSERT INTO communications (titre, type_support, destinataires, contenu, date_publication, statut, created_by, created_at)
       VALUES (?,?,?,?,?,?,?,?)`,
      b.titre, b.type_support || 'Information', b.destinataires || 'Tous les organismes', b.contenu,
      statut === 'Publié' ? todayISO() : null, statut, ctx.user.id, nowStamp()
    );
    const id = Number(res.lastInsertRowid);
    audit(ctx.user, 'Communication', id, 'Création', '', `${b.titre} — ${statut}`);
    ctx.flash('success', `Support « ${b.titre} » enregistré.`);
    ctx.redirect(`/communication/${id}`);
  });

  router.get('/communication/:id', 'view', (ctx) => {
    const c = one('SELECT c.*, u.nom AS auteur FROM communications c LEFT JOIN users u ON u.id = c.created_by WHERE c.id = ?', Number(ctx.params.id));
    if (!c) return ctx.send('<h1>Support introuvable</h1>', 404);
    const content = `
      ${pageHead(c.titre, `${c.type_support || 'Information'} · ${c.destinataires || '—'}`, `${c.statut !== 'Publié' && can(ctx.user, 'communication.edit') ? `<form method="post" action="/communication/${c.id}/publier" class="inline-form">${csrfField(ctx.csrf)}<button class="btn primary" type="submit">Publier</button></form>` : ''}<button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 20', 'Communication', c.titre])}
      ${card(`
        <div class="print-head"><h2>CAISSE DE RETRAITES DU TOGO</h2><p>Direction de l'Immatriculation et du Recouvrement</p></div>
        <div class="kv-row"><span>Type</span><strong>${esc(c.type_support || '—')}</strong></div>
        <div class="kv-row"><span>Destinataires</span><strong>${esc(c.destinataires || '—')}</strong></div>
        <div class="kv-row"><span>Statut</span><strong>${genericBadge(c.statut)}</strong></div>
        <div class="kv-row"><span>Publication</span><strong>${fmtDate(c.date_publication)}</strong></div>
        <div class="kv-row"><span>Auteur</span><strong>${esc(c.auteur || '—')}</strong></div>
        <div class="mt16" style="white-space:pre-line;font-size:13px;line-height:1.7">${esc(c.contenu)}</div>
      `, { title: 'Contenu du support' })}`;
    ctx.send(ctx.page(c.titre, '/communication', content, ['Module 20', 'Communication', c.titre]));
  });

  router.post('/communication/:id/publier', 'communication.edit', (ctx) => {
    const c = one('SELECT * FROM communications WHERE id = ?', Number(ctx.params.id));
    if (!c) return ctx.send('<h1>Support introuvable</h1>', 404);
    run("UPDATE communications SET statut = 'Publié', date_publication = COALESCE(date_publication, ?) WHERE id = ?", todayISO(), c.id);
    audit(ctx.user, 'Communication', c.id, 'Publication', c.statut, 'Publié');
    ctx.flash('success', 'Support publié.');
    ctx.redirect(`/communication/${c.id}`);
  });

  // ---------------- Import / Export ----------------
  const MODELES = {
    assures: {
      title: 'Référentiel des assurés',
      headers: ['matricule', 'nom', 'prenom', 'sexe', 'date_naissance', 'lieu_naissance', 'telephone', 'date_prise_service', 'date_nomination', 'date_titularisation', 'corps', 'categorie', 'grade', 'echelon', 'indice', 'bonification', 'date_retraite', 'position', 'organisme_code'],
      sample: [
        ['FP-900001', 'KOFFI', 'Ama', 'F', '1985-04-12', 'Lomé', '90 00 00 01', '2010-10-01', '2011-01-01', '2012-01-01', 'Enseignement', 'A', '1', '3', '650', '0', '2045-04-12', 'Actif', 'MIN-EDU'],
        ['FP-900002', 'ADJOVI', 'Kossi', 'M', '1979-09-03', 'Sokodé', '90 00 00 02', '2005-03-15', '2006-01-01', '2007-01-01', 'Santé', 'B', '2', '2', '520', '10', '2039-09-03', 'Actif', 'MIN-SANTE']
      ]
    },
    declarations: {
      title: 'Déclaration de cotisations',
      headers: ['matricule', 'montant'],
      sample: [['FP-000001', '45000'], ['FP-000002', '52000'], ['FP-000003', '38750']]
    },
    paiements: {
      title: 'Paiements de cotisations',
      headers: ['organisme_code', 'date_paiement', 'montant', 'mode_paiement', 'reference_bancaire', 'declaration_reference', 'dossier_reference', 'piece'],
      sample: [['MIN-EDU', '2026-06-30', '1250000', 'Virement', 'BOA-2026-7781', 'DEC-2026-00042', '', 'avis_virement_juin.pdf']]
    }
  };

  router.get('/import-export/modele/:type', 'view', (ctx) => {
    const m = MODELES[String(ctx.params.type)];
    if (!m) return ctx.send('<h1>Modèle introuvable</h1>', 404);
    const lines = [m.headers.map(csvSafe).join(';'), ...m.sample.map(r => r.map(csvSafe).join(';'))];
    sendDownload(ctx, `\uFEFF${lines.join('\r\n')}\r\n`, `modele-${ctx.params.type}.csv`, 'text/csv; charset=utf-8');
  });

  router.get('/import-export', 'view', (ctx) => {
    const extractions = q('SELECT * FROM extractions ORDER BY id DESC LIMIT 10');
    const exRows = extractions.map(x => [
      td(esc(x.type_etat)),
      td(esc(x.format)),
      td(esc(x.periode || '—')),
      td(String(x.nb_lignes || 0), 'num'),
      td(esc(x.user_nom || '—')),
      td(fmtDateTime(x.date_extraction))
    ]);
    const modeleRows = Object.entries(MODELES).map(([key, m]) => [
      td(esc(m.title)),
      td(`<span class="mono">${m.headers.slice(0, 6).map(esc).join('; ')}…</span>`),
      td(`<a class="btn xs" href="/import-export/modele/${key}">${icon('download', 13)} Télécharger</a>`, 'actions')
    ]);
    const content = `
      ${pageHead('Import / Export', 'Échanges de données avec les organismes et les outils institutionnels.', `<a class="btn" href="/etats">${icon('file', 16)} États et exports</a>`, ['Module 10', 'Import / Export'])}
      <div class="stats">
        ${statCard({ label: 'Déclarations', value: one('SELECT COUNT(*) AS n FROM declarations').n, hint: 'Saisies et importées', iconName: 'file' })}
        ${statCard({ label: 'Paiements', value: one('SELECT COUNT(*) AS n FROM paiements').n, hint: 'Enregistrements comptables', iconName: 'wallet' })}
        ${statCard({ label: 'Assurés', value: one('SELECT COUNT(*) AS n FROM assures').n, hint: 'Référentiel individuel', iconName: 'users' })}
        ${statCard({ label: 'Exports réalisés', value: one('SELECT COUNT(*) AS n FROM extractions').n, hint: 'Journalisés et traçables', tone: 'info', iconName: 'download' })}
      </div>
      <div class="grid grid-2">
        ${card(`
          <div class="kv-row"><span>Import de déclarations</span><strong><a class="btn xs" href="/declarations/import">Ouvrir</a></strong></div>
          <div class="kv-row"><span>Import de paiements</span><strong><a class="btn xs" href="/paiements/nouveau">Saisir</a></strong></div>
          <div class="kv-row"><span>Export des états</span><strong><a class="btn xs" href="/etats">Ouvrir</a></strong></div>
          <div class="callout mt16">${icon('shield', 18)}<div>Les fichiers importés sont contrôlés : format, matricules, doublons, montants et pièces justificatives. Les rejets sont tracés.</div></div>
        `, { title: 'Opérations courantes' })}
        ${card(`<div class="help-box"><b>Formats acceptés</b><br>CSV en UTF-8, séparateur « ; », virgule ou tabulation. La première ligne peut contenir les en-têtes.<br><br>Les exports institutionnels sont disponibles en CSV, Excel et impression PDF. Chaque export est enregistré pour la traçabilité.</div>
        <div class="mt16"><a class="btn" href="/controles">Contrôler les données</a></div>`, { title: 'Bonnes pratiques' })}
      </div>
      ${card(dataTable(['Modèle', 'Colonnes', ''], modeleRows, { empty: 'Aucun modèle.' }), { title: 'Modèles CSV', subtitle: 'Fichiers d’exemple pour préparer les échanges.', bodyClass: 'flush' })}
      ${card(dataTable(['État', 'Format', 'Période', 'Lignes', 'Utilisateur', 'Date'], exRows, { empty: 'Aucun export réalisé.' }), { title: 'Journal des extractions', bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Import / Export', '/import-export', content, ['Module 10', 'Import / Export']));
  });
}
