import crypto from 'node:crypto';
import { one, run, q, audit } from './db.js';
import { nowStamp } from './util.js';

export const PROFILS = ['Administrateur', 'Direction', 'Superviseur', 'Contrôleur', 'Comptable', 'Agent Recouvrement', 'Agent de saisie'];

const ROLE_PERMS = {
  'Administrateur': ['*'],
  'Direction': ['view', 'dossiers.validate', 'declarations.validate', 'etats.export', 'audit.view', 'recouvrement.edit'],
  'Superviseur': ['view', 'assures.edit', 'carrieres.edit', 'carrieres.validate', 'indices.edit', 'organismes.edit', 'declarations.create', 'declarations.validate', 'declarations.import', 'controles.run', 'dossiers.edit', 'dossiers.validate', 'dossiers.notify', 'recouvrement.edit', 'communication.edit', 'etats.export'],
  'Contrôleur': ['view', 'carrieres.edit', 'carrieres.validate', 'indices.edit', 'controles.view', 'controles.run', 'dossiers.edit', 'dossiers.validate', 'etats.export'],
  'Comptable': ['view', 'paiements.create', 'paiements.rapprocher', 'etats.export'],
  'Agent Recouvrement': ['view', 'dossiers.edit', 'dossiers.notify', 'recouvrement.edit', 'etats.export'],
  'Agent de saisie': ['view', 'assures.edit', 'carrieres.edit', 'declarations.create', 'declarations.import', 'paiements.create', 'etats.export']
};

export function can(user, perm) {
  if (!user) return false;
  const perms = ROLE_PERMS[user.profil] || [];
  return perms.includes('*') || perms.includes(perm);
}

export function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
}

export function verifyPassword(password, stored) {
  if (!stored) return false;
  const [algo, salt, hash] = stored.split('$');
  if (algo !== 'scrypt' || !salt || !hash) return false;
  const test = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(test, 'hex'), Buffer.from(hash, 'hex'));
}

export function createUser({ login, password, nom, profil, email = '', telephone = '' }) {
  const now = nowStamp();
  const res = run(
    'INSERT INTO users (login, password_hash, nom, profil, email, telephone, actif, created_at) VALUES (?,?,?,?,?,?,1,?)',
    login, hashPassword(password), nom, profil, email, telephone, now
  );
  return Number(res.lastInsertRowid);
}

export function authenticate(login, password) {
  const user = one('SELECT * FROM users WHERE login = ? AND actif = 1', String(login || '').trim());
  if (!user || !verifyPassword(String(password || ''), user.password_hash)) return null;
  run('UPDATE users SET derniere_connexion = ? WHERE id = ?', nowStamp(), user.id);
  return user;
}

export function createSession(userId) {
  const token = crypto.randomBytes(32).toString('hex');
  const csrf = crypto.randomBytes(24).toString('hex');
  const created = new Date();
  const expires = new Date(created.getTime() + 8 * 3600 * 1000);
  run(
    'INSERT INTO sessions (token, user_id, csrf, created_at, expires_at) VALUES (?,?,?,?,?)',
    token, userId, csrf, created.toISOString(), expires.toISOString()
  );
  return { token, csrf, expires };
}

export function getSession(token) {
  if (!token) return null;
  const row = one(
    `SELECT s.token, s.csrf, s.expires_at, u.id, u.login, u.nom, u.profil, u.email, u.actif
     FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?`, token);
  if (!row) return null;
  if (new Date(row.expires_at) < new Date() || !row.actif) {
    destroySession(token);
    return null;
  }
  return { session: { token: row.token, csrf: row.csrf }, user: { id: row.id, login: row.login, nom: row.nom, profil: row.profil, email: row.email } };
}

export function destroySession(token) {
  if (token) run('DELETE FROM sessions WHERE token = ?', token);
}

export function cleanupSessions() {
  run('DELETE FROM sessions WHERE expires_at < ?', new Date().toISOString());
}

export function listUsers() {
  return q('SELECT id, login, nom, profil, email, telephone, actif, derniere_connexion, created_at FROM users ORDER BY nom');
}

export function changePassword(user, newPassword, actor) {
  run('UPDATE users SET password_hash = ? WHERE id = ?', hashPassword(newPassword), user.id);
  audit(actor, 'Utilisateur', user.id, 'Modification du mot de passe', '—', 'Mot de passe réinitialisé');
}
