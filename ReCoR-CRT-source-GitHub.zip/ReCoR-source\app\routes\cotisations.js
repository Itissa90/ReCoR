import { q, one, run, audit, getParam, nextReference } from '../db.js';
import { can } from '../auth.js';
import { calcMois, theoreticalForOrganismMonth, rebuildComptes, refreshDossierTotals } from '../calc.js';
import { runControles, createDossierFromAnomaly } from '../controls.js';
import { storePiece } from '../files.js';
import { pageHead, card, dataTable, td, pagination, csrfField, badge, genericBadge, dossierBadge, statCard, icon, progress } from '../render.js';
import { esc, money, num, int, fmtDate, fmtDateTime, monthLabel, monthLast, addMonths, paginate, todayISO, ANOMALIES, ageDays } from '../util.js';

function orgSelect(selected, name = 'organisme_id') {
  const orgs = q('SELECT * FROM organismes ORDER BY nom');
  return orgs.map(o => `<option value="${o.id}" ${Number(selected) === o.id ? 'selected' : ''}>${esc(o.sigle || o.code)} — ${esc(o.nom)}</option>`).join('');
}

function parseLignes(text) {
  const raw = String(text || '').replace(/\r/g, '').trim();
  if (!raw) return [];
  const lines = raw.split('\n').map(l => l.trim()).filter(Boolean);
  const delim = lines[0].includes(';') ? ';' : lines[0].includes('\t') ? '\t' : ',';
  const out = [];
  for (const line of lines) {
    const parts = line.split(delim).map(s => s.trim().replace(/^"|"$/g, ''));
    if (!parts[0] || /matricule/i.test(parts[0])) continue;
    const montant = num(parts[1], NaN);
    if (!Number.isFinite(montant)) continue;
    out.push({ matricule: parts[0], montant });
  }
  return out;
}

function expectedAssures(orgId, periode) {
  return q('SELECT * FROM assures WHERE organisme_id = ? AND statut IN (?,?)', orgId, 'Actif', 'Suspendu')
    .filter(a => !(a.date_prise_service && a.date_prise_service.slice(0, 7) > periode))
    .filter(a => !(a.date_cessation && a.date_cessation.slice(0, 7) < periode));
}

function createLines(declId, orgId, periode) {
  const cache = {};
  let count = 0;
  for (const a of expectedAssures(orgId, periode)) {
    const c = calcMois(a.id, periode, cache);
    if (!c) continue;
    run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
      declId, a.matricule, a.id, c.theorique, 'Conforme');
    count++;
  }
  return count;
}

export function register(router) {
  // ---------------- Déclarations ----------------
  router.get('/declarations', 'view', (ctx) => {
    const f = {
      q: String(ctx.query.q || '').trim(), organisme: String(ctx.query.organisme || ''),
      statut: String(ctx.query.statut || ''), periode: String(ctx.query.periode || '')
    };
    const page = int(ctx.query.page, 1);
    const where = [];
    const params = [];
    if (f.q) { where.push('(d.reference LIKE ? OR o.nom LIKE ? OR o.code LIKE ?)'); const t = `%${f.q}%`; params.push(t, t, t); }
    if (f.organisme) { where.push('d.organisme_id = ?'); params.push(Number(f.organisme)); }
    if (f.statut) { where.push('d.statut = ?'); params.push(f.statut); }
    if (f.periode) { where.push('d.periode = ?'); params.push(f.periode); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM declarations d JOIN organismes o ON o.id = d.organisme_id ${w}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(
      `SELECT d.*, o.nom AS organisme_nom, o.sigle FROM declarations d JOIN organismes o ON o.id = d.organisme_id ${w}
       ORDER BY d.periode DESC, d.id DESC LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(d => [
      td(`<a href="/declarations/${d.id}" class="main-cell mono">${esc(d.reference)}</a><span class="sub">${esc(d.type_declaration || 'Mensuelle')}</span>`),
      td(`<a href="/organismes/${d.organisme_id}">${esc(d.sigle || d.organisme_nom)}</a>`),
      td(monthLabel(d.periode)),
      td(String(d.nb_assures), 'num'),
      td(money(d.montant_declare), 'num'),
      td(fmtDate(d.date_reception)),
      td(genericBadge(d.statut)),
      td(`<div class="table-actions"><a class="btn xs" href="/declarations/${d.id}">Ouvrir</a></div>`, 'actions')
    ]);
    const stats = one(`SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN statut='Validé' THEN montant_declare ELSE 0 END),0) AS montant,
      SUM(CASE WHEN statut IN ('Soumis','Brouillon') THEN 1 ELSE 0 END) AS attente FROM declarations`);
    const content = `
      ${pageHead('Déclarations', 'Saisie, import et contrôle des déclarations de cotisations.', `${can(ctx.user, 'declarations.create') ? `<a class="btn" href="/declarations/import">${icon('download', 16)} Importer un fichier</a><a class="btn primary" href="/declarations/nouvelle">${icon('plus', 16)} Nouvelle déclaration</a>` : ''}`, ['Module 06', 'Déclarations'])}
      <div class="stats">
        ${statCard({ label: 'Déclarations enregistrées', value: stats.total, hint: 'Toutes périodes', iconName: 'file' })}
        ${statCard({ label: 'Montant déclaré validé', value: money(stats.montant), hint: 'Base du compte cotisant', iconName: 'wallet' })}
        ${statCard({ label: 'En attente de traitement', value: stats.attente || 0, hint: 'Brouillon ou soumis', tone: 'warn', iconName: 'clock' })}
        ${statCard({ label: 'Taux de validation', value: `${stats.total ? Math.round((one("SELECT COUNT(*) AS n FROM declarations WHERE statut='Validé'").n / stats.total) * 100) : 0} %`, hint: 'Déclarations validées', tone: 'info', iconName: 'check' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/declarations">
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(f.q)}" placeholder="Référence ou organisme"></div>
          <div class="field"><label>Organisme</label><select name="organisme"><option value="">Tous</option>${orgSelect(f.organisme)}</select></div>
          <div class="field"><label>Période</label><input type="month" name="periode" value="${esc(f.periode)}"></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Brouillon','Soumis','Validé','Rejeté'].map(s => `<option ${f.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/declarations">Réinitialiser</a>
        </form>
        ${dataTable(['Référence', 'Organisme', 'Période', 'Assurés', 'Montant déclaré', 'Réception', 'Statut', ''], trs, { empty: 'Aucune déclaration.' })}
        ${pagination(p, '/declarations', f)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Déclarations', '/declarations', content, ['Module 06', 'Déclarations']));
  });

  router.get('/declarations/nouvelle', 'declarations.create', (ctx) => {
    const orgId = Number(ctx.query.organisme || 0);
    const periode = /^\d{4}-\d{2}$/.test(ctx.query.periode || '') ? ctx.query.periode : new Date().toISOString().slice(0, 7);
    const content = `
      ${pageHead('Nouvelle déclaration', 'Saisie manuelle avec génération automatique du détail par assuré.', '<a class="btn" href="/declarations">Annuler</a>', ['Module 06', 'Déclarations', 'Création'])}
      <form method="post" action="/declarations" enctype="multipart/form-data" class="card"><div class="card-body">
        ${csrfField(ctx.csrf)}
        <div class="form-grid">
          <div class="field span2"><label>Organisme cotisant <span class="req">*</span></label><select name="organisme_id" required><option value="">Choisir…</option>${orgSelect(orgId)}</select></div>
          <div class="field"><label>Période (mois / année) <span class="req">*</span></label><input type="month" name="periode" required value="${esc(periode)}"></div>
          <div class="field"><label>Date de réception <span class="req">*</span></label><input type="date" name="date_reception" required value="${todayISO()}"></div>
          <div class="field"><label>Type de déclaration</label><select name="type_declaration">${['Mensuelle','Rectificative','Complémentaire'].map(t => `<option>${t}</option>`).join('')}</select></div>
          <div class="field"><label>Nombre d'assurés</label><input type="number" name="nb_assures" min="0" placeholder="Calculé automatiquement"></div>
          <div class="field"><label>Montant déclaré (FCFA)</label><input type="number" step="0.01" name="montant_declare" min="0" placeholder="Calculé à partir du détail"></div>
          <div class="field"><label>Fichier source</label><input name="fichier_source" placeholder="declaration_organisme_2026-10.csv"></div>
          <div class="field"><label>Référence de la pièce</label><input name="piece_ref" placeholder="bordereau_organisme_2026-10.pdf"></div>
          <div class="field span2"><label>Pièce justificative (PDF, image)</label><input type="file" name="piece" accept=".pdf,.png,.jpg,.jpeg"><span class="hint">La pièce (fichier ou référence) est obligatoire pour valider la déclaration.</span></div>
          <div class="field span2"><label>Détail par assuré (facultatif)</label><textarea name="lignes" placeholder="matricule;montant&#10;FP-000001;45000&#10;FP-000002;52000"></textarea><span class="hint">Format : un assuré par ligne, matricule et montant séparés par « ; ». Laissez vide pour générer automatiquement le détail au montant théorique.</span></div>
          <div class="field span2"><label class="checkline"><input type="checkbox" name="generer" value="1" checked> Générer automatiquement les lignes au montant théorique si aucun détail n'est saisi</label></div>
        </div>
        <div class="callout mt16">${icon('shield', 18)}<div><strong>Contrôles automatiques.</strong> À l'enregistrement, la déclaration est soumise aux contrôles de doublon, période, matricule, organisme, cohérence du montant et pièce justificative.</div></div>
        <div class="form-actions"><button class="btn primary" type="submit">Enregistrer la déclaration</button><a class="btn" href="/declarations">Annuler</a></div>
      </div></form>`;
    ctx.send(ctx.page('Nouvelle déclaration', '/declarations', content, ['Module 06', 'Déclarations']));
  });

  router.post('/declarations', 'declarations.create', (ctx) => {
    const b = ctx.body;
    const orgId = Number(b.organisme_id || 0);
    const periode = String(b.periode || '');
    if (!orgId || !/^\d{4}-\d{2}$/.test(periode) || !b.date_reception) {
      ctx.flash('error', "L'organisme, la période et la date de réception sont obligatoires.");
      return ctx.redirect('/declarations/nouvelle');
    }
    const parsed = parseLignes(b.lignes);
    const ref = nextReference('DEC');
    const res = run(
      `INSERT INTO declarations (reference, organisme_id, periode, date_reception, type_declaration, nb_assures, montant_declare,
        fichier_source, piece, agent_id, statut, observation, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      ref, orgId, periode, b.date_reception, b.type_declaration || 'Mensuelle', 0, 0,
      b.fichier_source || '', '', ctx.user.id, 'Brouillon', '', new Date().toISOString().slice(0, 19).replace('T', ' ')
    );
    const id = Number(res.lastInsertRowid);
    let nb = 0;
    if (parsed.length) {
      for (const l of parsed) {
        const assure = one('SELECT id FROM assures WHERE matricule = ?', l.matricule);
        run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
          id, l.matricule, assure?.id || null, l.montant, assure ? 'Conforme' : 'Anomalie');
        nb++;
      }
    } else if (b.generer === '1') {
      nb = createLines(id, orgId, periode);
    }
    const sum = one('SELECT COALESCE(SUM(montant),0) AS m FROM declaration_lignes WHERE declaration_id = ?', id).m;
    const montant = parsed.length || b.generer === '1' ? sum : Math.max(0, num(b.montant_declare));
    const pieceName = storePiece(ctx.files?.piece, { entite: 'declaration', entiteId: id, userId: ctx.user.id }) || b.piece_ref || '';
    run('UPDATE declarations SET nb_assures = ?, montant_declare = ?, piece = ? WHERE id = ?',
      int(b.nb_assures, 0) || nb, montant, pieceName, id);
    audit(ctx.user, 'Déclaration', id, 'Création', '', `${ref} — ${montant} FCFA`, b.observation || '', pieceName);
    ctx.flash('success', `Déclaration ${ref} enregistrée en brouillon.`);
    ctx.redirect(`/declarations/${id}`);
  });

  router.get('/declarations/import', 'declarations.import', (ctx) => {
    const content = `
      ${pageHead('Import de déclarations', 'Chargement d’un fichier CSV de cotisations par organisme et période.', '<a class="btn" href="/declarations">Annuler</a>', ['Module 06', 'Déclarations', 'Import'])}
      <div class="grid grid-2">
        ${card(`
          <form method="post" action="/declarations/import" enctype="multipart/form-data" class="form-grid one">
            ${csrfField(ctx.csrf)}
            <div class="field"><label>Organisme cotisant <span class="req">*</span></label><select name="organisme_id" required><option value="">Choisir…</option>${orgSelect('')}</select></div>
            <div class="field"><label>Période <span class="req">*</span></label><input type="month" name="periode" required value="${new Date().toISOString().slice(0, 7)}"></div>
            <div class="field"><label>Date de réception <span class="req">*</span></label><input type="date" name="date_reception" required value="${todayISO()}"></div>
            <div class="field"><label>Fichier CSV <span class="req">*</span></label><input type="file" name="fichier" accept=".csv,.txt" required><span class="hint">Colonnes attendues : matricule ; montant.</span></div>
            <div class="field"><label>Référence de la pièce</label><input name="piece_ref" placeholder="bordereau_organisme_2026-10.pdf"></div>
            <div class="field"><label>Pièce justificative</label><input type="file" name="piece" accept=".pdf,.png,.jpg,.jpeg"></div>
            <div class="form-actions"><button class="btn primary" type="submit">Importer et contrôler</button></div>
          </form>`, { title: 'Fichier de déclaration' })}
        ${card(`
          <div class="help-box"><b>Format accepté</b><br>Un en-tête est toléré. Le séparateur peut être « ; », une virgule ou une tabulation.<br><br>
          <span class="mono">matricule;montant<br>FP-000001;45000<br>FP-000002;52000</span></div>
          <div class="callout mt16">${icon('shield', 18)}<div><strong>Après import :</strong> la déclaration est créée au statut « Soumis ». Les matricules inconnus et les écarts sont signalés par le module de contrôle (A04, A05, A06).</div></div>
          <div class="mt16"><a class="btn" href="/controles">Ouvrir le centre de contrôle</a></div>`, { title: 'Règles d’import' })}
      </div>`;
    ctx.send(ctx.page('Import de déclarations', '/declarations', content, ['Module 06', 'Déclarations', 'Import']));
  });

  router.post('/declarations/import', 'declarations.import', (ctx) => {
    const b = ctx.body;
    const orgId = Number(b.organisme_id || 0);
    const periode = String(b.periode || '');
    const file = ctx.files?.fichier;
    if (!orgId || !/^\d{4}-\d{2}$/.test(periode) || !b.date_reception || !file || !file.data?.length) {
      ctx.flash('error', 'Organisme, période, date de réception et fichier CSV sont obligatoires.');
      return ctx.redirect('/declarations/import');
    }
    const lines = parseLignes(file.data.toString('utf8'));
    if (!lines.length) {
      ctx.flash('error', 'Le fichier ne contient aucune ligne exploitable (matricule ; montant).');
      return ctx.redirect('/declarations/import');
    }
    const ref = nextReference('DEC');
    const res = run(
      `INSERT INTO declarations (reference, organisme_id, periode, date_reception, type_declaration, nb_assures, montant_declare,
        fichier_source, piece, agent_id, statut, observation, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      ref, orgId, periode, b.date_reception, 'Mensuelle', 0, 0, file.filename || '', '', ctx.user.id, 'Soumis', 'Import CSV',
      new Date().toISOString().slice(0, 19).replace('T', ' ')
    );
    const id = Number(res.lastInsertRowid);
    let unknown = 0;
    for (const l of lines) {
      const assure = one('SELECT id FROM assures WHERE matricule = ?', l.matricule);
      if (!assure) unknown++;
      run('INSERT INTO declaration_lignes (declaration_id, matricule, assure_id, montant, statut) VALUES (?,?,?,?,?)',
        id, l.matricule, assure?.id || null, l.montant, assure ? 'Conforme' : 'Anomalie');
    }
    const sum = one('SELECT COALESCE(SUM(montant),0) AS m FROM declaration_lignes WHERE declaration_id = ?', id).m;
    const pieceName = storePiece(ctx.files?.piece, { entite: 'declaration', entiteId: id, userId: ctx.user.id }) || b.piece_ref || '';
    run('UPDATE declarations SET nb_assures = ?, montant_declare = ?, piece = ? WHERE id = ?', lines.length, sum, pieceName, id);
    audit(ctx.user, 'Déclaration', id, 'Import', '', `${ref} — ${lines.length} lignes`, 'Import CSV', file.filename);
    ctx.flash(unknown ? 'warn' : 'success', `Déclaration ${ref} importée : ${lines.length} ligne(s)${unknown ? `, ${unknown} matricule(s) inconnu(s)` : ''}.`);
    ctx.redirect(`/declarations/${id}`);
  });

  router.get('/declarations/:id', 'view', (ctx) => {
    const d = one('SELECT d.*, o.nom AS organisme_nom, o.sigle, o.code AS organisme_code FROM declarations d JOIN organismes o ON o.id = d.organisme_id WHERE d.id = ?', Number(ctx.params.id));
    if (!d) return ctx.send('<h1>Déclaration introuvable</h1>', 404);
    const lignes = q('SELECT l.*, a.nom, a.prenom, a.organisme_id AS assure_org FROM declaration_lignes l LEFT JOIN assures a ON a.id = l.assure_id WHERE l.declaration_id = ? ORDER BY l.id', d.id);
    const paiements = q('SELECT * FROM paiements WHERE declaration_id = ? ORDER BY date_paiement', d.id);
    const paye = paiements.filter(p => p.statut === 'Rapproché').reduce((s, p) => s + Number(p.montant), 0);
    const theorique = theoreticalForOrganismMonth(d.organisme_id, d.periode);
    const anomalies = q('SELECT * FROM anomalies WHERE declaration_id = ?', d.id);
    const unknown = lignes.filter(l => !l.assure_id).length;
    const wrongOrg = lignes.filter(l => l.assure_id && l.assure_org && Number(l.assure_org) !== Number(d.organisme_id)).length;
    const duplicate = one("SELECT COUNT(*) AS n FROM declarations WHERE organisme_id = ? AND periode = ? AND statut <> 'Rejeté'", d.organisme_id, d.periode).n > 1;
    const late = d.date_reception && new Date(d.date_reception) > new Date(monthLast(d.periode) + 'T00:00:00Z').getTime() + Number(getParam('DELAI_DECLARATION_JOURS', 30)) * 86400000;
    const lineRows = lignes.map(l => [
      td(`<span class="mono">${esc(l.matricule)}</span>`),
      td(l.assure_id ? `<a href="/assures/${l.assure_id}">${esc(l.nom || '')} ${esc(l.prenom || '')}</a>` : '<span class="text-danger">Matricule inconnu</span>'),
      td(l.assure_org && Number(l.assure_org) !== Number(d.organisme_id) ? `<span class="text-warn">Mauvais organisme</span>` : '—'),
      td(money(l.montant), 'num'),
      td(genericBadge(l.statut))
    ]);
    const anomalyRows = anomalies.map(a => [
      td(`<span class="main-cell">${esc(a.code)}</span> ${esc(a.libelle)}<span class="sub">${esc(a.detail || '')}</span>`),
      td(genericBadge(a.criticite)),
      td(a.dossier_id ? `<a class="btn xs" href="/dossiers/${a.dossier_id}">Dossier</a>` : '', 'actions')
    ]);
    const canValidate = can(ctx.user, 'declarations.validate');
    const actions = `${d.statut === 'Brouillon' && can(ctx.user, 'declarations.create') ? `<form method="post" action="/declarations/${d.id}/transition" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="action" value="soumettre"><button class="btn primary" type="submit">Soumettre au contrôle</button></form>` : ''}
      ${['Soumis','Brouillon'].includes(d.statut) && canValidate ? `<form method="post" action="/declarations/${d.id}/transition" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="action" value="valider"><button class="btn primary" type="submit">Valider</button></form>
      <form method="post" action="/declarations/${d.id}/transition" class="inline-form" data-confirm="Rejeter cette déclaration ?">${csrfField(ctx.csrf)}<input type="hidden" name="action" value="rejeter"><button class="btn danger" type="submit">Rejeter</button></form>` : ''}`;
    const content = `
      ${pageHead(`Déclaration ${d.reference}`, `${d.organisme_nom} · ${monthLabel(d.periode)}`, actions + `<button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 06', 'Déclarations', d.reference])}
      <div class="stats">
        ${statCard({ label: 'Montant déclaré', value: money(d.montant_declare), hint: `${d.nb_assures} assuré(s)`, iconName: 'file' })}
        ${statCard({ label: 'Montant théorique', value: money(theorique), hint: 'Calcul parameteré', tone: 'info', iconName: 'calc' })}
        ${statCard({ label: 'Écart théorique / déclaré', value: money(Math.max(0, theorique - Number(d.montant_declare))), hint: theorique > Number(d.montant_declare) ? 'Sous-déclaration potentielle' : 'Conforme', tone: theorique > Number(d.montant_declare) ? 'bad' : 'ok', iconName: 'alert' })}
        ${statCard({ label: 'Paiements rapprochés', value: money(paye), hint: `${paiements.length} paiement(s)`, tone: 'info', iconName: 'wallet' })}
      </div>
      <div class="grid grid-2">
        ${card(`<dl class="dl tight">
          <dt>Référence</dt><dd class="mono">${esc(d.reference)}</dd>
          <dt>Organisme</dt><dd>${esc(d.organisme_nom)}</dd>
          <dt>Période</dt><dd>${monthLabel(d.periode)}</dd>
          <dt>Type</dt><dd>${esc(d.type_declaration || 'Mensuelle')}</dd>
          <dt>Date de réception</dt><dd>${fmtDate(d.date_reception)}</dd>
          <dt>Statut</dt><dd>${genericBadge(d.statut)}</dd>
          <dt>Fichier source</dt><dd>${esc(d.fichier_source || '—')}</dd>
          <dt>Pièce justificative</dt><dd>${esc(d.piece || '—')}</dd>
          <dt>Agent de saisie</dt><dd>${esc(one('SELECT nom FROM users WHERE id = ?', d.agent_id)?.nom || '—')}</dd>
          <dt>Horodatage</dt><dd>${fmtDateTime(d.created_at)}</dd>
        </dl>`, { title: 'Informations de la déclaration' })}
        ${card(`
          <div class="kv-row"><span>Doublon détecté</span><strong>${duplicate ? badge('Oui — A03', 'bad') : badge('Non', 'ok')}</strong></div>
          <div class="kv-row"><span>Déclaration en retard</span><strong>${late ? badge('Oui — A02', 'warn') : badge('Non', 'ok')}</strong></div>
          <div class="kv-row"><span>Matricules inconnus</span><strong>${unknown ? badge(`${unknown} — A04`, 'bad') : badge('Aucun', 'ok')}</strong></div>
          <div class="kv-row"><span>Assurés mal rattachés</span><strong>${wrongOrg ? badge(`${wrongOrg} — A05`, 'warn') : badge('Aucun', 'ok')}</strong></div>
          <div class="kv-row"><span>Écart au théorique</span><strong>${theorique > Number(d.montant_declare) + Number(getParam('TOLERANCE_ECART', 1)) ? badge('Sous-déclaration — A06', 'bad') : badge('Conforme', 'ok')}</strong></div>
          <div class="mt16"><a class="btn" href="/controles">Centre de contrôle</a></div>`, { title: 'Résultats des contrôles' })}
      </div>
      ${card(dataTable(['Matricule', 'Assuré', 'Rattachement', 'Montant déclaré', 'État ligne'], lineRows, { empty: 'Aucun détail par assuré.' }), { title: `Détail des lignes (${lignes.length})`, subtitle: 'Le contrôle A06 compare chaque ligne au montant théorique individuel.', bodyClass: 'flush' })}
      ${card(dataTable(['Anomalie', 'Criticité', ''], anomalyRows, { empty: 'Aucune anomalie liée à cette déclaration.' }), { title: 'Anomalies', bodyClass: 'flush' })}
      ${card(dataTable(['Référence', 'Date', 'Montant', 'Mode', 'Statut'], paiements.map(p => [
        td(`<a href="/paiements/${p.id}" class="mono">${esc(p.reference)}</a>`), td(fmtDate(p.date_paiement)), td(money(p.montant), 'num'), td(esc(p.mode_paiement || '—')), td(genericBadge(p.statut))
      ]), { empty: 'Aucun paiement imputé.' }), { title: 'Paiements imputés', bodyClass: 'flush' })}`;
    ctx.send(ctx.page(`Déclaration ${d.reference}`, '/declarations', content, ['Module 06', 'Déclarations', d.reference]));
  });

  router.post('/declarations/:id/transition', 'view', (ctx) => {
    const d = one('SELECT * FROM declarations WHERE id = ?', Number(ctx.params.id));
    if (!d) return ctx.send('<h1>Déclaration introuvable</h1>', 404);
    const action = ctx.body.action;
    if (action === 'soumettre') {
      if (!can(ctx.user, 'declarations.create')) return ctx.send('<h1>Accès refusé</h1>', 403);
      run("UPDATE declarations SET statut = 'Soumis' WHERE id = ?", d.id);
      audit(ctx.user, 'Déclaration', d.id, 'Soumission', d.statut, 'Soumis');
      ctx.flash('success', 'Déclaration soumise.');
    } else if (action === 'valider' || action === 'rejeter') {
      if (!can(ctx.user, 'declarations.validate')) return ctx.send('<h1>Accès refusé</h1>', 403);
      if (action === 'valider' && !d.piece) {
        ctx.flash('error', 'Impossible de valider : la pièce justificative est obligatoire.');
        return ctx.redirect(`/declarations/${d.id}`);
      }
      const statut = action === 'valider' ? 'Validé' : 'Rejeté';
      run('UPDATE declarations SET statut = ? WHERE id = ?', statut, d.id);
      audit(ctx.user, 'Déclaration', d.id, action === 'valider' ? 'Validation' : 'Rejet', d.statut, statut);
      rebuildComptes();
      ctx.flash('success', `Déclaration ${statut === 'Validé' ? 'validée et imputée aux comptes' : 'rejetée'}.`);
    }
    ctx.redirect(`/declarations/${d.id}`);
  });

  // ---------------- Paiements ----------------
  router.get('/paiements', 'view', (ctx) => {
    const f = { q: String(ctx.query.q || '').trim(), organisme: String(ctx.query.organisme || ''), statut: String(ctx.query.statut || '') };
    const page = int(ctx.query.page, 1);
    const where = []; const params = [];
    if (f.q) { where.push('(p.reference LIKE ? OR p.reference_bancaire LIKE ?)'); const t = `%${f.q}%`; params.push(t, t); }
    if (f.organisme) { where.push('p.organisme_id = ?'); params.push(Number(f.organisme)); }
    if (f.statut) { where.push('p.statut = ?'); params.push(f.statut); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM paiements p ${w}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(`SELECT p.*, o.sigle, o.nom AS organisme_nom, d.reference AS decl_ref, ds.reference AS dossier_ref FROM paiements p
      JOIN organismes o ON o.id = p.organisme_id LEFT JOIN declarations d ON d.id = p.declaration_id LEFT JOIN dossiers ds ON ds.id = p.dossier_id
      ${w} ORDER BY p.date_paiement DESC, p.id DESC LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(p => [
      td(`<a href="/paiements/${p.id}" class="main-cell mono">${esc(p.reference)}</a><span class="sub">${esc(p.mode_paiement || '—')}${p.reference_bancaire ? ' · ' + esc(p.reference_bancaire) : ''}</span>`),
      td(`<a href="/organismes/${p.organisme_id}">${esc(p.sigle || p.organisme_nom)}</a>`),
      td(fmtDate(p.date_paiement)),
      td(money(p.montant), 'num'),
      td(p.decl_ref ? `<span class="mono">${esc(p.decl_ref)}</span>` : p.dossier_ref ? `<a class="mono" href="/dossiers/${p.dossier_id}">${esc(p.dossier_ref)}</a>` : '<span class="muted">Non imputé</span>'),
      td(genericBadge(p.statut)),
      td(`<a class="btn xs" href="/paiements/${p.id}">Ouvrir</a>`, 'actions')
    ]);
    const stats = one("SELECT COUNT(*) AS n, COALESCE(SUM(montant),0) AS m, COALESCE(SUM(CASE WHEN statut='Non rapproché' THEN montant ELSE 0 END),0) AS attente FROM paiements");
    const content = `
      ${pageHead('Paiements', 'Enregistrement, imputation et rapprochement des paiements.', can(ctx.user, 'paiements.create') ? `<a class="btn primary" href="/paiements/nouveau">${icon('plus', 16)} Nouveau paiement</a>` : '', ['Module 07', 'Paiements'])}
      <div class="stats">
        ${statCard({ label: 'Paiements enregistrés', value: stats.n, hint: 'Toutes périodes', iconName: 'wallet' })}
        ${statCard({ label: 'Montant total', value: money(stats.m), hint: 'Tous statuts', iconName: 'calc' })}
        ${statCard({ label: 'En attente de rapprochement', value: money(stats.attente), hint: 'Anomalie A10', tone: 'warn', iconName: 'clock' })}
        ${statCard({ label: 'Taux de rapprochement', value: `${stats.n ? Math.round(((stats.n - one("SELECT COUNT(*) AS n FROM paiements WHERE statut='Non rapproché'").n) / stats.n) * 100) : 0} %`, hint: 'Paiements imputés', tone: 'info', iconName: 'check' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/paiements">
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(f.q)}" placeholder="Référence ou référence bancaire"></div>
          <div class="field"><label>Organisme</label><select name="organisme"><option value="">Tous</option>${orgSelect(f.organisme, 'organisme')}</select></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Non rapproché','Rapproché'].map(s => `<option ${f.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
        </form>
        ${dataTable(['Référence', 'Organisme', 'Date', 'Montant', 'Imputation', 'Statut', ''], trs, { empty: 'Aucun paiement.' })}
        ${pagination(p, '/paiements', f)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Paiements', '/paiements', content, ['Module 07', 'Paiements']));
  });

  router.get('/paiements/nouveau', 'paiements.create', (ctx) => {
    const declarations = q("SELECT d.id, d.reference, d.periode, d.montant_declare, o.sigle FROM declarations d JOIN organismes o ON o.id=d.organisme_id WHERE d.statut <> 'Rejeté' ORDER BY d.periode DESC LIMIT 200");
    const dossiers = q("SELECT id, reference, montant_du FROM dossiers WHERE statut NOT IN ('13','14','15') ORDER BY id DESC LIMIT 200");
    const selectedDecl = Number(ctx.query.declaration || 0);
    const selectedDossier = Number(ctx.query.dossier || 0);
    const content = `
      ${pageHead('Nouveau paiement', 'Enregistrement comptable et imputation à une déclaration ou un dossier.', '<a class="btn" href="/paiements">Annuler</a>', ['Module 07', 'Paiements', 'Enregistrement'])}
      <form method="post" action="/paiements" enctype="multipart/form-data" class="card"><div class="card-body">
        ${csrfField(ctx.csrf)}
        <div class="form-grid">
          <div class="field span2"><label>Organisme <span class="req">*</span></label><select name="organisme_id" required>${orgSelect('')}</select></div>
          <div class="field"><label>Date du paiement <span class="req">*</span></label><input type="date" name="date_paiement" required value="${todayISO()}"></div>
          <div class="field"><label>Montant (FCFA) <span class="req">*</span></label><input type="number" step="0.01" name="montant" min="1" required></div>
          <div class="field"><label>Mode de paiement</label><select name="mode_paiement">${['Virement','Chèque','Espèces','Mobile Money'].map(m => `<option>${m}</option>`).join('')}</select></div>
          <div class="field"><label>Référence bancaire</label><input name="reference_bancaire"></div>
          <div class="field"><label>Déclaration concernée</label><select name="declaration_id"><option value="">—</option>${declarations.map(d => `<option value="${d.id}" ${selectedDecl === d.id ? 'selected' : ''}>${esc(d.reference)} — ${esc(d.sigle)} — ${monthLabel(d.periode)} — ${money(d.montant_declare)}</option>`).join('')}</select></div>
          <div class="field"><label>Ou dossier concerné</label><select name="dossier_id"><option value="">—</option>${dossiers.map(d => `<option value="${d.id}" ${selectedDossier === d.id ? 'selected' : ''}>${esc(d.reference)} — reste ${money(d.montant_du)}</option>`).join('')}</select></div>
          <div class="field"><label>Référence de la pièce <span class="req">*</span></label><input name="piece_ref" placeholder="recu_PAY-2026-00001.pdf"></div>
          <div class="field"><label>Pièce justificative (fichier)</label><input type="file" name="piece" accept=".pdf,.png,.jpg,.jpeg"><span class="hint">Reçu, bordereau ou avis de virement. Un fichier ou une référence est obligatoire.</span></div>
        </div>
        <div class="form-actions"><button class="btn primary" type="submit">Enregistrer le paiement</button><a class="btn" href="/paiements">Annuler</a></div>
      </div></form>`;
    ctx.send(ctx.page('Nouveau paiement', '/paiements', content, ['Module 07', 'Paiements']));
  });

  router.post('/paiements', 'paiements.create', (ctx) => {
    const b = ctx.body;
    const montant = num(b.montant, 0);
    if (!b.organisme_id || !b.date_paiement || montant <= 0) {
      ctx.flash('error', "L'organisme, la date et un montant strictement positif sont obligatoires.");
      return ctx.redirect('/paiements/nouveau');
    }
    if (!ctx.files?.piece?.filename && !b.piece_ref) {
      ctx.flash('error', 'La pièce justificative (fichier ou référence) est obligatoire pour enregistrer un paiement.');
      return ctx.redirect('/paiements/nouveau');
    }
    if (b.declaration_id && b.dossier_id) {
      ctx.flash('error', 'Un paiement doit être imputé soit à une déclaration, soit à un dossier, pas aux deux.');
      return ctx.redirect('/paiements/nouveau');
    }
    const ref = nextReference('PAY');
    const res = run(
      `INSERT INTO paiements (reference, organisme_id, date_paiement, montant, mode_paiement, reference_bancaire, declaration_id, dossier_id, piece, agent_id, statut, motif, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      ref, Number(b.organisme_id), b.date_paiement, montant, b.mode_paiement || 'Virement', b.reference_bancaire || '',
      b.declaration_id ? Number(b.declaration_id) : null, b.dossier_id ? Number(b.dossier_id) : null, '', ctx.user.id,
      'Non rapproché', '', new Date().toISOString().slice(0, 19).replace('T', ' ')
    );
    const id = Number(res.lastInsertRowid);
    const pieceName = storePiece(ctx.files?.piece, { entite: 'paiement', entiteId: id, userId: ctx.user.id }) || b.piece_ref || '';
    run('UPDATE paiements SET piece = ? WHERE id = ?', pieceName, id);
    rebuildComptes();
    audit(ctx.user, 'Paiement', id, 'Création', '', `${ref} — ${montant} FCFA`, '', pieceName);
    ctx.flash('success', `Paiement ${ref} enregistré. Rapprochez-le pour l'imputer au compte.`);
    ctx.redirect(`/paiements/${id}`);
  });

  router.get('/paiements/:id', 'view', (ctx) => {
    const p = one(`SELECT p.*, o.nom AS organisme_nom, o.sigle FROM paiements p JOIN organismes o ON o.id = p.organisme_id WHERE p.id = ?`, Number(ctx.params.id));
    if (!p) return ctx.send('<h1>Paiement introuvable</h1>', 404);
    const decl = p.declaration_id ? one('SELECT * FROM declarations WHERE id = ?', p.declaration_id) : null;
    const dossier = p.dossier_id ? one('SELECT * FROM dossiers WHERE id = ?', p.dossier_id) : null;
    const declarations = q("SELECT d.id, d.reference, d.periode, d.montant_declare FROM declarations d WHERE d.organisme_id = ? AND d.statut <> 'Rejeté' ORDER BY d.periode DESC LIMIT 100", p.organisme_id);
    const dossiers = q("SELECT id, reference, montant_du FROM dossiers WHERE organisme_id = ? AND statut NOT IN ('13','14','15') ORDER BY id DESC LIMIT 100", p.organisme_id);
    const content = `
      ${pageHead(`Paiement ${p.reference}`, `${p.organisme_nom} · ${fmtDate(p.date_paiement)}`, `<button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 07', 'Paiements', p.reference])}
      <div class="grid grid-2">
        ${card(`<dl class="dl">
          <dt>Référence comptable</dt><dd class="mono">${esc(p.reference)}</dd>
          <dt>Organisme</dt><dd>${esc(p.organisme_nom)}</dd>
          <dt>Date</dt><dd>${fmtDate(p.date_paiement)}</dd>
          <dt>Montant</dt><dd class="strong">${money(p.montant)}</dd>
          <dt>Mode</dt><dd>${esc(p.mode_paiement || '—')}</dd>
          <dt>Référence bancaire</dt><dd>${esc(p.reference_bancaire || '—')}</dd>
          <dt>Déclaration</dt><dd>${decl ? `<a href="/declarations/${decl.id}" class="mono">${esc(decl.reference)}</a>` : '—'}</dd>
          <dt>Dossier</dt><dd>${dossier ? `<a href="/dossiers/${dossier.id}" class="mono">${esc(dossier.reference)}</a>` : '—'}</dd>
          <dt>Pièce</dt><dd>${esc(p.piece || '—')}</dd>
          <dt>Statut</dt><dd>${genericBadge(p.statut)}</dd>
          <dt>Agent comptable</dt><dd>${esc(one('SELECT nom FROM users WHERE id = ?', p.agent_id)?.nom || '—')}</dd>
          <dt>Enregistré le</dt><dd>${fmtDateTime(p.created_at)}</dd>
        </dl>`, { title: 'Détail du paiement' })}
        ${card(`
          <form method="post" action="/paiements/${p.id}/rapprocher" class="form-grid one">
            ${csrfField(ctx.csrf)}
            <div class="field"><label>Déclaration à imputer</label><select name="declaration_id"><option value="">—</option>${declarations.map(d => `<option value="${d.id}" ${p.declaration_id === d.id ? 'selected' : ''}>${esc(d.reference)} — ${monthLabel(d.periode)} — ${money(d.montant_declare)}</option>`).join('')}</select></div>
            <div class="field"><label>Ou dossier à imputer</label><select name="dossier_id"><option value="">—</option>${dossiers.map(d => `<option value="${d.id}" ${p.dossier_id === d.id ? 'selected' : ''}>${esc(d.reference)} — reste ${money(d.montant_du)}</option>`).join('')}</select></div>
            <div class="form-actions">
              ${can(ctx.user, 'paiements.rapprocher') ? `<button class="btn primary" type="submit">Rapprocher et imputer</button>` : '<span class="hint">Seul le profil Comptable peut rapprocher un paiement.</span>'}
            </div>
          </form>
          ${p.statut === 'Non rapproché' ? `<div class="callout mt16">${icon('alert', 18)}<div>Ce paiement alimente l'anomalie <strong>A10 — Paiement non rapproché</strong> tant qu'il n'est pas imputé.</div></div>` : `<div class="callout mt16">${icon('check', 18)}<div>Paiement rapproché : il est imputé au compte cotisant et, le cas échéant, au compte assuré.</div></div>`}`, { title: 'Rapprochement' })}
      </div>`;
    ctx.send(ctx.page(`Paiement ${p.reference}`, '/paiements', content, ['Module 07', 'Paiements', p.reference]));
  });

  router.post('/paiements/:id/rapprocher', 'paiements.rapprocher', (ctx) => {
    const p = one('SELECT * FROM paiements WHERE id = ?', Number(ctx.params.id));
    if (!p) return ctx.send('<h1>Paiement introuvable</h1>', 404);
    const declId = ctx.body.declaration_id ? Number(ctx.body.declaration_id) : null;
    const dossierId = ctx.body.dossier_id ? Number(ctx.body.dossier_id) : null;
    if (declId && dossierId) {
      ctx.flash('error', 'Choisissez une seule imputation : déclaration ou dossier.');
      return ctx.redirect(`/paiements/${p.id}`);
    }
    run("UPDATE paiements SET declaration_id = ?, dossier_id = ?, statut = 'Rapproché' WHERE id = ?",
      declId, dossierId, p.id);
    if (dossierId) {
      refreshDossierTotals(dossierId);
      const d = one('SELECT * FROM dossiers WHERE id = ?', dossierId);
      if (d) run('UPDATE dossiers SET statut = ? WHERE id = ?', Number(d.montant_du) <= 0 ? '11' : '10', d.id);
    }
    if (declId) {
      const d = one('SELECT * FROM declarations WHERE id = ?', declId);
      if (d && d.statut === 'Soumis') run("UPDATE declarations SET statut = 'Validé' WHERE id = ?", declId);
    }
    rebuildComptes();
    audit(ctx.user, 'Paiement', p.id, 'Rapprochement', p.statut, `Déclaration ${declId || '—'} / Dossier ${dossierId || '—'}`);
    ctx.flash('success', 'Paiement rapproché et imputé.');
    ctx.redirect(`/paiements/${p.id}`);
  });

  // ---------------- Contrôles et anomalies ----------------
  router.get('/controles', 'view', (ctx) => {
    const f = { code: String(ctx.query.code || ''), statut: String(ctx.query.statut || ''), criticite: String(ctx.query.criticite || '') };
    const page = int(ctx.query.page, 1);
    const where = []; const params = [];
    if (f.code) { where.push('a.code = ?'); params.push(f.code); }
    if (f.statut) { where.push('a.statut = ?'); params.push(f.statut); }
    if (f.criticite) { where.push('a.criticite = ?'); params.push(f.criticite); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM anomalies a ${w}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(
      `SELECT a.*, o.sigle, o.nom AS organisme_nom, s.matricule, s.nom AS assure_nom, s.prenom AS assure_prenom, d.reference AS dossier_ref
       FROM anomalies a LEFT JOIN organismes o ON o.id = a.organisme_id LEFT JOIN assures s ON s.id = a.assure_id
       LEFT JOIN dossiers d ON d.id = a.dossier_id ${w}
       ORDER BY CASE a.criticite WHEN 'Critique' THEN 0 WHEN 'À contrôler' THEN 1 ELSE 2 END, a.created_at DESC
       LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(a => [
      td(`<a href="/anomalies/${a.id}" class="main-cell">${esc(a.code)}</a><span class="sub">${esc(a.libelle)}</span>`),
      td(`${a.matricule ? `<a href="/assures/${a.assure_id}">${esc(a.assure_nom)} ${esc(a.assure_prenom)}</a><span class="sub mono">${esc(a.matricule)}</span>` : ''}${a.sigle ? `<a href="/organismes/${a.organisme_id}">${esc(a.sigle)}</a>` : ''}${!a.matricule && !a.sigle ? '—' : ''}`),
      td(esc(a.periode || '—')),
      td(genericBadge(a.criticite)),
      td(genericBadge(a.statut)),
      td(a.dossier_ref ? `<a class="mono" href="/dossiers/${a.dossier_id}">${esc(a.dossier_ref)}</a>` : '<span class="muted">—</span>'),
      td(`<a class="btn xs" href="/anomalies/${a.id}">Traiter</a>`, 'actions')
    ]);
    const byCode = new Map(q('SELECT code, COUNT(*) AS n FROM anomalies GROUP BY code').map(r => [r.code, r.n]));
    const cards = Object.entries(ANOMALIES).map(([code, meta]) => `
      <a class="stat-card" href="/controles?code=${code}" style="padding:12px 14px">
        <div class="stat-top"><span class="stat-label">${esc(code)}</span>${badge(meta.criticite === 'Critique' ? 'Critique' : 'À contrôler', meta.criticite === 'Critique' ? 'bad' : 'warn')}</div>
        <div class="stat-value" style="font-size:20px;margin-top:5px">${byCode.get(code) || 0}</div>
        <div class="stat-hint" style="min-height:28px">${esc(meta.libelle)}</div>
      </a>`).join('');
    const counts = one(`SELECT SUM(CASE WHEN criticite='Critique' THEN 1 ELSE 0 END) AS critiques,
      SUM(CASE WHEN criticite='À contrôler' THEN 1 ELSE 0 END) AS acontroler,
      SUM(CASE WHEN statut='Nouvelle' THEN 1 ELSE 0 END) AS nouvelles,
      COUNT(*) AS total FROM anomalies`);
    const last = getParam('DERNIER_CONTROLE', '—');
    const content = `
      ${pageHead('Contrôle', 'Détection automatique des 15 anomalies, génération des dossiers et suivi du traitement.', `${can(ctx.user, 'controles.run') ? `<form method="post" action="/controles/executer" class="inline-form">${csrfField(ctx.csrf)}<button class="btn primary" type="submit">${icon('refresh', 16)} Lancer les contrôles</button></form>` : ''}`, ['Module 08', 'Contrôle'])}
      <div class="stats">
        ${statCard({ label: 'Anomalies détectées', value: counts.total || 0, hint: `Dernier contrôle : ${esc(last)}`, iconName: 'alert' })}
        ${statCard({ label: 'Critiques (bloquantes)', value: counts.critiques || 0, hint: 'Traitement prioritaire', tone: 'bad', iconName: 'shield' })}
        ${statCard({ label: 'À contrôler', value: counts.acontroler || 0, hint: 'Analyse par un agent', tone: 'warn', iconName: 'search' })}
        ${statCard({ label: 'Nouvelles', value: counts.nouvelles || 0, hint: 'Non encore traitées', tone: 'info', iconName: 'bell' })}
      </div>
      <div class="section-title">Typologie des anomalies (A01 – A15)</div>
      <div class="stats" style="grid-template-columns:repeat(5,minmax(0,1fr))">${cards}</div>
      ${card(`
        <form class="filter-bar" method="get" action="/controles">
          <div class="field"><label>Code</label><select name="code"><option value="">Tous</option>${Object.entries(ANOMALIES).map(([c, m]) => `<option value="${c}" ${f.code === c ? 'selected' : ''}>${c} — ${esc(m.libelle)}</option>`).join('')}</select></div>
          <div class="field"><label>Criticité</label><select name="criticite"><option value="">Toutes</option>${['Critique','À contrôler','Conforme'].map(c => `<option ${f.criticite === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Nouvelle','En cours','Traitée','Ignorée'].map(s => `<option ${f.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/controles">Réinitialiser</a>
        </form>
        ${dataTable(['Anomalie', 'Objet', 'Période', 'Criticité', 'Statut', 'Dossier', ''], trs, { empty: 'Aucune anomalie. Lancez les contrôles pour analyser les données.' })}
        ${pagination(p, '/controles', f)}
      `, { title: 'Anomalies détectées', bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Contrôle', '/controles', content, ['Module 08', 'Contrôle']));
  });

  router.post('/controles/executer', 'controles.run', (ctx) => {
    const counts = runControles({ actor: ctx.user });
    const total = Object.values(counts).reduce((s, n) => s + n, 0);
    ctx.flash('success', `Contrôles exécutés : ${total} constat(s) traité(s) sur 15 typologies.`);
    ctx.redirect('/controles');
  });

  router.get('/anomalies/:id', 'view', (ctx) => {
    const a = one(`SELECT a.*, o.sigle, o.nom AS organisme_nom, s.matricule, s.nom AS assure_nom, s.prenom AS assure_prenom
      FROM anomalies a LEFT JOIN organismes o ON o.id = a.organisme_id LEFT JOIN assures s ON s.id = a.assure_id WHERE a.id = ?`, Number(ctx.params.id));
    if (!a) return ctx.send('<h1>Anomalie introuvable</h1>', 404);
    const dossier = a.dossier_id ? one('SELECT * FROM dossiers WHERE id = ?', a.dossier_id) : null;
    const decl = a.declaration_id ? one('SELECT * FROM declarations WHERE id = ?', a.declaration_id) : null;
    const content = `
      ${pageHead(`Anomalie ${a.code}`, a.libelle, dossier ? `<a class="btn primary" href="/dossiers/${dossier.id}">Ouvrir le dossier</a>` : (can(ctx.user, 'dossiers.edit') ? `<form method="post" action="/anomalies/${a.id}/dossier" class="inline-form">${csrfField(ctx.csrf)}<button class="btn primary" type="submit">Créer un dossier</button></form>` : ''), ['Module 08', 'Contrôle', a.code])}
      <div class="grid grid-2">
        ${card(`<dl class="dl">
          <dt>Code et libellé</dt><dd>${esc(a.code)} — ${esc(a.libelle)}</dd>
          <dt>Criticité</dt><dd>${genericBadge(a.criticite)}</dd>
          <dt>Statut</dt><dd>${genericBadge(a.statut)}</dd>
          <dt>Assuré</dt><dd>${a.matricule ? `<a href="/assures/${a.assure_id}">${esc(a.assure_nom)} ${esc(a.assure_prenom)} (${esc(a.matricule)})</a>` : '—'}</dd>
          <dt>Organisme</dt><dd>${a.sigle ? `<a href="/organismes/${a.organisme_id}">${esc(a.organisme_nom)}</a>` : '—'}</dd>
          <dt>Période</dt><dd>${esc(a.periode || '—')}</dd>
          <dt>Déclaration</dt><dd>${decl ? `<a href="/declarations/${decl.id}" class="mono">${esc(decl.reference)}</a>` : '—'}</dd>
          <dt>Dossier</dt><dd>${dossier ? `<a href="/dossiers/${dossier.id}" class="mono">${esc(dossier.reference)}</a>` : '—'}</dd>
          <dt>Détectée le</dt><dd>${fmtDateTime(a.created_at)}</dd>
        </dl>`, { title: 'Constat' })}
        ${card(`
          <div class="help-box">${esc(a.detail || 'Aucun détail complémentaire.')}</div>
          <div class="mt16 form-actions">
            ${!dossier && can(ctx.user, 'dossiers.edit') ? `<form method="post" action="/anomalies/${a.id}/dossier">${csrfField(ctx.csrf)}<button class="btn primary" type="submit">Créer un dossier de traitement</button></form>` : ''}
            ${a.statut !== 'Ignorée' && can(ctx.user, 'dossiers.edit') ? `<form method="post" action="/anomalies/${a.id}/ignorer" data-confirm="Marquer cette anomalie comme ignorée ?">${csrfField(ctx.csrf)}<button class="btn" type="submit">Ignorer l'anomalie</button></form>` : ''}
          </div>`, { title: 'Détail du constat' })}
      </div>`;
    ctx.send(ctx.page(`Anomalie ${a.code}`, '/controles', content, ['Module 08', 'Contrôle', a.code]));
  });

  router.post('/anomalies/:id/dossier', 'dossiers.edit', (ctx) => {
    const d = createDossierFromAnomaly(Number(ctx.params.id), ctx.user);
    if (!d) { ctx.flash('error', 'Anomalie introuvable.'); return ctx.redirect('/controles'); }
    rebuildComptes();
    ctx.flash('success', `Dossier ${d.reference} créé.`);
    ctx.redirect(`/dossiers/${d.id}`);
  });

  router.post('/anomalies/:id/ignorer', 'dossiers.edit', (ctx) => {
    const a = one('SELECT * FROM anomalies WHERE id = ?', Number(ctx.params.id));
    if (!a) return ctx.send('<h1>Anomalie introuvable</h1>', 404);
    run("UPDATE anomalies SET statut = 'Ignorée' WHERE id = ?", a.id);
    audit(ctx.user, 'Anomalie', a.id, 'Ignorée', a.statut, 'Ignorée', ctx.body.motif || '');
    ctx.flash('success', 'Anomalie marquée comme ignorée.');
    ctx.redirect('/controles');
  });
}
