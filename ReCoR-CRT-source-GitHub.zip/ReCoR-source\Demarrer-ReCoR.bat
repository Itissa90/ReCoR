@echo off
setlocal
title ReCoR - Caisse de Retraites du Togo
cd /d "%~dp0"

set "NODE=runtime\node\node.exe"
if not exist "%NODE%" (
  where node >nul 2>nul
  if errorlevel 1 (
    echo Erreur : Node.js est introuvable.
    echo Installez Node.js 24 ou placez le moteur portable dans runtime\node\node.exe
    pause
    exit /b 1
  )
  set "NODE=node"
)

if not exist "data\recor.db" (
  echo Premiere initialisation : creation de la base de demonstration...
  "%NODE%" app\seed.js
  if errorlevel 1 (
    echo Echec de l'initialisation. Consultez les messages ci-dessus.
    pause
    exit /b 1
  )
)

echo.
echo   ReCoR - plateforme CRT
echo   Adresse : http://127.0.0.1:3000
echo   Comptes de demonstration : admin / Recor2026!
echo.
echo   Laissez cette fenetre ouverte. Ctrl+C pour arreter.
echo.

start "" /b cmd /c "ping -n 3 127.0.0.1 >nul & start http://127.0.0.1:3000"
"%NODE%" app\server.js
pause
