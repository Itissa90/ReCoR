import { authenticate, createSession, destroySession, verifyPassword, changePassword, can } from '../auth.js';
import { one, q, audit } from '../db.js';
import { loginLayout, pageHead, card, dataTable, td, csrfField, badge } from '../render.js';
import { esc, fmtDateTime, nowStamp } from '../util.js';
import { loginRateBlocked, loginFailed, loginSucceeded, setSessionCookie, clearSessionCookie } from '../server.js';

export function register(router) {
  router.get('/login', 'public', (ctx) => {
    if (ctx.user) return ctx.redirect('/');
    ctx.send(loginLayout({ csrf: ctx.csrf }));
  });

  router.post('/login', 'public', (ctx) => {
    if (loginRateBlocked(ctx.ip)) {
      return ctx.send(loginLayout({ csrf: ctx.csrf, error: 'Trop de tentatives. Réessayez dans quelques minutes.' }), 429);
    }
    const user = authenticate(ctx.body.login, ctx.body.password);
    if (!user) {
      loginFailed(ctx.ip);
      return ctx.send(loginLayout({ csrf: ctx.csrf, error: 'Identifiant ou mot de passe incorrect.' }), 401);
    }
    loginSucceeded(ctx.ip);
    const s = createSession(user.id);
    ctx.sessionToken = s.token;
    setSessionCookie(ctx.res, s.token);
    ctx.setFlash('success', `Bienvenue, ${user.nom}.`);
    audit(user, 'Session', user.id, 'Connexion', '', user.profil, '', '', ctx.ip);
    ctx.redirect('/');
  });

  router.post('/logout', 'view', (ctx) => {
    audit(ctx.user, 'Session', ctx.user.id, 'Déconnexion', '', '', '', '', ctx.ip);
    destroySession(ctx.sessionToken);
    clearSessionCookie(ctx.res);
    ctx.redirect('/login');
  });

  router.get('/mon-compte', 'view', (ctx) => {
    const user = one('SELECT * FROM users WHERE id = ?', ctx.user.id);
    const actions = q(
      `SELECT * FROM audit_log WHERE user_id = ? ORDER BY date_action DESC, id DESC LIMIT 15`, ctx.user.id);
    const rows = actions.map(a => [
      td(`<span class="mono">${esc(fmtDateTime(a.date_action))}</span>`),
      td(esc(a.action)),
      td(esc(a.entite) + (a.entite_id ? ` <span class="ref">${esc(a.entite_id)}</span>` : '')),
      td(esc(a.motif || '—'))
    ]);
    const content = `
      ${pageHead('Authentification', 'Compte utilisateur, profil et sécurité de la connexion.', '', ['Module 01', 'Authentification'])}
      <div class="grid grid-2">
        ${card(`
          <div class="profile-head">
            <div class="profile-avatar">${esc((user.nom || '').split(' ').map(x => x[0]).slice(0, 2).join(''))}</div>
            <div><h2>${esc(user.nom)}</h2><div class="meta">${esc(user.login)} · ${esc(user.profil)}</div></div>
          </div>
          <dl class="dl mt16">
            <dt>Profil d'accès</dt><dd>${badge(user.profil, user.profil === 'Administrateur' ? 'gold' : 'info')}</dd>
            <dt>Adresse électronique</dt><dd>${esc(user.email || '—')}</dd>
            <dt>Téléphone</dt><dd>${esc(user.telephone || '—')}</dd>
            <dt>Dernière connexion</dt><dd>${esc(fmtDateTime(user.derniere_connexion))}</dd>
            <dt>Compte créé le</dt><dd>${esc(fmtDateTime(user.created_at))}</dd>
            <dt>Session en cours</dt><dd>Expire après 8 heures d'inactivité</dd>
          </dl>`, { title: 'Identité et habilitation' })}
        ${card(`
          <form method="post" action="/mon-compte" class="form-grid one">
            ${csrfField(ctx.csrf)}
            <div class="field"><label>Mot de passe actuel <span class="req">*</span></label><input type="password" name="actuel" required autocomplete="current-password"></div>
            <div class="field"><label>Nouveau mot de passe <span class="req">*</span></label><input type="password" name="nouveau" required minlength="8" autocomplete="new-password"><span class="hint">8 caractères minimum.</span></div>
            <div class="field"><label>Confirmation <span class="req">*</span></label><input type="password" name="confirmation" required minlength="8" autocomplete="new-password"></div>
            <div class="form-actions"><button class="btn primary" type="submit">Mettre à jour le mot de passe</button></div>
          </form>`, { title: 'Changer le mot de passe' })}
      </div>
      ${card(dataTable(['Date', 'Action', 'Objet', 'Motif'], rows, { empty: 'Aucune action enregistrée pour ce compte.' }), {
        title: 'Mes dernières actions', subtitle: 'Extrait du journal de traçabilité.', bodyClass: 'flush'
      })}`;
    ctx.send(ctx.page('Authentification', '/mon-compte', content, ['Module 01', 'Authentification']));
  });

  router.post('/mon-compte', 'view', (ctx) => {
    const user = one('SELECT * FROM users WHERE id = ?', ctx.user.id);
    const actuel = String(ctx.body.actuel || '');
    const nouveau = String(ctx.body.nouveau || '');
    const confirmation = String(ctx.body.confirmation || '');
    if (!verifyPassword(actuel, user.password_hash)) {
      ctx.flash('error', 'Le mot de passe actuel est incorrect.');
      return ctx.redirect('/mon-compte');
    }
    if (nouveau.length < 8) {
      ctx.flash('error', 'Le nouveau mot de passe doit contenir au moins 8 caractères.');
      return ctx.redirect('/mon-compte');
    }
    if (nouveau !== confirmation) {
      ctx.flash('error', 'La confirmation ne correspond pas au nouveau mot de passe.');
      return ctx.redirect('/mon-compte');
    }
    changePassword(user, nouveau, ctx.user);
    ctx.flash('success', 'Mot de passe mis à jour.');
    ctx.redirect('/mon-compte');
  });
}
