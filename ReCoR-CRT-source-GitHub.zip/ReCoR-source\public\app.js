(function () {
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const menuBtn = document.getElementById('menuBtn');

  function closeMenu() {
    sidebar?.classList.remove('open');
    overlay?.classList.remove('show');
  }
  menuBtn?.addEventListener('click', () => {
    sidebar?.classList.toggle('open');
    overlay?.classList.toggle('show');
  });
  overlay?.addEventListener('click', closeMenu);

  document.addEventListener('click', (e) => {
    const closer = e.target.closest('.flash-close');
    if (closer) closer.closest('.flash')?.remove();
  });

  document.querySelectorAll('[data-confirm]').forEach((el) => {
    el.addEventListener('submit', (e) => {
      if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
    });
    if (el.tagName === 'BUTTON' || el.tagName === 'A') {
      el.addEventListener('click', (e) => {
        if (!window.confirm(el.getAttribute('data-confirm'))) e.preventDefault();
      });
    }
  });

  document.querySelectorAll('select.auto-submit, input.auto-submit').forEach((el) => {
    el.addEventListener('change', () => el.form?.submit());
  });

  document.querySelectorAll('[data-print]').forEach((el) => {
    el.addEventListener('click', () => window.print());
  });

  document.querySelectorAll('[data-copy]').forEach((el) => {
    el.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(el.getAttribute('data-copy'));
        const old = el.textContent;
        el.textContent = 'Copié';
        setTimeout(() => { el.textContent = old; }, 1200);
      } catch { /* ignore */ }
    });
  });

  const hash = window.location.hash;
  if (hash && hash.startsWith('#')) {
    const target = document.querySelector(hash);
    if (target) target.scrollIntoView({ block: 'start' });
  }
})();
