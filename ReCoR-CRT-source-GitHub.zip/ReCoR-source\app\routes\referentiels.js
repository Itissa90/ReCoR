import { q, one, run, audit } from '../db.js';
import { can } from '../auth.js';
import { calcMois, compteAssure, compteCotisant, getAssure, expliquer } from '../calc.js';
import { pageHead, card, dataTable, td, pagination, csrfField, badge, genericBadge, dossierBadge, statCard, icon, emptyState, tabs } from '../render.js';
import { esc, money, fmtDate, fmtDateTime, monthLabel, paginate, int, todayISO, initials, periodFromDate } from '../util.js';

function soldesMap(ids, type = 'assure') {
  if (!ids.length) return new Map();
  const marks = ids.map(() => '?').join(',');
  const col = type === 'assure' ? 'assure_id' : 'organisme_id';
  const rows = q(
    `SELECT ${col} AS id, SUM(debit) - SUM(credit) AS solde FROM mouvements
     WHERE compte_type = ? AND ${col} IN (${marks}) GROUP BY ${col}`, type, ...ids);
  return new Map(rows.map(r => [Number(r.id), Number(r.solde)]));
}

function soldeBadge(solde) {
  if (solde > 0.5) return `<span class="text-danger strong">${money(solde)}</span>`;
  if (solde < -0.5) return `<span class="text-ok strong">${money(solde)}</span>`;
  return `<span class="text-ok">${money(0)}</span>`;
}

function orgOptions(selected) {
  const orgs = q('SELECT id, code, nom FROM organismes ORDER BY nom');
  return `<option value="">—</option>` + orgs.map(o => `<option value="${o.id}" ${Number(selected) === Number(o.id) ? 'selected' : ''}>${esc(o.sigle || o.code)} — ${esc(o.nom)}</option>`).join('');
}

function assureFormPage(ctx, { a = {}, error = '', mode = 'create' }) {
  const isEdit = mode === 'edit';
  const content = `
    ${pageHead(isEdit ? 'Modifier un assuré' : 'Nouvel assuré', 'Fiche individuelle, situation administrative et position.', `<a class="btn" href="${isEdit ? `/assures/${a.id}` : '/assures'}">Annuler</a>`, ['Module 02', 'Assurés', isEdit ? 'Modification' : 'Création'])}
    ${error ? `<div class="alert-line">${icon('alert', 17)} ${esc(error)}</div>` : ''}
    <form method="post" action="${isEdit ? `/assures/${a.id}/modifier` : '/assures'}" class="card">
      ${csrfField(ctx.csrf)}
      <div class="card-body">
        <div class="form-section"><h3>Identité</h3><div class="form-grid">
          <div class="field"><label>Matricule FP <span class="req">*</span></label><input name="matricule" required value="${esc(a.matricule || '')}" placeholder="FP-000121"></div>
          <div class="field"><label>Organisme de rattachement <span class="req">*</span></label><select name="organisme_id" required>${orgOptions(a.organisme_id)}</select></div>
          <div class="field"><label>Nom <span class="req">*</span></label><input name="nom" required value="${esc(a.nom || '')}"></div>
          <div class="field"><label>Prénom(s) <span class="req">*</span></label><input name="prenom" required value="${esc(a.prenom || '')}"></div>
          <div class="field"><label>Sexe</label><select name="sexe"><option value="M" ${a.sexe === 'M' ? 'selected' : ''}>Masculin</option><option value="F" ${a.sexe === 'F' ? 'selected' : ''}>Féminin</option></select></div>
          <div class="field"><label>Date de naissance</label><input type="date" name="date_naissance" value="${esc(a.date_naissance || '')}"></div>
          <div class="field"><label>Lieu de naissance</label><input name="lieu_naissance" value="${esc(a.lieu_naissance || '')}"></div>
          <div class="field"><label>Téléphone</label><input name="telephone" value="${esc(a.telephone || '')}"></div>
        </div></div>
        <div class="form-section"><h3>Situation administrative</h3><div class="form-grid three">
          <div class="field"><label>Date de prise de service</label><input type="date" name="date_prise_service" value="${esc(a.date_prise_service || '')}"></div>
          <div class="field"><label>Date de nomination</label><input type="date" name="date_nomination" value="${esc(a.date_nomination || '')}"></div>
          <div class="field"><label>Date de titularisation</label><input type="date" name="date_titularisation" value="${esc(a.date_titularisation || '')}"></div>
          <div class="field"><label>Corps</label><input name="corps" value="${esc(a.corps || '')}"></div>
          <div class="field"><label>Catégorie</label><select name="categorie">${['A','B','C','D','E'].map(c => `<option ${a.categorie === c ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
          <div class="field"><label>Grade</label><input name="grade" value="${esc(a.grade || '')}"></div>
          <div class="field"><label>Échelon</label><input name="echelon" value="${esc(a.echelon || '')}"></div>
          <div class="field"><label>Indice</label><input type="number" name="indice" min="1" value="${esc(a.indice ?? '')}"></div>
          <div class="field"><label>Bonification d'indice</label><input type="number" name="bonification" min="0" value="${esc(a.bonification ?? 0)}"></div>
          <div class="field"><label>Date de retraite</label><input type="date" name="date_retraite" value="${esc(a.date_retraite || '')}"></div>
          <div class="field"><label>Position</label><select name="position">${['Actif','Détachement','Disponibilité','Suspension','Cessation'].map(p => `<option ${a.position === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
          <div class="field"><label>Date de position</label><input type="date" name="date_position" value="${esc(a.date_position || '')}"></div>
          <div class="field"><label>Statut</label><select name="statut">${['Actif','Suspendu','Retraité','Radié','Décédé'].map(p => `<option ${a.statut === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
          <div class="field"><label>Motif de cessation</label><select name="cessation_type"><option value="">—</option>${['Retraite','Radiation','Décès','Démission'].map(p => `<option ${a.cessation_type === p ? 'selected' : ''}>${p}</option>`).join('')}</select></div>
          <div class="field"><label>Date de cessation</label><input type="date" name="date_cessation" value="${esc(a.date_cessation || '')}"></div>
        </div></div>
        <div class="form-section"><h3>Observation</h3>
          <div class="field"><textarea name="observation" placeholder="Information complémentaire utile au dossier...">${esc(a.observation || '')}</textarea></div>
        </div>
        <div class="form-actions">
          <button class="btn primary" type="submit">${isEdit ? 'Enregistrer les modifications' : "Créer l'assuré"}</button>
          <a class="btn" href="${isEdit ? `/assures/${a.id}` : '/assures'}">Annuler</a>
        </div>
      </div>
    </form>`;
  ctx.send(ctx.page(isEdit ? 'Modifier un assuré' : 'Nouvel assuré', '/assures', content, ['Module 02', 'Assurés']));
}

export function register(router) {
  router.get('/assures', 'view', (ctx) => {
    const filters = {
      q: String(ctx.query.q || '').trim(),
      organisme: String(ctx.query.organisme || ''),
      statut: String(ctx.query.statut || ''),
      position: String(ctx.query.position || '')
    };
    const page = int(ctx.query.page, 1);
    const where = [];
    const params = [];
    if (filters.q) {
      where.push('(a.matricule LIKE ? OR a.nom LIKE ? OR a.prenom LIKE ?)');
      const term = `%${filters.q}%`;
      params.push(term, term, term);
    }
    if (filters.organisme) { where.push('a.organisme_id = ?'); params.push(Number(filters.organisme)); }
    if (filters.statut) { where.push('a.statut = ?'); params.push(filters.statut); }
    if (filters.position) { where.push('a.position = ?'); params.push(filters.position); }
    const sqlWhere = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM assures a ${sqlWhere}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(
      `SELECT a.*, o.nom AS organisme_nom, o.sigle AS organisme_sigle FROM assures a
       LEFT JOIN organismes o ON o.id = a.organisme_id ${sqlWhere}
       ORDER BY a.nom, a.prenom LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const soldes = soldesMap(rows.map(r => r.id));
    const trs = rows.map(a => [
      td(`<a href="/assures/${a.id}" class="main-cell">${esc(a.matricule)}</a><span class="sub">${esc(a.corps || '—')} · ${esc(a.categorie || '—')} / ${esc(a.grade || '—')}</span>`),
      td(`<a href="/assures/${a.id}">${esc(a.nom)} ${esc(a.prenom)}</a><span class="sub">${esc(a.lieu_naissance || '—')}</span>`),
      td(esc(a.organisme_sigle || a.organisme_nom || '—')),
      td(`<span class="mono">${a.indice ?? '—'}</span>`, 'num'),
      td(genericBadge(a.position)),
      td(genericBadge(a.statut)),
      td(soldeBadge(soldes.get(a.id) || 0), 'num'),
      td(`<div class="table-actions"><a class="btn xs" href="/assures/${a.id}">Fiche</a>${can(ctx.user, 'assures.edit') ? `<a class="btn xs" href="/assures/${a.id}/modifier">Modifier</a>` : ''}</div>`, 'actions')
    ]);
    const content = `
      ${pageHead('Assurés', `${total} compte(s) individuel(s) — recherche, fiche et situation administrative.`, can(ctx.user, 'assures.edit') ? `<a class="btn primary" href="/assures/nouveau">${icon('plus', 16)} Nouvel assuré</a>` : '', ['Module 02', 'Assurés'])}
      <div class="stats">
        ${statCard({ label: 'Assurés enregistrés', value: new Intl.NumberFormat('fr-FR').format(one('SELECT COUNT(*) AS n FROM assures').n), hint: 'Capacité cible : 200 000', iconName: 'users' })}
        ${statCard({ label: 'Comptes à régulariser', value: new Intl.NumberFormat('fr-FR').format(one("SELECT COUNT(*) AS n FROM (SELECT assure_id FROM mouvements WHERE compte_type='assure' GROUP BY assure_id HAVING SUM(debit)-SUM(credit) > 1)").n), hint: 'Solde débiteur', tone: 'warn', iconName: 'alert' })}
        ${statCard({ label: 'Positions particulières', value: new Intl.NumberFormat('fr-FR').format(one("SELECT COUNT(*) AS n FROM assures WHERE position <> 'Actif'").n), hint: 'Détachement, disponibilité, suspension', iconName: 'layers' })}
        ${statCard({ label: 'Organismes cotisants', value: one('SELECT COUNT(*) AS n FROM organismes WHERE actif = 1').n, hint: 'Structures rattachées', iconName: 'building' })}
      </div>
      ${card(`
        <form class="filter-bar" method="get" action="/assures">
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(filters.q)}" placeholder="Matricule, nom ou prénom"></div>
          <div class="field"><label>Organisme</label><select name="organisme">${orgOptions(filters.organisme)}</select></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Actif','Suspendu','Retraité','Radié','Décédé'].map(s => `<option ${filters.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <div class="field"><label>Position</label><select name="position"><option value="">Toutes</option>${['Actif','Détachement','Disponibilité','Suspension','Cessation'].map(s => `<option ${filters.position === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/assures">Réinitialiser</a>
        </form>
        ${dataTable(['Matricule / corps', 'Assuré', 'Organisme', 'Indice', 'Position', 'Statut', 'Solde', ''], trs, { empty: 'Aucun assuré ne correspond aux critères.' })}
        ${pagination(p, '/assures', filters)}
      `, { bodyClass: 'flush' })}
      <div class="note">Le solde est calculé à partir des mouvements validés (déclarations, régularisations et paiements rapprochés).</div>`;
    ctx.send(ctx.page('Assurés', '/assures', content, ['Module 02', 'Assurés']));
  });

  router.get('/assures/nouveau', 'assures.edit', (ctx) => assureFormPage(ctx, { a: {} }));

  router.post('/assures', 'assures.edit', (ctx) => {
    const b = ctx.body;
    const matricule = String(b.matricule || '').trim().toUpperCase();
    const nom = String(b.nom || '').trim();
    const prenom = String(b.prenom || '').trim();
    if (!matricule || !nom || !prenom || !b.organisme_id) {
      return assureFormPage(ctx, { a: b, error: 'Le matricule, le nom, le prénom et l’organisme sont obligatoires.' });
    }
    if (one('SELECT id FROM assures WHERE matricule = ?', matricule)) {
      return assureFormPage(ctx, { a: b, error: `Le matricule ${matricule} existe déjà.` });
    }
    const res = run(
      `INSERT INTO assures (matricule, nom, prenom, sexe, date_naissance, lieu_naissance, telephone, date_prise_service,
        date_nomination, date_titularisation, corps, categorie, grade, echelon, indice, bonification, date_retraite,
        position, date_position, cessation_type, date_cessation, organisme_id, statut, observation, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      matricule, nom, prenom, b.sexe || 'M', b.date_naissance || null, b.lieu_naissance || '', b.telephone || '',
      b.date_prise_service || null, b.date_nomination || null, b.date_titularisation || null,
      b.corps || '', b.categorie || '', b.grade || '', b.echelon || '', int(b.indice, 0) || null, int(b.bonification, 0) || 0,
      b.date_retraite || null, b.position || 'Actif', b.date_position || null, b.cessation_type || null,
      b.date_cessation || null, Number(b.organisme_id), b.statut || 'Actif', b.observation || '',
      new Date().toISOString().slice(0, 19).replace('T', ' '), new Date().toISOString().slice(0, 19).replace('T', ' ')
    );
    const id = Number(res.lastInsertRowid);
    audit(ctx.user, 'Assuré', id, 'Création', '', `${nom} ${prenom} (${matricule})`, 'Création de la fiche assuré');
    ctx.flash('success', `L'assuré ${nom} ${prenom} a été créé.`);
    ctx.redirect(`/assures/${id}`);
  });

  router.get('/assures/:id', 'view', (ctx) => {
    const a = one(`SELECT a.*, o.nom AS organisme_nom, o.code AS organisme_code, o.sigle AS organisme_sigle FROM assures a LEFT JOIN organismes o ON o.id = a.organisme_id WHERE a.id = ?`, Number(ctx.params.id));
    if (!a) return ctx.send('<h1>Assuré introuvable</h1>', 404);
    const carrieres = q('SELECT * FROM carrieres WHERE assure_id = ? ORDER BY date_debut DESC, id DESC', a.id);
    const dossiers = q('SELECT * FROM dossiers WHERE assure_id = ? ORDER BY created_at DESC LIMIT 12', a.id);
    const anomalies = q('SELECT * FROM anomalies WHERE assure_id = ? ORDER BY created_at DESC LIMIT 12', a.id);
    const compte = compteAssure(a.id);
    const decls = q(
      `SELECT d.reference, d.periode, d.statut, l.montant FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id
       WHERE l.assure_id = ? ORDER BY d.periode DESC LIMIT 12`, a.id);
    const totalDecl = one("SELECT COALESCE(SUM(l.montant),0) AS m FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id WHERE l.assure_id = ? AND d.statut = 'Validé'", a.id).m;
    const totalPay = one("SELECT COALESCE(SUM(p.montant),0) AS m FROM paiements p WHERE p.declaration_id IN (SELECT d.id FROM declarations d JOIN declaration_lignes l ON l.declaration_id = d.id WHERE l.assure_id = ?) AND p.statut = 'Rapproché'", a.id).m;
    const periodes = q(
      `SELECT DISTINCT d.periode FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id
       WHERE l.assure_id = ? AND d.statut <> 'Rejeté' ORDER BY d.periode DESC LIMIT 8`, a.id);

    const careerRows = carrieres.map(c => [
      td(`<span class="main-cell">${esc(c.type_evenement)}</span><span class="sub">${esc(c.motif || '—')}</span>`),
      td(`${fmtDate(c.date_debut)}${c.date_fin ? `<span class="sub">au ${fmtDate(c.date_fin)}</span>` : ''}`),
      td(c.ancien_indice ? `${c.ancien_indice} → ${c.nouvel_indice}` : esc(c.nouvel_indice || '—'), 'num'),
      td(genericBadge(c.statut)),
      td(c.piece ? esc(c.piece) : '<span class="muted">—</span>'),
      td(can(ctx.user, 'carrieres.validate') && c.statut === 'Brouillon'
        ? `<div class="table-actions"><form method="post" action="/carrieres/${c.id}/statut" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="statut" value="Validé"><button class="btn xs primary" type="submit">Valider</button></form><form method="post" action="/carrieres/${c.id}/statut" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="statut" value="Rejeté"><button class="btn xs danger" type="submit">Rejeter</button></form></div>`
        : '', 'actions')
    ]);
    const dossierRows = dossiers.map(d => [
      td(`<a href="/dossiers/${d.id}" class="main-cell mono">${esc(d.reference)}</a><span class="sub">${esc(d.type === 'Regularisation' ? 'Régularisation' : d.type)}</span>`),
      td(`${monthLabel(d.periode_debut)}${d.periode_fin && d.periode_fin !== d.periode_debut ? ` → ${monthLabel(d.periode_fin)}` : ''}`),
      td(money(d.montant_du), 'num'),
      td(dossierBadge(d.statut)),
      td(`<a class="btn xs" href="/dossiers/${d.id}">Ouvrir</a>`, 'actions')
    ]);
    const anomalyRows = anomalies.map(an => [
      td(`<span class="main-cell">${esc(an.code)}</span> <span class="small">${esc(an.libelle)}</span><span class="sub">${esc(an.detail || '')}</span>`),
      td(esc(an.periode || '—')),
      td(genericBadge(an.criticite)),
      td(genericBadge(an.statut)),
      td(an.dossier_id ? `<a class="btn xs" href="/dossiers/${an.dossier_id}">Dossier</a>` : '', 'actions')
    ]);
    const movementRows = compte.rows.slice(-10).reverse().map(m => [
      td(fmtDate(m.date_mouvement)),
      td(esc(m.libelle) + `<span class="sub">${esc(m.origine || '')} · ${esc(m.reference || '')}</span>`),
      td(m.debit ? money(m.debit) : '—', 'num'),
      td(m.credit ? money(m.credit) : '—', 'num'),
      td(money(m.solde), 'num')
    ]);
    const declRows = decls.map(d => [
      td(`<span class="mono">${esc(d.reference)}</span>`),
      td(monthLabel(d.periode)),
      td(money(d.montant), 'num'),
      td(genericBadge(d.statut)),
      td(`<a class="btn xs" href="/expliquer?assure_id=${a.id}&periode=${d.periode}">Expliquer l'écart</a>`, 'actions')
    ]);

    const content = `
      ${pageHead('Fiche assuré', 'Compte individuel, carrière, dossiers et traçabilité.', `${can(ctx.user, 'assures.edit') ? `<a class="btn" href="/assures/${a.id}/modifier">Modifier</a>` : ''}${can(ctx.user, 'carrieres.edit') ? `<a class="btn" href="/carrieres/nouvelle?assure_id=${a.id}">${icon('plus', 15)} Événement de carrière</a>` : ''}<button class="btn" data-print>${icon('print', 15)} Imprimer</button>`, ['Module 02', 'Assurés', a.matricule])}
      <div class="card"><div class="card-body">
        <div class="profile-head">
          <div class="profile-avatar">${esc(initials(a.nom, a.prenom))}</div>
          <div>
            <h2>${esc(a.nom)} ${esc(a.prenom)}</h2>
            <div class="meta">${esc(a.matricule)} · ${esc(a.corps || '—')} · ${esc(a.categorie || '—')} / ${esc(a.grade || '—')} / échelon ${esc(a.echelon || '—')}</div>
          </div>
          <div class="inline-list" style="margin-left:auto">
            ${genericBadge(a.statut)} ${genericBadge(a.position)}
          </div>
        </div>
      </div></div>
      <div class="stats">
        ${statCard({ label: 'Solde du compte', value: money(compte.solde), hint: compte.solde > 0 ? 'Reste à régulariser' : 'Compte à jour', tone: compte.solde > 0 ? 'bad' : 'ok', iconName: 'wallet' })}
        ${statCard({ label: 'Cotisations déclarées', value: money(totalDecl), hint: 'Déclarations validées', iconName: 'file' })}
        ${statCard({ label: 'Paiements imputés', value: money(totalPay), hint: 'Rapprochés', tone: 'info', iconName: 'wallet' })}
        ${statCard({ label: 'Événements de carrière', value: carrieres.length, hint: `${carrieres.filter(c => c.statut === 'Brouillon').length} en attente`, iconName: 'layers' })}
      </div>
      <div class="grid grid-2">
        ${card(`<dl class="dl">
          <dt>Matricule FP</dt><dd><span class="mono">${esc(a.matricule)}</span></dd>
          <dt>Organisme</dt><dd>${esc(a.organisme_sigle || a.organisme_nom || '—')}</dd>
          <dt>Date et lieu de naissance</dt><dd>${fmtDate(a.date_naissance)} · ${esc(a.lieu_naissance || '—')}</dd>
          <dt>Prise de service</dt><dd>${fmtDate(a.date_prise_service)}</dd>
          <dt>Nomination</dt><dd>${fmtDate(a.date_nomination)}</dd>
          <dt>Titularisation</dt><dd>${fmtDate(a.date_titularisation)}</dd>
          <dt>Indice / bonification</dt><dd>${a.indice ?? '—'} / ${a.bonification ?? 0}</dd>
          <dt>Date de retraite</dt><dd>${fmtDate(a.date_retraite)}</dd>
          <dt>Position</dt><dd>${esc(a.position)}${a.date_position ? ` depuis le ${fmtDate(a.date_position)}` : ''}</dd>
          ${a.cessation_type ? `<dt>Cessation</dt><dd>${esc(a.cessation_type)} — ${fmtDate(a.date_cessation)}</dd>` : ''}
        </dl>${a.observation ? `<div class="help-box mt16"><b>Observation :</b> ${esc(a.observation)}</div>` : ''}`, { title: 'Situation administrative' })}
        ${card(`
          <div class="kv-row"><span>Solde débiteur cumulé</span><strong class="${compte.solde > 0 ? 'text-danger' : 'text-ok'}">${money(compte.debit)}</strong></div>
          <div class="kv-row"><span>Paiements / crédits</span><strong>${money(compte.credit)}</strong></div>
          <div class="kv-row"><span>Solde</span><strong class="${compte.solde > 0 ? 'text-danger' : 'text-ok'}">${money(compte.solde)}</strong></div>
          ${dataTable(['Date', 'Mouvement', 'Débit', 'Crédit', 'Solde'], movementRows, { empty: 'Aucun mouvement de compte.', className: 'compact' })}
          <div class="mt16"><a class="btn" href="/comptes/assures/${a.id}">Voir le compte complet</a></div>`, { title: 'Derniers mouvements du compte assuré', bodyClass: '' })}
      </div>
      ${card(dataTable(['Événement', 'Période', 'Indice', 'Statut', 'Pièce', ''], careerRows, { empty: 'Aucun événement de carrière enregistré.' }), {
        title: 'Historique de carrière', subtitle: 'Historisation sans écrasement — un événement validé ne peut être supprimé.', bodyClass: 'flush',
        actions: can(ctx.user, 'carrieres.edit') ? `<a class="btn sm" href="/carrieres/nouvelle?assure_id=${a.id}">Ajouter</a>` : ''
      })}
      ${card(dataTable(['Période', 'Déclaration', 'Montant déclaré', 'Statut', ''], declRows, { empty: 'Aucune déclaration rattachée à cet assuré.' }), {
        title: 'Historique des cotisations', subtitle: 'Dernières périodes déclarées. Utilisez « Expliquer l’écart » pour la décomposition.', bodyClass: 'flush'
      })}
      ${card(dataTable(['Dossier', 'Période', 'Reste dû', 'Statut', ''], dossierRows, { empty: 'Aucun dossier pour cet assuré.' }), { title: 'Dossiers de régularisation et de redressement', bodyClass: 'flush' })}
      ${card(dataTable(['Anomalie', 'Période', 'Criticité', 'Statut', ''], anomalyRows, { empty: 'Aucune anomalie détectée.' }), { title: 'Anomalies détectées', bodyClass: 'flush' })}`;
    ctx.send(ctx.page(`Assuré ${a.matricule}`, '/assures', content, ['Module 02', 'Assurés', a.matricule]));
  });

  router.get('/assures/:id/modifier', 'assures.edit', (ctx) => {
    const a = one('SELECT * FROM assures WHERE id = ?', Number(ctx.params.id));
    if (!a) return ctx.send('<h1>Assuré introuvable</h1>', 404);
    assureFormPage(ctx, { a, mode: 'edit' });
  });

  router.post('/assures/:id/modifier', 'assures.edit', (ctx) => {
    const id = Number(ctx.params.id);
    const before = one('SELECT * FROM assures WHERE id = ?', id);
    if (!before) return ctx.send('<h1>Assuré introuvable</h1>', 404);
    const b = ctx.body;
    const matricule = String(b.matricule || '').trim().toUpperCase();
    if (!matricule || !b.nom || !b.prenom || !b.organisme_id) {
      return assureFormPage(ctx, { a: { ...before, ...b, id }, mode: 'edit', error: 'Le matricule, le nom, le prénom et l’organisme sont obligatoires.' });
    }
    const dup = one('SELECT id FROM assures WHERE matricule = ? AND id <> ?', matricule, id);
    if (dup) return assureFormPage(ctx, { a: { ...before, ...b, id }, mode: 'edit', error: 'Ce matricule est déjà utilisé par un autre assuré.' });
    run(
      `UPDATE assures SET matricule=?, nom=?, prenom=?, sexe=?, date_naissance=?, lieu_naissance=?, telephone=?,
        date_prise_service=?, date_nomination=?, date_titularisation=?, corps=?, categorie=?, grade=?, echelon=?, indice=?,
        bonification=?, date_retraite=?, position=?, date_position=?, cessation_type=?, date_cessation=?, organisme_id=?,
        statut=?, observation=?, updated_at=? WHERE id=?`,
      matricule, b.nom, b.prenom, b.sexe || 'M', b.date_naissance || null, b.lieu_naissance || '', b.telephone || '',
      b.date_prise_service || null, b.date_nomination || null, b.date_titularisation || null, b.corps || '', b.categorie || '',
      b.grade || '', b.echelon || '', int(b.indice, 0) || null, int(b.bonification, 0) || 0, b.date_retraite || null,
      b.position || 'Actif', b.date_position || null, b.cessation_type || null, b.date_cessation || null,
      Number(b.organisme_id), b.statut || 'Actif', b.observation || '', new Date().toISOString().slice(0, 19).replace('T', ' '), id
    );
    audit(ctx.user, 'Assuré', id, 'Modification', before, b, 'Mise à jour de la fiche assuré');
    ctx.flash('success', 'Fiche assuré mise à jour.');
    ctx.redirect(`/assures/${id}`);
  });

  // ---------- Carrières ----------
  router.get('/carrieres', 'view', (ctx) => {
    const filters = { q: String(ctx.query.q || '').trim(), statut: String(ctx.query.statut || ''), type: String(ctx.query.type || '') };
    const page = int(ctx.query.page, 1);
    const where = [];
    const params = [];
    if (filters.q) { where.push('(a.matricule LIKE ? OR a.nom LIKE ? OR a.prenom LIKE ?)'); const t = `%${filters.q}%`; params.push(t, t, t); }
    if (filters.statut) { where.push('c.statut = ?'); params.push(filters.statut); }
    if (filters.type) { where.push('c.type_evenement = ?'); params.push(filters.type); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM carrieres c JOIN assures a ON a.id = c.assure_id ${w}`, ...params).n;
    const p = paginate(total, page, 25);
    const rows = q(`SELECT c.*, a.matricule, a.nom, a.prenom FROM carrieres c JOIN assures a ON a.id = c.assure_id ${w} ORDER BY c.created_at DESC, c.id DESC LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(c => [
      td(`<a href="/assures/${c.assure_id}" class="main-cell">${esc(c.nom)} ${esc(c.prenom)}</a><span class="sub mono">${esc(c.matricule)}</span>`),
      td(`<span class="main-cell">${esc(c.type_evenement)}</span><span class="sub">${esc(c.motif || '—')}</span>`),
      td(`${fmtDate(c.date_debut)}${c.date_fin ? `<span class="sub">au ${fmtDate(c.date_fin)}</span>` : ''}`),
      td(c.ancien_indice || c.nouvel_indice ? `${c.ancien_indice || '—'} → ${c.nouvel_indice || '—'}` : '—', 'num'),
      td(genericBadge(c.statut)),
      td(c.piece ? esc(c.piece) : '—'),
      td(can(ctx.user, 'carrieres.validate') && c.statut === 'Brouillon'
        ? `<div class="table-actions"><form method="post" action="/carrieres/${c.id}/statut" class="inline-form">${csrfField(ctx.csrf)}<input type="hidden" name="statut" value="Validé"><button class="btn xs primary" type="submit">Valider</button></form><form method="post" action="/carrieres/${c.id}/statut">${csrfField(ctx.csrf)}<input type="hidden" name="statut" value="Rejeté"><button class="btn xs danger" type="submit">Rejeter</button></form></div>`
        : '', 'actions')
    ]);
    const content = `
      ${pageHead('Carrières', 'Reconstitution des carrières, indices et pièces justificatives.', can(ctx.user, 'carrieres.edit') ? `<a class="btn primary" href="/carrieres/nouvelle">${icon('plus', 16)} Nouvel événement</a>` : '', ['Module 03', 'Carrières'])}
      ${card(`
        <form class="filter-bar" method="get" action="/carrieres">
          <div class="field grow search-input"><label>Assuré</label><span>${icon('search', 15)}</span><input name="q" value="${esc(filters.q)}" placeholder="Matricule ou nom"></div>
          <div class="field"><label>Type d'événement</label><select name="type"><option value="">Tous</option>${['Titularisation','Avancement','Reclassement','Détachement','Disponibilité','Suspension','Réintégration','Cessation'].map(t => `<option ${filters.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Brouillon','Validé','Rejeté'].map(s => `<option ${filters.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
          <a class="btn" href="/carrieres">Réinitialiser</a>
        </form>
        ${dataTable(['Assuré', 'Événement', 'Période', 'Indice', 'Statut', 'Pièce', ''], trs, { empty: 'Aucun événement de carrière.' })}
        ${pagination(p, '/carrieres', filters)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Carrières', '/carrieres', content, ['Module 03', 'Carrières']));
  });

  router.get('/carrieres/nouvelle', 'carrieres.edit', (ctx) => {
    const assures = q('SELECT id, matricule, nom, prenom FROM assures ORDER BY nom LIMIT 500');
    const selected = Number(ctx.query.assure_id || 0);
    const content = `
      ${pageHead('Nouvel événement de carrière', 'Toute modification est historisée et soumise à validation.', '<a class="btn" href="/carrieres">Annuler</a>', ['Module 03', 'Carrières', 'Création'])}
      <form method="post" action="/carrieres" class="card"><div class="card-body">
        ${csrfField(ctx.csrf)}
        <div class="form-grid">
          <div class="field span2"><label>Assuré <span class="req">*</span></label><select name="assure_id" required><option value="">Choisir un assuré…</option>${assures.map(a => `<option value="${a.id}" ${selected === a.id ? 'selected' : ''}>${esc(a.matricule)} — ${esc(a.nom)} ${esc(a.prenom)}</option>`).join('')}</select></div>
          <div class="field"><label>Type d'événement <span class="req">*</span></label><select name="type_evenement" required>${['Titularisation','Avancement','Reclassement','Détachement','Disponibilité','Suspension','Réintégration','Cessation'].map(t => `<option>${t}</option>`).join('')}</select></div>
          <div class="field"><label>Date de début <span class="req">*</span></label><input type="date" name="date_debut" required value="${todayISO()}"></div>
          <div class="field"><label>Date de fin</label><input type="date" name="date_fin"></div>
          <div class="field"><label>Ancien indice</label><input type="number" name="ancien_indice" min="0"></div>
          <div class="field"><label>Nouvel indice</label><input type="number" name="nouvel_indice" min="0"></div>
          <div class="field"><label>Valeur indiciaire applicable</label><input type="number" step="0.01" name="valeur_indiciaire" min="0"></div>
          <div class="field span2"><label>Motif</label><input name="motif" placeholder="Référence de l'acte, décision ou arrêté"></div>
          <div class="field span2"><label>Pièce justificative</label><input name="piece" placeholder="Nom du document (ex. arrete_avancement.pdf)"><span class="hint">La pièce est obligatoire pour la validation définitive.</span></div>
        </div>
        <div class="form-actions"><button class="btn primary" type="submit">Enregistrer en brouillon</button><a class="btn" href="/carrieres">Annuler</a></div>
      </div></form>`;
    ctx.send(ctx.page('Nouvel événement de carrière', '/carrieres', content, ['Module 03', 'Carrières']));
  });

  router.post('/carrieres', 'carrieres.edit', (ctx) => {
    const b = ctx.body;
    const assureId = Number(b.assure_id || 0);
    if (!assureId || !b.type_evenement || !b.date_debut) {
      ctx.flash('error', "L'assuré, le type d'événement et la date de début sont obligatoires.");
      return ctx.redirect('/carrieres/nouvelle');
    }
    const res = run(
      `INSERT INTO carrieres (assure_id, type_evenement, motif, date_debut, date_fin, ancien_indice, nouvel_indice, valeur_indiciaire, piece, statut, created_by, created_at)
       VALUES (?,?,?,?,?,?,?,?,?, 'Brouillon', ?, ?)`,
      assureId, b.type_evenement, b.motif || '', b.date_debut, b.date_fin || null,
      int(b.ancien_indice, 0) || null, int(b.nouvel_indice, 0) || null, b.valeur_indiciaire ? Number(b.valeur_indiciaire) : null,
      b.piece || '', ctx.user.id, new Date().toISOString().slice(0, 19).replace('T', ' ')
    );
    const id = Number(res.lastInsertRowid);
    audit(ctx.user, 'Carrière', id, 'Création', '', `${b.type_evenement} — ${b.date_debut}`, b.motif || '', b.piece || '');
    ctx.flash('success', 'Événement de carrière enregistré en brouillon.');
    ctx.redirect(`/assures/${assureId}`);
  });

  router.post('/carrieres/:id/statut', 'carrieres.validate', (ctx) => {
    const c = one('SELECT * FROM carrieres WHERE id = ?', Number(ctx.params.id));
    if (!c) return ctx.send('<h1>Événement introuvable</h1>', 404);
    const statut = ctx.body.statut === 'Validé' ? 'Validé' : 'Rejeté';
    if (statut === 'Validé' && !c.piece) {
      ctx.flash('error', 'Impossible de valider : la pièce justificative est obligatoire.');
      return ctx.redirect(`/assures/${c.assure_id}`);
    }
    run('UPDATE carrieres SET statut = ? WHERE id = ?', statut, c.id);
    if (statut === 'Validé' && c.nouvel_indice) run('UPDATE assures SET indice = ?, updated_at = ? WHERE id = ?', c.nouvel_indice, new Date().toISOString().slice(0, 19).replace('T', ' '), c.assure_id);
    audit(ctx.user, 'Carrière', c.id, statut === 'Validé' ? 'Validation' : 'Rejet', c.statut, statut, ctx.body.motif || '');
    ctx.flash('success', `Événement ${statut === 'Validé' ? 'validé' : 'rejeté'}.`);
    ctx.redirect(`/assures/${c.assure_id}`);
  });

  // ---------- Indices ----------
  router.get('/indices', 'view', (ctx) => {
    const filters = { q: String(ctx.query.q || '').trim(), statut: String(ctx.query.statut || '') };
    const page = int(ctx.query.page, 1);
    const where = [];
    const params = [];
    if (filters.q) { where.push('(reference LIKE ? OR CAST(indice AS TEXT) LIKE ? OR corps LIKE ?)'); const t = `%${filters.q}%`; params.push(t, t, t); }
    if (filters.statut) { where.push('statut = ?'); params.push(filters.statut); }
    const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
    const total = one(`SELECT COUNT(*) AS n FROM indices ${w}`, ...params).n;
    const p = paginate(total, page, 30);
    const rows = q(`SELECT * FROM indices ${w} ORDER BY indice, date_debut DESC LIMIT ? OFFSET ?`, ...params, p.size, p.offset);
    const trs = rows.map(i => [
      td(`<span class="main-cell mono">${esc(i.reference)}</span><span class="sub">${esc(i.corps || '—')} · catégorie ${esc(i.categorie || '—')}</span>`),
      td(String(i.indice), 'num'),
      td(Number(i.valeur_indiciaire) < 100 ? `<span class="text-danger strong">${money(i.valeur_indiciaire)}</span>` : money(i.valeur_indiciaire), 'num'),
      td(`${fmtDate(i.date_debut)}${i.date_fin ? `<span class="sub">au ${fmtDate(i.date_fin)}</span>` : ''}`),
      td(genericBadge(i.statut)),
      td(esc(i.observation || '—')),
      td(can(ctx.user, 'indices.edit') ? `<div class="table-actions"><a class="btn xs" href="/indices/${i.id}/modifier">Modifier</a><form method="post" action="/indices/${i.id}/statut">${csrfField(ctx.csrf)}<input type="hidden" name="statut" value="${i.statut === 'Actif' ? 'Inactif' : 'Actif'}"><button class="btn xs" type="submit">${i.statut === 'Actif' ? 'Désactiver' : 'Activer'}</button></form></div>` : '', 'actions')
    ]);
    const content = `
      ${pageHead('Indices et valeurs indiciaires', 'Référentiel unique par entrée, historisé et contrôlé.', can(ctx.user, 'indices.edit') ? `<a class="btn primary" href="/indices/nouveau">${icon('plus', 16)} Nouvelle valeur</a>` : '', ['Module 05', 'Indices et valeurs'])}
      <div class="callout gold mb16">${icon('alert', 18)}<div><strong>Valeurs paramétrables.</strong> Les taux et valeurs indiciaires exacts doivent être validés par la CRT. Une valeur inférieure à 100 FCFA est signalée automatiquement (anomalie A08).</div></div>
      ${card(`
        <form class="filter-bar" method="get" action="/indices">
          <div class="field grow search-input"><label>Recherche</label><span>${icon('search', 15)}</span><input name="q" value="${esc(filters.q)}" placeholder="Référence, indice ou corps"></div>
          <div class="field"><label>Statut</label><select name="statut"><option value="">Tous</option>${['Actif','Inactif'].map(s => `<option ${filters.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <button class="btn" type="submit">Filtrer</button>
        </form>
        ${dataTable(['Référence', 'Indice', 'Valeur indiciaire', "Période d'application", 'Statut', 'Observation', ''], trs, { empty: 'Aucune valeur indiciaire.' })}
        ${pagination(p, '/indices', filters)}
      `, { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Indices et valeurs', '/indices', content, ['Module 05', 'Indices et valeurs']));
  });

  const indexForm = (ctx, i = {}, error = '', isEdit = false) => {
    const content = `
      ${pageHead(isEdit ? 'Modifier une valeur indiciaire' : 'Nouvelle valeur indiciaire', 'Chaque entrée est unique et historisée.', '<a class="btn" href="/indices">Annuler</a>', ['Module 05', 'Indices et valeurs'])}
      ${error ? `<div class="alert-line">${icon('alert', 17)} ${esc(error)}</div>` : ''}
      <form method="post" action="${isEdit ? `/indices/${i.id}/modifier` : '/indices'}" class="card"><div class="card-body">
        ${csrfField(ctx.csrf)}
        <div class="form-grid">
          <div class="field"><label>Référence unique <span class="req">*</span></label><input name="reference" required value="${esc(i.reference || '')}" placeholder="IDX-2026-0021"></div>
          <div class="field"><label>Indice <span class="req">*</span></label><input type="number" name="indice" min="1" required value="${esc(i.indice ?? '')}"></div>
          <div class="field"><label>Valeur indiciaire (FCFA) <span class="req">*</span></label><input type="number" step="0.01" name="valeur_indiciaire" min="0" required value="${esc(i.valeur_indiciaire ?? '')}"></div>
          <div class="field"><label>Date de début d'application</label><input type="date" name="date_debut" value="${esc(i.date_debut || '')}"></div>
          <div class="field"><label>Date de fin d'application</label><input type="date" name="date_fin" value="${esc(i.date_fin || '')}"></div>
          <div class="field"><label>Catégorie concernée</label><input name="categorie" value="${esc(i.categorie || '')}"></div>
          <div class="field"><label>Corps concerné</label><input name="corps" value="${esc(i.corps || '')}"></div>
          <div class="field"><label>Statut</label><select name="statut">${['Actif','Inactif'].map(s => `<option ${i.statut === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
          <div class="field span2"><label>Observation libre</label><textarea name="observation">${esc(i.observation || '')}</textarea></div>
        </div>
        <div class="form-actions"><button class="btn primary" type="submit">Enregistrer</button><a class="btn" href="/indices">Annuler</a></div>
      </div></form>`;
    ctx.send(ctx.page(isEdit ? 'Modifier une valeur indiciaire' : 'Nouvelle valeur indiciaire', '/indices', content, ['Module 05', 'Indices et valeurs']));
  };

  router.get('/indices/nouveau', 'indices.edit', (ctx) => indexForm(ctx));
  router.get('/indices/:id/modifier', 'indices.edit', (ctx) => {
    const i = one('SELECT * FROM indices WHERE id = ?', Number(ctx.params.id));
    if (!i) return ctx.send('<h1>Valeur introuvable</h1>', 404);
    indexForm(ctx, i, '', true);
  });

  function saveIndex(ctx, id) {
    const b = ctx.body;
    if (!b.reference || !b.indice || !b.valeur_indiciaire) return 'La référence, l’indice et la valeur indiciaire sont obligatoires.';
    if (Number(b.valeur_indiciaire) <= 0) return 'La valeur indiciaire doit être strictement positive.';
    if (b.date_debut && b.date_fin && b.date_fin < b.date_debut) return 'La date de fin ne peut pas précéder la date de début.';
    const dup = one('SELECT id FROM indices WHERE reference = ? AND id <> ?', b.reference.trim(), id || 0);
    if (dup) return 'Cette référence existe déjà.';
    return '';
  }

  router.post('/indices', 'indices.edit', (ctx) => {
    const err = saveIndex(ctx, 0);
    if (err) return indexForm(ctx, ctx.body, err);
    const b = ctx.body;
    const res = run(
      `INSERT INTO indices (reference, indice, valeur_indiciaire, date_debut, date_fin, categorie, corps, observation, statut, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,?)`,
      b.reference.trim(), int(b.indice), Number(b.valeur_indiciaire), b.date_debut || null, b.date_fin || null,
      b.categorie || '', b.corps || '', b.observation || '', b.statut || 'Actif', new Date().toISOString().slice(0, 19).replace('T', ' ')
    );
    audit(ctx.user, 'Indice', Number(res.lastInsertRowid), 'Création', '', `${b.reference} — ${b.indice} / ${b.valeur_indiciaire}`);
    ctx.flash('success', 'Valeur indiciaire enregistrée.');
    ctx.redirect('/indices');
  });

  router.post('/indices/:id/modifier', 'indices.edit', (ctx) => {
    const id = Number(ctx.params.id);
    const before = one('SELECT * FROM indices WHERE id = ?', id);
    if (!before) return ctx.send('<h1>Valeur introuvable</h1>', 404);
    const err = saveIndex(ctx, id);
    if (err) return indexForm(ctx, { ...before, ...ctx.body, id }, err, true);
    const b = ctx.body;
    run(
      `UPDATE indices SET reference=?, indice=?, valeur_indiciaire=?, date_debut=?, date_fin=?, categorie=?, corps=?, observation=?, statut=? WHERE id=?`,
      b.reference.trim(), int(b.indice), Number(b.valeur_indiciaire), b.date_debut || null, b.date_fin || null,
      b.categorie || '', b.corps || '', b.observation || '', b.statut || 'Actif', id
    );
    audit(ctx.user, 'Indice', id, 'Modification', before, b);
    ctx.flash('success', 'Valeur indiciaire mise à jour.');
    ctx.redirect('/indices');
  });

  router.post('/indices/:id/statut', 'indices.edit', (ctx) => {
    const i = one('SELECT * FROM indices WHERE id = ?', Number(ctx.params.id));
    if (!i) return ctx.send('<h1>Valeur introuvable</h1>', 404);
    const statut = ctx.body.statut === 'Actif' ? 'Actif' : 'Inactif';
    run('UPDATE indices SET statut = ? WHERE id = ?', statut, i.id);
    audit(ctx.user, 'Indice', i.id, 'Changement de statut', i.statut, statut);
    ctx.flash('success', `Valeur ${statut === 'Actif' ? 'activée' : 'désactivée'}.`);
    ctx.redirect('/indices');
  });

  // ---------- Organismes / cotisants ----------
  router.get('/organismes', 'view', (ctx) => {
    const orgs = q('SELECT * FROM organismes ORDER BY nom');
    const soldes = soldesMap(orgs.map(o => o.id), 'cotisant');
    const counts = new Map(q('SELECT organisme_id, COUNT(*) AS n FROM assures GROUP BY organisme_id').map(r => [Number(r.organisme_id), r.n]));
    const declStats = new Map(q("SELECT organisme_id, COUNT(*) AS n, MAX(periode) AS last FROM declarations WHERE statut <> 'Rejeté' GROUP BY organisme_id").map(r => [Number(r.organisme_id), r]));
    const trs = orgs.map(o => {
      const st = declStats.get(o.id);
      return [
        td(`<a href="/organismes/${o.id}" class="main-cell">${esc(o.nom)}</a><span class="sub">${esc(o.code)} · ${esc(o.type || '—')} · ${esc(o.ville || '—')}</span>`),
        td(String(counts.get(o.id) || 0), 'num'),
        td(st ? String(st.n) : '0', 'num'),
        td(st ? monthLabel(st.last) : '—'),
        td(soldeBadge(soldes.get(o.id) || 0), 'num'),
        td(genericBadge(o.actif ? 'Actif' : 'Inactif')),
        td(`<div class="table-actions"><a class="btn xs" href="/organismes/${o.id}">Compte</a>${can(ctx.user, 'organismes.edit') ? `<a class="btn xs" href="/organismes/${o.id}/modifier">Modifier</a>` : ''}</div>`, 'actions')
      ];
    });
    const content = `
      ${pageHead('Cotisants', 'Organismes, comptes cotisants et suivi consolidé.', can(ctx.user, 'organismes.edit') ? `<a class="btn primary" href="/organismes/nouveau">${icon('plus', 16)} Nouvel organisme</a>` : '', ['Module 04', 'Cotisants'])}
      ${card(dataTable(['Organisme', 'Assurés', 'Déclarations', 'Dernière période', 'Solde', 'Statut', ''], trs, { empty: 'Aucun organisme.' }), { bodyClass: 'flush' })}`;
    ctx.send(ctx.page('Cotisants', '/organismes', content, ['Module 04', 'Cotisants']));
  });

  router.get('/organismes/nouveau', 'organismes.edit', (ctx) => orgForm(ctx, {}));
  router.get('/organismes/:id', 'view', (ctx) => {
    const o = one('SELECT * FROM organismes WHERE id = ?', Number(ctx.params.id));
    if (!o) return ctx.send('<h1>Organisme introuvable</h1>', 404);
    const compte = compteCotisant(o.id);
    const assures = q('SELECT id, matricule, nom, prenom, statut FROM assures WHERE organisme_id = ? ORDER BY nom LIMIT 20', o.id);
    const decls = q('SELECT * FROM declarations WHERE organisme_id = ? ORDER BY periode DESC LIMIT 14', o.id);
    const paiements = q('SELECT * FROM paiements WHERE organisme_id = ? ORDER BY date_paiement DESC LIMIT 12', o.id);
    const moveRows = compte.rows.slice(-15).reverse().map(m => [
      td(fmtDate(m.date_mouvement)),
      td(esc(m.libelle) + `<span class="sub">${esc(m.reference || '')}</span>`),
      td(m.debit ? money(m.debit) : '—', 'num'),
      td(m.credit ? money(m.credit) : '—', 'num'),
      td(money(m.solde), 'num')
    ]);
    const declRows = decls.map(d => [
      td(`<a href="/declarations/${d.id}" class="mono">${esc(d.reference)}</a>`),
      td(monthLabel(d.periode)),
      td(String(d.nb_assures), 'num'),
      td(money(d.montant_declare), 'num'),
      td(genericBadge(d.statut)),
      td(fmtDate(d.date_reception))
    ]);
    const payRows = paiements.map(p => [
      td(`<span class="mono">${esc(p.reference)}</span>`),
      td(fmtDate(p.date_paiement)),
      td(money(p.montant), 'num'),
      td(esc(p.mode_paiement || '—')),
      td(genericBadge(p.statut))
    ]);
    const content = `
      ${pageHead(o.nom, `${o.code} · ${o.type || 'Organisme'} · ${o.ville || ''}`, `${can(ctx.user, 'declarations.create') ? `<a class="btn primary" href="/declarations/nouvelle?organisme=${o.id}">Nouvelle déclaration</a>` : ''}${can(ctx.user, 'organismes.edit') ? `<a class="btn" href="/organismes/${o.id}/modifier">Modifier</a>` : ''}`, ['Module 04', 'Cotisants', o.code])}
      <div class="stats">
        ${statCard({ label: 'Solde cotisant', value: money(compte.solde), hint: compte.solde > 0 ? 'Reste dû' : 'Compte à jour', tone: compte.solde > 0 ? 'bad' : 'ok', iconName: 'wallet' })}
        ${statCard({ label: 'Total dû cumulé', value: money(compte.debit), hint: 'Déclarations et régularisations', iconName: 'file' })}
        ${statCard({ label: 'Total payé', value: money(compte.credit), hint: 'Paiements rapprochés', tone: 'info', iconName: 'wallet' })}
        ${statCard({ label: 'Assurés rattachés', value: one('SELECT COUNT(*) AS n FROM assures WHERE organisme_id = ?', o.id).n, hint: 'Comptes individuels', iconName: 'users' })}
      </div>
      <div class="grid grid-2">
        ${card(`<dl class="dl tight">
          <dt>Code</dt><dd class="mono">${esc(o.code)}</dd>
          <dt>Type</dt><dd>${esc(o.type || '—')}</dd>
          <dt>Ville</dt><dd>${esc(o.ville || '—')}</dd>
          <dt>Courriel</dt><dd>${esc(o.email || '—')}</dd>
          <dt>Téléphone</dt><dd>${esc(o.telephone || '—')}</dd>
          <dt>Statut</dt><dd>${genericBadge(o.actif ? 'Actif' : 'Inactif')}</dd>
        </dl>`, { title: 'Identité de l’organisme' })}
        ${card(dataTable(['Date', 'Mouvement', 'Débit', 'Crédit', 'Solde'], moveRows, { empty: 'Aucun mouvement.', className: 'compact' }), { title: 'Compte cotisant — mouvements récents', actions: `<a class="btn sm" href="/comptes/cotisants/${o.id}">Voir tout</a>`, bodyClass: 'flush' })}
      </div>
      ${card(dataTable(['Référence', 'Période', 'Assurés', 'Montant déclaré', 'Statut', 'Réception'], declRows, { empty: 'Aucune déclaration.' }), { title: 'Déclarations mensuelles', bodyClass: 'flush' })}
      ${card(dataTable(['Référence', 'Date', 'Montant', 'Mode', 'Rapprochement'], payRows, { empty: 'Aucun paiement.' }), { title: 'Paiements', bodyClass: 'flush' })}
      ${card(dataTable(['Assuré', 'Matricule', 'Statut', ''], assures.map(a => [
        td(`<a href="/assures/${a.id}">${esc(a.nom)} ${esc(a.prenom)}</a>`), td(`<span class="mono">${esc(a.matricule)}</span>`), td(genericBadge(a.statut)), td(`<a class="btn xs" href="/assures/${a.id}">Fiche</a>`, 'actions')
      ]), { empty: 'Aucun assuré rattaché.' }), { title: 'Assurés rattachés', bodyClass: 'flush' })}`;
    ctx.send(ctx.page(o.sigle || o.code, '/organismes', content, ['Module 04', 'Cotisants', o.code]));
  });

  router.get('/organismes/:id/modifier', 'organismes.edit', (ctx) => {
    const o = one('SELECT * FROM organismes WHERE id = ?', Number(ctx.params.id));
    if (!o) return ctx.send('<h1>Organisme introuvable</h1>', 404);
    orgForm(ctx, o, true);
  });

  function orgForm(ctx, o, isEdit = false) {
    const content = `
      ${pageHead(isEdit ? 'Modifier un organisme' : 'Nouvel organisme cotisant', 'Structure rattachée à la CRT.', '<a class="btn" href="/organismes">Annuler</a>', ['Module 04', 'Cotisants'])}
      <form method="post" action="${isEdit ? `/organismes/${o.id}/modifier` : '/organismes'}" class="card"><div class="card-body">
        ${csrfField(ctx.csrf)}
        <div class="form-grid">
          <div class="field"><label>Code <span class="req">*</span></label><input name="code" required value="${esc(o.code || '')}" placeholder="MEF"></div>
          <div class="field"><label>Sigle</label><input name="sigle" value="${esc(o.sigle || '')}"></div>
          <div class="field span2"><label>Nom complet <span class="req">*</span></label><input name="nom" required value="${esc(o.nom || '')}"></div>
          <div class="field"><label>Type</label><select name="type">${['Ministère','Établissement','Collectivité','Agence','Administration','Autre'].map(t => `<option ${o.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
          <div class="field"><label>Ville</label><input name="ville" value="${esc(o.ville || '')}"></div>
          <div class="field"><label>Courriel</label><input type="email" name="email" value="${esc(o.email || '')}"></div>
          <div class="field"><label>Téléphone</label><input name="telephone" value="${esc(o.telephone || '')}"></div>
          <div class="field"><label>Statut</label><select name="actif"><option value="1" ${o.actif !== 0 ? 'selected' : ''}>Actif</option><option value="0" ${o.actif === 0 ? 'selected' : ''}>Inactif</option></select></div>
        </div>
        <div class="form-actions"><button class="btn primary" type="submit">Enregistrer</button><a class="btn" href="/organismes">Annuler</a></div>
      </div></form>`;
    ctx.send(ctx.page(isEdit ? 'Modifier un organisme' : 'Nouvel organisme', '/organismes', content, ['Module 04', 'Cotisants']));
  }

  router.post('/organismes', 'organismes.edit', (ctx) => {
    const b = ctx.body;
    if (!b.code || !b.nom) { ctx.flash('error', 'Le code et le nom sont obligatoires.'); return ctx.redirect('/organismes/nouveau'); }
    if (one('SELECT id FROM organismes WHERE code = ?', b.code.trim().toUpperCase())) { ctx.flash('error', 'Ce code organisme existe déjà.'); return ctx.redirect('/organismes/nouveau'); }
    const res = run('INSERT INTO organismes (code, nom, sigle, type, ville, email, telephone, actif, created_at) VALUES (?,?,?,?,?,?,?,?,?)',
      b.code.trim().toUpperCase(), b.nom.trim(), b.sigle || '', b.type || 'Ministère', b.ville || '', b.email || '', b.telephone || '', b.actif === '0' ? 0 : 1, new Date().toISOString().slice(0, 19).replace('T', ' '));
    audit(ctx.user, 'Organisme', Number(res.lastInsertRowid), 'Création', '', b.nom);
    ctx.flash('success', 'Organisme créé.');
    ctx.redirect('/organismes');
  });

  router.post('/organismes/:id/modifier', 'organismes.edit', (ctx) => {
    const o = one('SELECT * FROM organismes WHERE id = ?', Number(ctx.params.id));
    if (!o) return ctx.send('<h1>Organisme introuvable</h1>', 404);
    const b = ctx.body;
    run('UPDATE organismes SET code=?, nom=?, sigle=?, type=?, ville=?, email=?, telephone=?, actif=? WHERE id=?',
      (b.code || o.code).toUpperCase(), b.nom || o.nom, b.sigle || '', b.type || '', b.ville || '', b.email || '', b.telephone || '', b.actif === '0' ? 0 : 1, o.id);
    audit(ctx.user, 'Organisme', o.id, 'Modification', o, b);
    ctx.flash('success', 'Organisme mis à jour.');
    ctx.redirect(`/organismes/${o.id}`);
  });

  // ---------- Calcul / simulateur ----------
  router.get('/calcul', 'view', (ctx) => {
    const assureId = Number(ctx.query.assure_id || 0);
    const periode = /^\d{4}-\d{2}$/.test(ctx.query.periode || '') ? ctx.query.periode : new Date().toISOString().slice(0, 7);
    const assures = q('SELECT id, matricule, nom, prenom FROM assures ORDER BY nom LIMIT 500');
    let result = '';
    if (assureId) {
      const c = calcMois(assureId, periode);
      if (c) {
        result = `
          <div class="grid grid-2">
            ${card(`<dl class="dl">
              <dt>Assuré</dt><dd>${esc(c.assure.nom)} ${esc(c.assure.prenom)} <span class="mono">(${esc(c.assure.matricule)})</span></dd>
              <dt>Période</dt><dd>${monthLabel(periode)}</dd>
              <dt>Indice applicable</dt><dd>${c.indice || '—'}</dd>
              <dt>Valeur indiciaire</dt><dd>${money(c.valeur)} <span class="small muted">(${esc(c.sourceValeur)})</span></dd>
              <dt>Base de calcul</dt><dd>${money(c.base)}</dd>
              <dt>Taux applicable</dt><dd>${(c.taux * 100).toFixed(2)} %</dd>
              <dt>Cotisation théorique</dt><dd class="strong">${money(c.theorique)}</dd>
              ${c.motif ? `<dt>Observation</dt><dd>${esc(c.motif)}</dd>` : ''}
            </dl>`, { title: 'Décomposition du calcul' })}
            ${card(`<div class="amount-hero ${c.theorique > 0 ? '' : 'ok'}">${money(c.theorique)}</div>
              <p class="muted small mt8">Cotisation théorique mensuelle reconstituée à partir de l'indice et de la valeur indiciaire applicables à la période.</p>
              <div class="callout mt16">${icon('alert', 18)}<div>Le taux de <strong>${(c.taux * 100).toFixed(2)} %</strong> est un paramètre de démonstration. Les taux exacts et règles juridiques doivent être validés par la CRT avant exploitation.</div></div>
              <div class="mt16"><a class="btn primary" href="/expliquer?assure_id=${assureId}&periode=${periode}">Expliquer l'écart complet</a></div>`, { title: 'Résultat' })}
          </div>`;
      }
    }
    const content = `
      ${pageHead('Calcul des cotisations', 'Simulateur de cotisation théorique par assuré et par période.', '', ['Module 09', 'Calcul'])}
      ${card(`<form class="filter-bar" method="get" action="/calcul">
        <div class="field grow"><label>Assuré</label><select name="assure_id" required><option value="">Choisir un assuré…</option>${assures.map(a => `<option value="${a.id}" ${assureId === a.id ? 'selected' : ''}>${esc(a.matricule)} — ${esc(a.nom)} ${esc(a.prenom)}</option>`).join('')}</select></div>
        <div class="field"><label>Période</label><input type="month" name="periode" value="${esc(periode)}"></div>
        <button class="btn primary" type="submit">Calculer</button>
      </form>`, { bodyClass: '' })}
      ${result || `<div class="callout">${icon('calc', 18)}<div><strong>Formule appliquée :</strong> base = indice × valeur indiciaire ; cotisation théorique = base × taux. Les périodes antérieures à la prise de service ou postérieures à la cessation sont neutralisées. La suspension de solde met la cotisation théorique à zéro.</div></div>`}`;
    ctx.send(ctx.page('Calcul', '/calcul', content, ['Module 09', 'Calcul']));
  });
}
