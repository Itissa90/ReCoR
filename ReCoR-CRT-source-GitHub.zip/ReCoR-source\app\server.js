import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { db, ROOT, isSeeded, one } from './db.js';
import { seedDatabase } from './seed.js';
import { getSession, destroySession, cleanupSessions, can } from './auth.js';
import { layout, loginLayout } from './render.js';
import { safeEqual, nowStamp } from './util.js';
import { getPiece, piecePath } from './files.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1';
const SESSION_COOKIE = 'recor_sid';
const ANON_COOKIE = 'recor_csrf';
const MAX_BODY = 20 * 1024 * 1024;
const flashers = new Map();
const loginAttempts = new Map();

export class Router {
  constructor() { this.routes = []; }
  get(pattern, perm, handler) { this.add('GET', pattern, perm, handler); }
  post(pattern, perm, handler) { this.add('POST', pattern, perm, handler); }
  add(method, pattern, perm, handler) {
    const names = [];
    const regex = new RegExp('^' + pattern.replace(/:[a-zA-Z_]+/g, m => {
      names.push(m.slice(1));
      return '([^/]+)';
    }) + '/?$');
    this.routes.push({ method, regex, names, perm, handler, pattern });
  }
  match(method, pathname) {
    for (const r of this.routes) {
      if (r.method !== method) continue;
      const m = r.regex.exec(pathname);
      if (m) {
        const params = {};
        r.names.forEach((n, i) => { params[n] = decodeURIComponent(m[i + 1]); });
        return { route: r, params };
      }
    }
    return null;
  }
}

const router = new Router();

function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function cookie(name, value, { maxAge = 0, httpOnly = false, sameSite = 'Lax', path: p = '/' } = {}) {
  const bits = [`${name}=${encodeURIComponent(value)}`, `Path=${p}`, `SameSite=${sameSite}`];
  if (maxAge) bits.push(`Max-Age=${maxAge}`);
  if (httpOnly) bits.push('HttpOnly');
  return bits.join('; ');
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', c => {
      size += c.length;
      if (size > MAX_BODY) { reject(new Error('Corps de requête trop volumineux')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function parseMultipart(buffer, boundary) {
  const fields = {};
  const files = {};
  const delim = Buffer.from(`--${boundary}`);
  let pos = 0;
  while (pos < buffer.length) {
    const start = buffer.indexOf(delim, pos);
    if (start === -1) break;
    const after = start + delim.length;
    if (buffer.slice(after, after + 2).toString() === '--') break;
    const headerStart = after + 2;
    const headerEnd = buffer.indexOf('\r\n\r\n', headerStart);
    if (headerEnd === -1) break;
    const headers = buffer.slice(headerStart, headerEnd).toString('utf8');
    const next = buffer.indexOf(delim, headerEnd + 4);
    if (next === -1) break;
    let data = buffer.slice(headerEnd + 4, next);
    if (data.slice(-2).toString() === '\r\n') data = data.slice(0, -2);
    const nameMatch = /name="([^"]*)"/i.exec(headers);
    const fileMatch = /filename="([^"]*)"/i.exec(headers);
    if (nameMatch) {
      const n = nameMatch[1];
      if (fileMatch && fileMatch[1]) files[n] = { filename: fileMatch[1], data, size: data.length };
      else fields[n] = data.toString('utf8');
    }
    pos = next;
  }
  return { fields, files };
}

function flashKey(ctx) {
  return ctx.sessionToken || ctx.anonId || ctx.ip;
}

function takeFlash(ctx) {
  const key = flashKey(ctx);
  const f = flashers.get(key);
  if (f && Date.now() - f.at < 5 * 60 * 1000) { flashers.delete(key); return f; }
  return null;
}

function sendHtml(res, html, status = 200) {
  const buf = Buffer.from(html, 'utf8');
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': buf.length,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'"
  });
  res.end(buf);
}

function errorPage(status, title, message) {
  return `<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>${status} — ReCoR</title><link rel="stylesheet" href="/public/styles.css"></head>
  <body><div style="min-height:100vh;display:grid;place-items:center;padding:24px">
  <div class="card" style="max-width:480px;width:100%"><div class="card-body" style="text-align:center;padding:36px">
  <div style="font-size:44px;font-weight:700;color:#0f2742;letter-spacing:-1px">${status}</div>
  <h2 style="margin:8px 0 6px;font-size:18px">${title}</h2>
  <p class="muted" style="font-size:13px">${message}</p>
  <p style="margin-top:20px"><a class="btn primary" href="/">Retour à l'accueil</a></p>
  </div></div></div></body></html>`;
}

const MIME = {
  '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.json': 'application/json; charset=utf-8'
};

function serveStatic(req, res, pathname) {
  const rel = pathname.replace(/^\/public\//, '');
  const full = path.join(PUBLIC_DIR, rel);
  if (!full.startsWith(PUBLIC_DIR)) return false;
  if (!fs.existsSync(full) || !fs.statSync(full).isFile()) return false;
  const ext = path.extname(full).toLowerCase();
  if (!MIME[ext]) return false;
  const buf = fs.readFileSync(full);
  res.writeHead(200, { 'Content-Type': MIME[ext], 'Content-Length': buf.length, 'Cache-Control': 'public, max-age=3600', 'X-Content-Type-Options': 'nosniff' });
  res.end(buf);
  return true;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    if (req.method === 'GET' && pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true, time: nowStamp() }));
      return;
    }
    if (req.method === 'GET' && pathname.startsWith('/public/')) {
      if (serveStatic(req, res, pathname)) return;
      res.writeHead(404); res.end('Not found'); return;
    }

    const cookies = parseCookies(req);
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
    let sessionToken = cookies[SESSION_COOKIE] || '';
    let session = getSession(sessionToken);
    let anonId = cookies[ANON_COOKIE] || '';
    const setCookies = [];
    if (!anonId) {
      anonId = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
      setCookies.push(cookie(ANON_COOKIE, anonId, { maxAge: 8 * 3600, sameSite: 'Lax' }));
    }
    if (sessionToken && !session) {
      setCookies.push(cookie(SESSION_COOKIE, '', { maxAge: 1, httpOnly: true }));
      sessionToken = '';
    }

    let body = {};
    let files = {};
    if (req.method === 'POST') {
      const raw = await readBody(req);
      const ct = String(req.headers['content-type'] || '');
      if (ct.includes('multipart/form-data')) {
        const m = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(ct);
        const boundary = m ? (m[1] || m[2]) : '';
        const parsed = boundary ? parseMultipart(raw, boundary) : { fields: {}, files: {} };
        body = parsed.fields;
        files = parsed.files;
      } else {
        body = Object.fromEntries(new URLSearchParams(raw.toString('utf8')));
      }
    }

    const matched = router.match(req.method, pathname);
    const query = Object.fromEntries(url.searchParams.entries());

    const ctx = {
      req, res, url, pathname, query, params: matched?.params || {}, body, files, ip,
      sessionToken, anonId, user: session ? { ...session.user, csrf: session.session.csrf } : null,
      demo: true,
      csrf: session ? session.session.csrf : anonId,
      setFlash(type, message) { flashers.set(flashKey(this), { type, message, at: Date.now() }); },
      flash: (type, message) => flashers.set(flashKey(ctx), { type, message, at: Date.now() }),
      page(title, active, content, breadcrumb = []) {
        return layout({ user: ctx.user, title, active, content, flash: takeFlash(ctx), breadcrumb });
      },
      redirect(location, status = 303) {
        res.writeHead(status, { Location: location, 'Content-Length': 0 });
        res.end();
        return true;
      },
      send: (html, status = 200) => sendHtml(res, html, status),
      json(obj, status = 200) {
        res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(obj));
      }
    };

    if (setCookies.length) {
      const existing = res.getHeader('Set-Cookie') || [];
      res.setHeader('Set-Cookie', [...(Array.isArray(existing) ? existing : [existing]), ...setCookies]);
    }

    if (!matched) {
      if (pathname === '/login' && req.method === 'GET') { /* handled by route */ }
      if (req.method === 'GET') return sendHtml(res, errorPage(404, 'Page introuvable', "La page demandée n'existe pas."), 404);
      ctx.flash('error', "Action inconnue.");
      return ctx.redirect('/');
    }

    const route = matched.route;
    const isPublic = route.perm === 'public';

    if (!isPublic && !ctx.user) {
      ctx.flash('error', 'Veuillez vous connecter pour continuer.');
      return ctx.redirect('/login');
    }

    if (req.method === 'POST') {
      const expected = isPublic ? anonId : (ctx.user?.csrf || '');
      if (!expected || !safeEqual(String(body._csrf || ''), String(expected))) {
        return sendHtml(res, errorPage(403, 'Session expirée', 'Le formulaire a expiré ou la protection anti-fraude est invalide. Rechargez la page et réessayez.'), 403);
      }
    }

    if (route.perm && route.perm !== 'public' && route.perm !== 'view' && !can(ctx.user, route.perm)) {
      return sendHtml(res, errorPage(403, 'Accès refusé', "Votre profil ne dispose pas du droit requis pour cette action."), 403);
    }

    await route.handler(ctx);
  } catch (err) {
    console.error('ERREUR', err);
    if (!res.headersSent) {
      sendHtml(res, errorPage(500, 'Erreur interne', "Une erreur est survenue. L'incident a été journalisé."), 500);
    } else {
      try { res.end(); } catch { /* ignore */ }
    }
  }
});

export function loginRateBlocked(ip) {
  const rec = loginAttempts.get(ip);
  if (!rec) return false;
  if (Date.now() > rec.until) { loginAttempts.delete(ip); return false; }
  return rec.count >= 8;
}
export function loginFailed(ip) {
  const rec = loginAttempts.get(ip) || { count: 0, until: Date.now() + 10 * 60 * 1000 };
  rec.count++;
  rec.until = Date.now() + 10 * 60 * 1000;
  loginAttempts.set(ip, rec);
}
export function loginSucceeded(ip) { loginAttempts.delete(ip); }
export function setSessionCookie(res, token) {
  const existing = res.getHeader('Set-Cookie') || [];
  res.setHeader('Set-Cookie', [...(Array.isArray(existing) ? existing : [existing]), cookie(SESSION_COOKIE, token, { maxAge: 8 * 3600, httpOnly: true, sameSite: 'Lax' })]);
}
export function clearSessionCookie(res) {
  const existing = res.getHeader('Set-Cookie') || [];
  res.setHeader('Set-Cookie', [...(Array.isArray(existing) ? existing : [existing]), cookie(SESSION_COOKIE, '', { maxAge: 1, httpOnly: true, sameSite: 'Lax' })]);
}

import { register as registerAuth } from './routes/auth.js';
import { register as registerReferentiels } from './routes/referentiels.js';
import { register as registerCotisations } from './routes/cotisations.js';
import { register as registerDossiers } from './routes/dossiers.js';
import { register as registerPilotage } from './routes/pilotage.js';

registerAuth(router);
registerReferentiels(router);
registerCotisations(router);
registerDossiers(router);
registerPilotage(router);

router.get('/pieces/:id', 'view', (ctx) => {
  const piece = getPiece(Number(ctx.params.id));
  const full = piece && piecePath(piece);
  if (!full) return ctx.send(errorPage(404, 'Pièce introuvable', "Le fichier demandé n'est plus disponible."), 404);
  const buf = fs.readFileSync(full);
  const filename = (piece.nom_original || 'piece').replace(/["\r\n]/g, '');
  ctx.res.writeHead(200, {
    'Content-Type': 'application/octet-stream',
    'Content-Length': buf.length,
    'Content-Disposition': `attachment; filename="${filename}"`,
    'X-Content-Type-Options': 'nosniff'
  });
  ctx.res.end(buf);
});

async function start() {
  if (!isSeeded()) {
    console.log('Initialisation de la base et du jeu de démonstration…');
    const res = await seedDatabase();
    console.log('Base initialisée.', res.controls ? `Contrôles: ${JSON.stringify(res.controls)}` : '');
  }
  cleanupSessions();
  setInterval(cleanupSessions, 60 * 60 * 1000).unref();
  server.listen(PORT, HOST, () => {
    console.log(`\n  ReCoR — plateforme CRT`);
    console.log(`  Adresse : http://${HOST}:${PORT}`);
    console.log(`  Compte administrateur : admin / Recor2026!`);
    console.log(`  Arrêt : Ctrl+C\n`);
  });
}

if (process.argv[1] && process.argv[1].endsWith('server.js')) {
  start().catch(err => { console.error('Démarrage impossible:', err); process.exit(1); });
}

export { server, router, start };
