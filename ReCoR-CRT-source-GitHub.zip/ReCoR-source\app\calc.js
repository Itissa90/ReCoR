import { q, one, run, getParam, tx } from './db.js';
import { monthLast, monthLabel, periodFromDate, monthIndex, monthsRange, addMonths } from './util.js';

export function getAssure(id, cache) {
  if (cache?.assures?.has(id)) return cache.assures.get(id);
  const a = one('SELECT * FROM assures WHERE id = ?', id);
  if (cache) {
    if (!cache.assures) cache.assures = new Map();
    cache.assures.set(id, a);
  }
  return a;
}

export function valeurIndiciaireFor(indice, periode) {
  const end = monthLast(periode);
  const row = one(
    `SELECT * FROM indices WHERE indice = ? AND statut = 'Actif'
       AND (date_debut IS NULL OR date_debut <= ?) AND (date_fin IS NULL OR date_fin >= ?)
     ORDER BY date_debut DESC LIMIT 1`, indice, end, `${periode}-01`);
  if (row) return { valeur: Number(row.valeur_indiciaire), source: row.reference, row };
  return { valeur: Number(getParam('VALEUR_INDICIAIRE_DEFAUT', '1000')), source: 'Valeur par défaut', row: null };
}

export function indiceFor(assureId, periode, cache) {
  const end = monthLast(periode);
  if (cache?.indices?.has(`${assureId}|${periode}`)) return cache.indices.get(`${assureId}|${periode}`);
  const ev = one(
    `SELECT nouvel_indice, valeur_indiciaire, date_debut, id FROM carrieres
     WHERE assure_id = ? AND statut = 'Validé' AND nouvel_indice IS NOT NULL AND date_debut <= ?
     ORDER BY date_debut DESC, id DESC LIMIT 1`, assureId, end);
  const assure = getAssure(assureId, cache);
  const indice = ev ? Number(ev.nouvel_indice) : Number(assure?.indice || 0);
  const out = { indice, evenement: ev || null };
  if (cache) {
    if (!cache.indices) cache.indices = new Map();
    cache.indices.set(`${assureId}|${periode}`, out);
  }
  return out;
}

export function calcMois(assureId, periode, cache) {
  const key = `${assureId}|${periode}`;
  if (cache?.calc?.has(key)) return cache.calc.get(key);
  const assure = getAssure(assureId, cache);
  if (!assure) return null;
  const taux = Number(getParam('TAUX_COTISATION', '0.125'));
  const pStart = `${periode}-01`;
  const pEnd = monthLast(periode);
  let theorique = 0;
  let indice = 0, valeur = 0, base = 0, sourceValeur = '';
  let motif = '';
  let suspendu = false;

  if (assure.date_prise_service && periodFromDate(assure.date_prise_service) > periode) {
    motif = 'Période antérieure à la prise de service';
  } else if (assure.date_cessation && periodFromDate(assure.date_cessation) < periode) {
    motif = 'Période postérieure à la cessation';
  } else if (assure.position === 'Suspension' && assure.date_position && assure.date_position <= pEnd) {
    suspendu = true;
    motif = 'Suspension de solde';
  } else {
    const eff = indiceFor(assureId, periode, cache);
    indice = eff.indice;
    const v = valeurIndiciaireFor(indice, periode);
    valeur = v.valeur;
    sourceValeur = v.source;
    base = Math.round(indice * valeur);
    theorique = Math.round(base * taux);
  }

  const out = {
    assure, periode, taux, indice, valeur, base, theorique, sourceValeur,
    suspendu, motif, debut: pStart, fin: pEnd, indice_source: indiceFor(assureId, periode, cache).evenement
  };
  if (cache) {
    if (!cache.calc) cache.calc = new Map();
    cache.calc.set(key, out);
  }
  return out;
}

export function declaredForAssureMonth(assureId, periode) {
  const row = one(
    `SELECT COALESCE(SUM(l.montant),0) AS montant, COUNT(DISTINCT d.id) AS nb
     FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id
     WHERE l.assure_id = ? AND d.periode = ? AND d.statut <> 'Rejeté'`, assureId, periode);
  return { montant: Number(row?.montant || 0), nb: Number(row?.nb || 0) };
}

export function firstDeclarationMonth(assureId) {
  const row = one(
    `SELECT MIN(d.periode) AS p FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id
     WHERE l.assure_id = ? AND d.statut <> 'Rejeté'`, assureId);
  return row?.p || null;
}

export function theoreticalForOrganismMonth(organismeId, periode, cache) {
  const assures = q('SELECT id FROM assures WHERE organisme_id = ? AND statut IN (?,?)', organismeId, 'Actif', 'Suspendu');
  let total = 0;
  for (const a of assures) total += calcMois(a.id, periode, cache).theorique;
  return total;
}

export function paidForDossier(dossierId) {
  const row = one("SELECT COALESCE(SUM(montant),0) AS m FROM paiements WHERE dossier_id = ? AND statut = 'Rapproché'", dossierId);
  return Number(row?.m || 0);
}

export function refreshDossierTotals(dossierId) {
  const d = one('SELECT * FROM dossiers WHERE id = ?', dossierId);
  if (!d) return null;
  const paye = paidForDossier(dossierId);
  const du = Math.max(0, Number(d.montant_theorique || 0) - Number(d.montant_declare || 0) - paye);
  run('UPDATE dossiers SET montant_paye = ?, montant_du = ? WHERE id = ?', paye, du, dossierId);
  return { ...d, montant_paye: paye, montant_du: du };
}

export function getDossier(id) {
  return one(
    `SELECT d.*, a.matricule, a.nom AS assure_nom, a.prenom AS assure_prenom,
            o.nom AS organisme_nom, o.code AS organisme_code
     FROM dossiers d LEFT JOIN assures a ON a.id = d.assure_id
     LEFT JOIN organismes o ON o.id = d.organisme_id WHERE d.id = ?`, id);
}

export function compteAssure(assureId, { from = '', to = '' } = {}) {
  const rows = q(
    `SELECT * FROM mouvements WHERE compte_type = 'assure' AND assure_id = ?
       AND date_mouvement >= ? AND date_mouvement <= ?
     ORDER BY date_mouvement ASC, id ASC`, assureId, from || '0000-01-01', to || '9999-12-31');
  let solde = 0, debit = 0, credit = 0;
  const withSolde = rows.map(r => {
    debit += Number(r.debit || 0);
    credit += Number(r.credit || 0);
    solde = debit - credit;
    return { ...r, solde };
  });
  return { rows: withSolde, debit, credit, solde };
}

export function compteCotisant(organismeId, { from = '', to = '' } = {}) {
  const rows = q(
    `SELECT * FROM mouvements WHERE compte_type = 'cotisant' AND organisme_id = ?
       AND date_mouvement >= ? AND date_mouvement <= ?
     ORDER BY date_mouvement ASC, id ASC`, organismeId, from || '0000-01-01', to || '9999-12-31');
  let solde = 0, debit = 0, credit = 0;
  const withSolde = rows.map(r => {
    debit += Number(r.debit || 0);
    credit += Number(r.credit || 0);
    solde = debit - credit;
    return { ...r, solde };
  });
  return { rows: withSolde, debit, credit, solde };
}

export function rebuildComptes() {
  return tx(() => {
    run('DELETE FROM mouvements');
    const insert = (compteType, assureId, organismeId, date, libelle, debit, credit, origine, reference, periode = null) => {
      run(
        `INSERT INTO mouvements (compte_type, assure_id, organisme_id, date_mouvement, periode, libelle, debit, credit, origine, reference, statut)
         VALUES (?,?,?,?,?,?,?,?,?,?,'Validé')`,
        compteType, assureId || null, organismeId || null, date || '2000-01-01', periode, libelle, debit || 0, credit || 0, origine, reference
      );
    };

    const declarations = q(`SELECT * FROM declarations WHERE statut = 'Validé' ORDER BY periode, id`);
    for (const d of declarations) {
      const lines = q('SELECT * FROM declaration_lignes WHERE declaration_id = ?', d.id);
      const totalLines = lines.reduce((s, l) => s + Number(l.montant || 0), 0);
      for (const l of lines) {
        if (!l.assure_id) continue;
        insert('assure', l.assure_id, d.organisme_id, d.date_reception || d.created_at,
          `Déclaration ${d.type_declaration || 'mensuelle'} — ${monthLabel(d.periode)}`, Number(l.montant || 0), 0, 'Déclaration', d.reference, d.periode);
      }
      insert('cotisant', null, d.organisme_id, d.date_reception || d.created_at,
        `Déclaration ${d.type_declaration || 'mensuelle'} — ${monthLabel(d.periode)}`,
        Number(d.montant_declare || totalLines), 0, 'Déclaration', d.reference, d.periode);

      const pays = q(
        `SELECT * FROM paiements WHERE declaration_id = ? AND statut = 'Rapproché' ORDER BY date_paiement, id`, d.id);
      for (const p of pays) {
        if (totalLines > 0) {
          for (const l of lines) {
            if (!l.assure_id) continue;
            const part = Math.round(Number(p.montant) * (Number(l.montant) / totalLines));
            if (part > 0) insert('assure', l.assure_id, d.organisme_id, p.date_paiement,
              `Paiement imputé — ${p.reference}`, 0, part, 'Paiement', p.reference, d.periode);
          }
        }
        insert('cotisant', null, d.organisme_id, p.date_paiement, `Paiement — ${p.reference}`, 0, Number(p.montant), 'Paiement', p.reference, d.periode);
      }
    }

    const dossiers = q(`SELECT * FROM dossiers WHERE statut IN ('06','07','08','09','10','11','12','13')`);
    for (const d of dossiers) {
      const base = Math.max(0, Number(d.montant_theorique || 0) - Number(d.montant_declare || 0));
      if (base <= 0) continue;
      const libelle = `${d.type === 'Regularisation' ? 'Régularisation' : d.type === 'Redressement' ? 'Redressement' : 'Recouvrement'} ${d.reference}`;
      if (d.assure_id) insert('assure', d.assure_id, d.organisme_id, d.updated_at || d.created_at, libelle, base, 0, 'Régularisation', d.reference, d.periode_debut);
      insert('cotisant', null, d.organisme_id, d.updated_at || d.created_at, libelle, base, 0, 'Régularisation', d.reference, d.periode_debut);
      const pays = q("SELECT * FROM paiements WHERE dossier_id = ? AND statut = 'Rapproché' ORDER BY date_paiement, id", d.id);
      for (const p of pays) {
        if (d.assure_id) insert('assure', d.assure_id, d.organisme_id, p.date_paiement, `Paiement dossier ${d.reference}`, 0, Number(p.montant), 'Paiement', p.reference, d.periode_debut);
        insert('cotisant', null, d.organisme_id, p.date_paiement, `Paiement dossier ${d.reference}`, 0, Number(p.montant), 'Paiement', p.reference, d.periode_debut);
      }
    }

    const orphans = q(`SELECT * FROM paiements WHERE declaration_id IS NULL AND dossier_id IS NULL AND statut = 'Rapproché'`);
    for (const p of orphans) {
      insert('cotisant', null, p.organisme_id, p.date_paiement, `Paiement non imputé — ${p.reference}`, 0, Number(p.montant), 'Paiement', p.reference);
    }
  });
}

export function findDossierFor(assureId, periode) {
  return one(
    `SELECT * FROM dossiers WHERE assure_id = ? AND periode_debut <= ? AND periode_fin >= ?
     ORDER BY id DESC LIMIT 1`, assureId, periode, periode);
}

export function expliquer({ assureId, periode, dossierId }) {
  let dossier = null;
  if (dossierId) {
    dossier = getDossier(dossierId);
    if (dossier) {
      assureId = dossier.assure_id;
      periode = periode || dossier.periode_debut;
    }
  }
  const assure = getAssure(assureId);
  if (!assure) return null;
  const calc = calcMois(assureId, periode);
  const declared = declaredForAssureMonth(assureId, periode);
  const dossierRow = dossier || findDossierFor(assureId, periode);
  const payeRows = q(
    `SELECT p.* FROM paiements p
     WHERE (p.declaration_id IN (SELECT d.id FROM declarations d JOIN declaration_lignes l ON l.declaration_id = d.id
            WHERE l.assure_id = ? AND d.periode = ? AND d.statut <> 'Rejeté'))
        OR (p.dossier_id IN (SELECT id FROM dossiers WHERE assure_id = ? AND periode_debut <= ? AND periode_fin >= ?))
     ORDER BY p.date_paiement`, assureId, periode, assureId, periode, periode);
  const paye = payeRows.reduce((s, p) => s + Number(p.montant || 0), 0);
  const notification = dossierRow ? one('SELECT * FROM notifications WHERE dossier_id = ? ORDER BY id DESC LIMIT 1', dossierRow.id) : null;
  const ecart = calc ? calc.theorique - declared.montant : 0;
  return {
    assure, periode, calc, declared, dossier: dossierRow, notification, paiements: payeRows,
    paye, ecart, reste: Math.max(0, (calc?.theorique || 0) - declared.montant - paye),
    declarations: q(
      `SELECT d.reference, d.periode, d.statut, l.montant FROM declaration_lignes l JOIN declarations d ON d.id = l.declaration_id
       WHERE l.assure_id = ? AND d.periode = ? ORDER BY d.id`, assureId, periode)
  };
}

export function periodesCreques(assureId, debutAnalyse) {
  const assure = getAssure(assureId);
  if (!assure) return [];
  const first = firstDeclarationMonth(assureId);
  const start = assure.date_prise_service ? periodFromDate(assure.date_prise_service) : debutAnalyse;
  const from = monthIndex(start) < monthIndex(debutAnalyse) ? debutAnalyse : start;
  const end = first ? addMonths(first, -1) : null;
  if (!end || monthIndex(from) > monthIndex(end)) return [];
  return monthsRange(from, end);
}

export function declarantSummary(organismeId, periode) {
  return one(
    `SELECT COALESCE(SUM(montant_declare),0) AS montant, COALESCE(SUM(nb_assures),0) AS nb, COUNT(*) AS nb_declarations
     FROM declarations WHERE organisme_id = ? AND periode = ? AND statut <> 'Rejeté'`, organismeId, periode);
}
